<?php
session_start();
include_once("..\config\database.php");
include_once(__DIR__ . "/../includes/navbargest.php");
if (isset($_SESSION['message'])) {
    echo "<p style='color:green; text-align:center;'>" . $_SESSION['message'] . "</p>";
    unset($_SESSION['message']);
    // Après l'ajout réussi
   header("Location: tableau_bord.php?success=1&type=destination");
   exit();
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Destinations - Bénin Tourisme</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<style>
        .hero-section {
            height: 60vh;
            background-size: cover;
            background-position: center;
        }
        .hero-overlay {
            background: rgba(0, 0, 0, 0.5);
        }
        .hero-title {
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .hero-subtitle {
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }
</style>
<!-- Hero Section -->
<section class="hero-section relative" style="background-image: url('../assets/images/destinations.jpeg');">
        <div class="hero-overlay absolute inset-0"></div>
        <div class="hero-content relative z-10 flex flex-col justify-center h-full px-8">
            <h1 class="hero-title text-4xl md:text-5xl font-bold text-white mb-4 animate-fade-in text-center">
            Proposez Votre Destination Touristique
            </h1>
            <p class="hero-subtitle text-xl text-white animate-fade-in" style="animation-delay: 0.2s">
                
                
            </p>
        </div>
    </section>

    <section class="py-16 bg-gray-50">
    <div class="container mx-auto px-4">
        <div class="flex flex-col lg:flex-row gap-8">
            <!-- Informations principales -->
            <div class="lg:w-2/3">
                <div class="info-card bg-white rounded-xl p-8 mb-8">
                    <h2 class="text-2xl font-bold text-gray-800 mb-6">À propos</h2>
                    <h5 class="text-1xl font-sans text-gray-800 mb-2">
                    Proposez Votre Destination Touristique
                        Vous êtes gestionnaire d'un site touristique, propriétaire d'un lieu d'intérêt ou responsable d'une activité culturelle ou naturelle ? Rejoignez la plateforme Benin Découverte et faites découvrir votre destination à des milliers de visiteurs !

                        Grâce à ce formulaire, vous pouvez inscrire votre site, décrire ses atouts, ajouter des photos, et proposer des services associés (guides, hébergement, restauration, etc.).

                        Partagez la beauté de votre région, attirez de nouveaux visiteurs et développez votre activité touristique.
                        <!-- contenu abrégé -->
                    </h5>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="lg:w-1/3">
                <div class="sticky top-8 bg-white p-8 rounded-xl shadow-lg">
                    <h2 class="text-2xl font-bold mb-6 text-gray-800 text-center">Ajouter un lieu</h2>

                    <form action="traitement_destinations.php" method="POST" enctype="multipart/form-data" class="space-y-5">
                        <!-- ... tous tes champs ici ... (nom, description, etc.) -->
                         <!-- Nom -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-map-marker-alt mr-1 text-blue-500"></i>Nom du lieu</label>
                            <input type="text" name="nom" required class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                        </div>

                        <!-- Description -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-align-left mr-1 text-blue-500"></i>Description</label>
                            <textarea name="description" rows="4" required class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300"></textarea>
                        </div>

                        <!-- Adresse -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-map-pin mr-1 text-blue-500"></i>Adresse</label>
                            <input type="text" name="adresse" required class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                        </div>

                        <!-- Ville -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-city mr-1 text-blue-500"></i>Ville</label>
                            <input type="text" name="ville" required class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                        </div>

                        <!-- Région -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-globe-africa mr-1 text-blue-500"></i>Région</label>
                            <select name="region" required class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                            <option value="">Choisir une région</option>
                            <option value="Sud">Sud</option>
                            <option value="Nord">Nord</option>
                            <option value="Centre">Centre</option>
                            <option value="Autre">Autre</option>
                            </select>
                        </div>

                        <!-- Latitude / Longitude -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-location-arrow mr-1 text-blue-500"></i>Latitude</label>
                            <input type="text" name="latitude" class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                            </div>
                            <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-location-arrow mr-1 text-blue-500"></i>Longitude</label>
                            <input type="text" name="longitude" class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                            </div>
                        </div>

                        <!-- Image -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-image mr-1 text-blue-500"></i>Image</label>
                            <input type="file" name="image" accept="image/*" required class="w-full border-gray-300 rounded-lg px-4 py-2 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:bg-blue-100 file:text-blue-700 hover:file:bg-blue-200">
                        </div>

                        <!-- Type -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-tags mr-1 text-blue-500"></i>Type de lieu</label>
                            <select name="type" required class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                            <option value="">Sélectionner un type</option>
                            <option value="Culturel">Culturel</option>
                            <option value="Naturel">Naturel</option>
                            <option value="Historique">Historique</option>
                            <option value="Autre">Autre</option>
                            </select>
                        </div>

                        <!-- Prix -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-money-bill-wave mr-1 text-blue-500"></i>Prix d'entrée (en FCFA)</label>
                            <input type="number" name="prix" min="0" step="100" class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                        </div>

                        <!-- Vidéo -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1">
                                <i class="fas fa-video mr-1 text-blue-500"></i>Vidéo de présentation
                            </label>
                            <input type="file" 
                                   name="video" 
                                   accept="video/mp4,video/mpeg,video/quicktime,video/x-msvideo"
                                   class="w-full border-gray-300 rounded-lg px-4 py-2 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:bg-blue-100 file:text-blue-700 hover:file:bg-blue-200">
                            <p class="text-sm text-gray-500 mt-1">
                                Formats acceptés : MP4, MPEG, MOV, AVI (max 100MB)
                            </p>
                        </div>

                        <div class="text-center pt-4">
                            <button type="submit"
                                class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-2 rounded-lg shadow-md transition duration-300">
                                <i class="fas fa-paper-plane mr-1"></i>Enregistrer
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>





<?php
include_once( "../includes/footergest.php");?>
</body>
</html>
