<!-- En-tête HTML -->
<title>Découvrez le Bénin - Votre Guide Touristique</title>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
<script src="https://cdn.tailwindcss.com"></script>
<?php
// Utiliser le chemin relatif correct pour inclure database.php
include_once(__DIR__ . "/../config/database.php");
?>

<script>
tailwind.config = {
    theme: {
        extend: {
            colors: {
                primary: '#4A5568',
                secondary: '#718096',
                dark: '#2D3748',
            },
            fontFamily: {
                sans: ['Poppins', 'sans-serif'],
            },
            animation: {
                'slide-down': 'slideDown 0.5s ease-out',
                'slide-up': 'slideUp 0.5s ease-out',
                'fade-in': 'fadeIn 0.5s ease-out',
                'scale-in': 'scaleIn 0.5s ease-out',
            },
            keyframes: {
                slideDown: {
                    '0%': { transform: 'translateY(-100%)' },
                    '100%': { transform: 'translateY(0)' }
                },
                slideUp: {
                    '0%': { transform: 'translateY(100%)' },
                    '100%': { transform: 'translateY(0)' }
                },
                fadeIn: {
                    '0%': { opacity: '0' },
                    '100%': { opacity: '1' }
                },
                scaleIn: {
                    '0%': { transform: 'scale(0.9)', opacity: '0' },
                    '100%': { transform: 'scale(1)', opacity: '1' }
                }
            }
        }
    }
}
</script>

<style>
/* Navbar Styles */
.navbar {
    background: rgba(255, 255, 255, 0.95);
    backdrop-filter: blur(10px);
    border-bottom: 1px solid rgba(74, 85, 104, 0.1);
    box-shadow: 0 4px 30px rgba(74, 85, 104, 0.1);
    transition: transform 0.4s ease, opacity 0.4s ease;
    opacity: 0;
    transform: translateY(-100%);
}

.navbar.visible {
    opacity: 1;
    transform: translateY(0);
}

.navbar.scrolled {
    background: rgba(255, 255, 255, 0.98);
    box-shadow: 0 4px 20px rgba(74, 85, 104, 0.1);
}

.nav-link {
    position: relative;
    padding: 0.4rem 0.8rem;
    font-weight: 500;
    font-size: 0.95rem;
    transition: all 0.3s ease;
    margin: 0 0.5rem;
    white-space: nowrap;
}

.nav-link::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: linear-gradient(45deg, #718096, #4A5568);
    opacity: 0;
    transition: opacity 0.3s ease, transform 0.3s ease;
    z-index: -1;
    transform: scale(0.8);
}

.nav-link:hover::before {
    opacity: 0.1;
    transform: scale(1);
}

.nav-link::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 50%;
    width: 0;
    height: 2px;
    background: linear-gradient(90deg, #718096, #4A5568);
    transition: all 0.3s ease;
    transform: translateX(-50%);
}

.nav-link:hover::after {
    width: 100%;
}

.nav-link:hover {
    color: #718096;
    transform: translateY(-1px);
}

.logo-text {
    font-size: 1.4rem;
    font-weight: 700;
    background: linear-gradient(45deg, #4A5568, #718096);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    white-space: nowrap; /* Ajouté pour forcer sur une ligne */
}
.logo-icon {
    font-size: 1.6rem;
    color: #718096;
    transition: all 0.5s ease;
}

.logo-container {
    position: relative;
    overflow: hidden;
    padding: 0.5rem;
    border-radius: 0.5rem;
}

.logo-container::before {
    content: '';
    position: absolute;
    top: -2px;
    left: -2px;
    right: -2px;
    bottom: -2px;
    background: linear-gradient(45deg, #f97316, #1e40af, #f97316);
    background-size: 200% 200%;
    border-radius: 0.5rem;
    z-index: -1;
    animation: gradientMove 3s ease infinite;
}

.logo-container::after {
    content: '';
    position: absolute;
    inset: 0;
    background: rgba(255, 255, 255, 0.95);
    border-radius: 0.5rem;
    z-index: -1;
}

.logo-container:hover .logo-icon {
    transform: rotate(360deg) scale(1.1);
    color: #f97316;
}

@keyframes gradientMove {
    0% { background-position: 0% 50%; }
    50% { background-position: 100% 50%; }
    100% { background-position: 0% 50%; }
}

.nav-links-container {
    display: flex;
    align-items: center;
    gap: 1rem;
}
</style>

<!-- NAVBAR -->
<nav id="navbar" class="navbar fixed top-0 left-0 right-0 z-50 transition-all duration-500 bg-white shadow-md opacity-0 transform -translate-y-full">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="flex justify-between items-center h-16">
            <!-- Logo -->
            <a href="../index.php" class="flex items-center space-x-2">
                <div class="logo-container">
                    <i class="fas fa-globe-africa logo-icon"></i>
                </div>
                <span class="logo-text">Bénin Tourisme</span>
            </a>

            <!-- Hamburger -->
            <div class="lg:hidden">
                <input type="checkbox" id="menu-toggle" class="hidden">
                <label for="menu-toggle" class="cursor-pointer flex flex-col gap-1">
                    <span class="w-6 h-0.5 bg-gray-800"></span>
                    <span class="w-6 h-0.5 bg-gray-800"></span>
                    <span class="w-6 h-0.5 bg-gray-800"></span>
                </label>
            </div>

            <!-- Menu links -->
            <div id="menu" class="hidden lg:flex flex-col lg:flex-row lg:items-center gap-4 lg:gap-6 absolute lg:static top-16 left-0 w-full lg:w-auto bg-white lg:bg-transparent px-4 lg:px-0 py-4 lg:py-0 shadow-md lg:shadow-none z-40">
                <a href="/ProjetBinome/pages/destinations.php" class="nav-link text-primary">Destinations</a>
                <a href="/ProjetBinome/pages/hotel.php" class="nav-link text-primary">Hôtels</a>
                <a href="/ProjetBinome/pages/circuits.php" class="nav-link text-primary">Circuits</a>
                <a href="/ProjetBinome/pages/evenements.php" class="nav-link text-primary">Événements</a>
                <a href="/ProjetBinome/pages/blog.php" class="nav-link text-primary">Blog</a>
                <a href="/ProjetBinome/pages/contact.php" class="nav-link text-primary">Contact</a>
                <a href="/ProjetBinome/pages/a_propos.php" class="nav-link text-primary">À propos</a>
            </div>
        </div>
    </div>
</nav>

<!-- ESPACE pour éviter que la navbar ne cache le contenu -->
<div class="h-16"></div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
        const navbar = document.getElementById('navbar');
        let lastScroll = 0;

        // Affiche la navbar après chargement
        setTimeout(() => {
            navbar.classList.add('visible');
            navbar.classList.remove('opacity-0', '-translate-y-full');
        }, 500); // 500ms = transition plus fluide que 3000ms

        // Gère le scroll
        window.addEventListener('scroll', () => {
            const currentScroll = window.pageYOffset;

            if (currentScroll <= 0) {
                navbar.classList.remove('scrolled');
                navbar.style.transform = 'translateY(0)';
                return;
            }

            if (currentScroll > lastScroll && currentScroll > 100) {
                // Scroll vers le bas → cacher la navbar
                navbar.style.transform = 'translateY(-100%)';
            } else {
                // Scroll vers le haut → montrer la navbar
                navbar.style.transform = 'translateY(0)';
                navbar.classList.add('scrolled');
            }

            lastScroll = currentScroll;
        });
    });
</script>
