<?php
// Connexion à la base de données
require_once '../config/database.php'; // à adapter selon ton projet


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération des champs texte
    $nom = $_POST['nom'];
    $description = $_POST['description'];
    $etoile = $_POST['etoiles'];
    $ville = $_POST['ville'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $telephone = $_POST['telephone'];
    $prix = $_POST['prix'];
    $contenu = $_POST['description_supp'];
    $site = $_POST['site_web'];
    $email = $_POST['email'];

    // Gestion de l'image
    $image_nom = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_nom = basename($_FILES['image']['name']);
        $image_destination = '../assets/images/' . $image_nom;
        move_uploaded_file($image_tmp, $image_destination);
    }
    $imagesupp_nom = '';
    if (isset($_FILES['image_supp']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_nom = basename($_FILES['image']['name']);
        $image_destination = '../assets/images/' . $image_nom;
        move_uploaded_file($image_tmp, $image_destination);
    }

    

    // Requête d'insertion
    $sql = "INSERT INTO hotels (nom, description, etoiles, ville, téléphone, latitude, longitude, image,image_supplementaire,contenu, prix_min, site,email)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $nom,
        $description,
        $etoile,
        $ville,
        $telephone,
        $latitude,
        $longitude,
        $image_nom,
        $imagesupp_nom,
        $contenu,
        $prix,
        $site,
        $email
    ]);

    $_SESSION['message'] = "✅ Lieu ajouté avec succès !";
    $_SESSION['message_type'] = "success"; // ou "error", selon le besoin
    header('Location: hotels.php');
    exit();
}else {
    $_SESSION['message'] = "erreur lors de l'ajout ";
$_SESSION['message_type'] = "warning"; // ou "error", selon le besoin
header('Location: hotels.php');
}
?>


