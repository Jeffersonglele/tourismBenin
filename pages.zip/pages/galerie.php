<?php
session_start();
include_once("..\config\database.php");

try {
    // Récupérer tous les posts avec leurs médias
    $stmt = $pdo->query("
        SELECT 
            p.*,
            u.prenom as auteur_prenom,
            u.nom as auteur_nom,
            COUNT(l.id) as nombre_likes,
            EXISTS(SELECT 1 FROM blog_likes WHERE post_id = p.id AND user_id = " . (isset($_SESSION['user_id']) ? $_SESSION['user_id'] : 0) . ") as user_liked
        FROM blog_posts p
        LEFT JOIN users u ON p.user_id = u.id
        LEFT JOIN blog_likes l ON p.id = l.post_id
        WHERE p.image_url IS NOT NULL OR p.fichier_url IS NOT NULL
        GROUP BY p.id
        ORDER BY p.date_creation DESC
    ");
    $posts = $stmt->fetchAll();
} catch (PDOException $e) {
    $posts = [];
}

// Fonction pour obtenir l'icône en fonction du type de fichier
function getFileIcon($filename) {
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    switch ($extension) {
        case 'pdf':
            return 'fas fa-file-pdf';
        case 'doc':
        case 'docx':
            return 'fas fa-file-word';
        case 'txt':
            return 'fas fa-file-alt';
        case 'zip':
        case 'rar':
            return 'fas fa-file-archive';
        default:
            return 'fas fa-file';
    }
}

// Définir le titre de la page
$page_title = "Galerie - Bénin Tourisme";

// Inclure le header
include_once(__DIR__ . "/../includes/header.php"); 
include_once(__DIR__ . "/../includes/navbar.php"); 
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galerie - Bénin Tourisme</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .galerie-container {
            padding-top: 100px;
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        .media-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            transition: transform 0.3s ease;
            overflow: hidden;
        }
        .media-card:hover {
            transform: translateY(-5px);
        }
        .media-image {
            width: 100%;
            height: 250px;
            object-fit: cover;
        }
        .file-icon {
            font-size: 4rem;
            color: #6c757d;
            margin: 2rem 0;
        }
        .like-button {
            cursor: pointer;
            transition: color 0.3s ease;
        }
        .like-button:hover {
            color: #dc3545;
        }
        .like-button.liked {
            color: #dc3545;
        }
        .filter-buttons {
            margin-bottom: 2rem;
        }
        .filter-button {
            margin: 0 0.5rem;
            padding: 0.5rem 1.5rem;
            border-radius: 25px;
            transition: all 0.3s ease;
        }
        .filter-button.active {
            background-color: #0d6efd;
            color: white;
        }
    </style>
</head>
<body>
    <div class="galerie-container">
        <div class="container">
            <h2 class="text-center mb-4">Galerie des Médias</h2>

            <div class="filter-buttons text-center">
                <button class="btn btn-outline-primary filter-button active" data-filter="all">
                    <i class="fas fa-th-large me-2"></i>Tout
                </button>
                <button class="btn btn-outline-primary filter-button" data-filter="images">
                    <i class="fas fa-image me-2"></i>Images
                </button>
                <button class="btn btn-outline-primary filter-button" data-filter="files">
                    <i class="fas fa-file me-2"></i>Fichiers
                </button>
            </div>

            <div class="row">
                <?php foreach ($posts as $post): ?>
                    <div class="col-md-6 col-lg-4 mb-4 media-item" 
                         data-type="<?php echo $post['image_url'] ? 'images' : 'files'; ?>">
                        <div class="media-card">
                            <?php if ($post['image_url']): ?>
                                <img src="<?php echo htmlspecialchars($post['image_url']); ?>" 
                                     class="media-image" 
                                     alt="Image du post">
                            <?php else: ?>
                                <div class="text-center">
                                    <i class="<?php echo getFileIcon($post['fichier_url']); ?> file-icon"></i>
                                </div>
                            <?php endif; ?>
                            
                            <div class="p-4">
                                <h5 class="mb-3"><?php echo htmlspecialchars($post['titre']); ?></h5>
                                
                                <div class="d-flex justify-content-between align-items-center mb-3">
                                    <div class="text-muted small">
                                        <i class="fas fa-user me-2"></i>
                                        <?php echo htmlspecialchars($post['auteur_prenom'] . ' ' . $post['auteur_nom']); ?>
                                    </div>
                                    <div class="text-muted small">
                                        <i class="fas fa-clock me-2"></i>
                                        <?php echo date('d/m/Y', strtotime($post['date_creation'])); ?>
                                    </div>
                                </div>

                                <?php if ($post['fichier_url']): ?>
                                    <div class="mb-3">
                                        <a href="<?php echo htmlspecialchars($post['fichier_url']); ?>" 
                                           class="btn btn-outline-primary w-100" 
                                           download>
                                            <i class="fas fa-download me-2"></i>Télécharger
                                        </a>
                                    </div>
                                <?php endif; ?>

                                <div class="d-flex justify-content-between align-items-center">
                                    <div>
                                        <?php if (isset($_SESSION['user_id'])): ?>
                                            <form method="POST" action="blog.php" class="d-inline">
                                                <input type="hidden" name="action" value="<?php echo $post['user_liked'] ? 'unlike' : 'like'; ?>">
                                                <input type="hidden" name="post_id" value="<?php echo $post['id']; ?>">
                                                <button type="submit" class="btn btn-link p-0 me-2">
                                                    <i class="fas fa-heart like-button <?php echo $post['user_liked'] ? 'liked' : ''; ?>"></i>
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                        <span class="text-muted">
                                            <?php echo $post['nombre_likes']; ?> like<?php echo $post['nombre_likes'] > 1 ? 's' : ''; ?>
                                        </span>
                                    </div>
                                    <a href="blog.php#post-<?php echo $post['id']; ?>" class="btn btn-sm btn-outline-secondary">
                                        <i class="fas fa-eye me-2"></i>Voir le post
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <?php include_once(__DIR__ . "/../includes/footer.php"); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const filterButtons = document.querySelectorAll('.filter-button');
            const mediaItems = document.querySelectorAll('.media-item');

            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    // Mettre à jour les boutons actifs
                    filterButtons.forEach(btn => btn.classList.remove('active'));
                    this.classList.add('active');

                    // Filtrer les éléments
                    const filter = this.dataset.filter;
                    mediaItems.forEach(item => {
                        if (filter === 'all' || item.dataset.type === filter) {
                            item.style.display = 'block';
                        } else {
                            item.style.display = 'none';
                        }
                    });
                });
            });
        });
    </script>
</body>
</html> 