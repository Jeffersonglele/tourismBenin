<?php
require_once 'database.php';
require_once 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Vérification de la méthode de requête
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Méthode non autorisée']);
    exit;
}

// Récupération et nettoyage de l'email
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);

// Validation de l'email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['error' => 'Adresse email invalide']);
    exit;
}

try {
    // Vérification si l'email existe déjà
    $stmt = $conn->prepare("SELECT id FROM newsletter_subscribers WHERE email = ?");
    $stmt->execute([$email]);
    
    if ($stmt->rowCount() > 0) {
        http_response_code(400);
        echo json_encode(['error' => 'Cette adresse email est déjà inscrite']);
        exit;
    }

    // Insertion dans la base de données
    $stmt = $conn->prepare("INSERT INTO newsletter_subscribers (email, created_at) VALUES (?, NOW())");
    $stmt->execute([$email]);

    // Configuration de PHPMailer
    $mail = new PHPMailer(true);

    // Configuration du serveur
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; // Remplacez par votre serveur SMTP
    $mail->SMTPAuth = true;
    $mail->Username = 'contactbenintourisme@gmail.com'; // Remplacez par votre email
    $mail->Password = 'hvbd rvhi nknf hmas'; // Remplacez par votre mot de passe
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 587;
    $mail->CharSet = 'UTF-8';

    // Destinataires
    $mail->setFrom('noreply@benintourisme.com', 'Bénin Tourisme');
    $mail->addAddress($email);

    // Contenu
    $mail->isHTML(true);
    $mail->Subject = "Confirmation d'inscription à la newsletter - Bénin Tourisme";
    
    // Template HTML de l'email
    $mail->Body = "
    <html>
    <head>
        <title>Bienvenue dans notre newsletter</title>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: linear-gradient(45deg, #1e40af, #f97316); color: white; padding: 20px; text-align: center; }
            .content { padding: 20px; background: #f9fafb; }
            .footer { text-align: center; padding: 20px; font-size: 12px; color: #666; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>Bienvenue dans notre newsletter !</h1>
            </div>
            <div class='content'>
                <p>Cher(e) abonné(e),</p>
                <p>Merci de vous être inscrit(e) à la newsletter de Bénin Tourisme. Vous recevrez désormais nos actualités, offres spéciales et informations sur les événements touristiques au Bénin.</p>
                <p>Pour vous désabonner, cliquez simplement sur le lien en bas de nos emails.</p>
            </div>
            <div class='footer'>
                <p>© " . date('Y') . " Bénin Tourisme. Tous droits réservés.</p>
            </div>
        </div>
    </body>
    </html>
    ";

    // Version texte de l'email
    $mail->AltBody = "Merci de vous être inscrit(e) à la newsletter de Bénin Tourisme. Vous recevrez désormais nos actualités, offres spéciales et informations sur les événements touristiques au Bénin.";

    // Envoi de l'email
    $mail->send();

    // Réponse de succès
    echo json_encode([
        'success' => true,
        'message' => 'Inscription réussie ! Un email de confirmation vous a été envoyé.'
    ]);

} catch (PDOException $e) {
    // Log de l'erreur
    error_log("Erreur newsletter : " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'error' => 'Une erreur est survenue lors de l\'inscription'
    ]);
} catch (Exception $e) {
    // Log de l'erreur PHPMailer
    error_log("Erreur PHPMailer : " . $e->getMessage());
    
    http_response_code(500);
    echo json_encode([
        'error' => 'Une erreur est survenue lors de l\'envoi de l\'email'
    ]);
}
?> 