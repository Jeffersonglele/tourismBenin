<?php
session_start();
$page_title = "Inscription réussie - Bénin Tourisme";
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: #fafafa;
            padding: 20px;
        }

        .success-container {
            background: white;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            text-align: center;
            max-width: 600px;
            width: 100%;
            animation: fadeIn 0.5s ease-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .success-icon {
            width: 80px;
            height: 80px;
            background: #28a745;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 20px;
            animation: scaleIn 0.5s ease-out;
        }

        @keyframes scaleIn {
            from {
                transform: scale(0);
            }
            to {
                transform: scale(1);
            }
        }

        .success-icon svg {
            width: 40px;
            height: 40px;
            fill: white;
        }

        h1 {
            color: #1a237e;
            margin-bottom: 20px;
            font-size: 28px;
        }

        .message {
            color: #495057;
            margin-bottom: 30px;
            line-height: 1.6;
        }

        .status {
            background: #e8f5e9;
            color: #2e7d32;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 30px;
            font-weight: 500;
        }

        .next-steps {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            text-align: left;
        }

        .next-steps h2 {
            color: #1a237e;
            font-size: 18px;
            margin-bottom: 15px;
        }

        .next-steps ul {
            list-style: none;
            padding-left: 20px;
        }

        .next-steps li {
            margin-bottom: 10px;
            color: #495057;
            position: relative;
            padding-left: 25px;
        }

        .next-steps li:before {
            content: "•";
            color: #1a237e;
            font-weight: bold;
            position: absolute;
            left: 0;
        }

        .button {
            display: inline-block;
            padding: 12px 30px;
            background: #1a237e;
            color: white;
            text-decoration: none;
            border-radius: 8px;
            font-weight: 500;
            transition: all 0.3s ease;
        }

        .button:hover {
            background: #0d47a1;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(13, 71, 161, 0.3);
        }

        .contact-info {
            margin-top: 30px;
            color: #6c757d;
            font-size: 14px;
        }

        .contact-info a {
            color: #1a237e;
            text-decoration: none;
        }

        .contact-info a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="success-container">
        <div class="success-icon">
            <svg viewBox="0 0 24 24">
                <path d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41L9 16.17z"/>
            </svg>
        </div>
        
        <h1>Paiement Réussi !</h1>
        
        <div class="message">
            Votre inscription a été enregistrée avec succès.
        </div>
        
        <div class="status">
            Votre compte est en attente de validation par l'administrateur.
        </div>
        
        <div class="next-steps">
            <h2>Prochaines étapes :</h2>
            <ul>
                <li>Vous recevrez un email de confirmation une fois votre compte validé</li>
                <li>Vous pourrez alors vous connecter à votre espace gestionnaire</li>
                <li>Vous aurez accès à toutes les fonctionnalités de gestion</li>
            </ul>
        </div>
        
        <a href="../index.php" class="button">Retour à l'accueil</a>
        
        <div class="contact-info">
            <p>Pour toute question, contactez-nous :</p>
            <p>Email : <a href="mailto:contactbenintourisme@gmail.com">contactbenintourisme@gmail.com</a></p>
            <p>Téléphone : <a href="tel:+22990077139">+229 90 07 71 39</a> / <a href="tel:+22964780067">+229 64 78 00 67</a></p>
        </div>
    </div>
</body>
</html> 