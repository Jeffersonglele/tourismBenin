<?php
session_start();
include_once("..\config\database.php");
include_once("..\config\mail.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL);
    $errors = [];

    if (!$email) {
        $errors[] = "Adresse email invalide";
    } else {
        // Vérifier si l'email existe déjà
        $stmt = $pdo->prepare("SELECT id FROM newsletter WHERE email = ?");
        $stmt->execute([$email]);
        if ($stmt->fetch()) {
            $errors[] = "Cette adresse email est déjà inscrite à la newsletter";
        }
    }

    if (empty($errors)) {
        try {
            // Insérer l'email dans la base de données
            $stmt = $pdo->prepare("INSERT INTO newsletter (email, date_inscription) VALUES (?, NOW())");
            $result = $stmt->execute([$email]);

            if ($result) {
                // Envoyer un email de confirmation à l'utilisateur
                $userEmailBody = "
                    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;'>
                        <div style='background-color: #1e40af; padding: 20px; text-align: center; border-radius: 5px 5px 0 0;'>
                            <h1 style='color: white; margin: 0;'>Bienvenue à la newsletter de Bénin Tourisme !</h1>
                        </div>
                        <div style='background-color: #f8f9fa; padding: 20px; border-radius: 0 0 5px 5px;'>
                            <p>Cher(e) abonné(e),</p>
                            <p>Nous sommes ravis de vous accueillir dans notre communauté ! En vous inscrivant à notre newsletter, vous serez parmi les premiers à :</p>
                            <ul style='color: #1e40af;'>
                                <li>Découvrir nos nouvelles destinations</li>
                                <li>Bénéficier de nos offres exclusives</li>
                                <li>Recevoir nos actualités touristiques</li>
                                <li>Participer à nos événements spéciaux</li>
                            </ul>
                            <p>Votre inscription a été enregistrée le " . date('d/m/Y à H:i') . ".</p>
                            <div style='background-color: #e5e7eb; padding: 15px; border-radius: 5px; margin: 20px 0;'>
                                <p style='margin: 0;'><strong>Pour vous désinscrire :</strong> Cliquez simplement sur le lien de désinscription en bas de nos emails.</p>
                            </div>
                            <p>À très bientôt !</p>
                            <p style='color: #1e40af;'><strong>L'équipe Bénin Tourisme</strong></p>
                        </div>
                    </div>
                ";
                sendEmail($email, "Bienvenue à la newsletter - Bénin Tourisme", $userEmailBody);

                // Envoyer une notification à l'administrateur
                $adminEmailBody = "
                    <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;'>
                        <div style='background-color: #1e40af; padding: 20px; text-align: center; border-radius: 5px 5px 0 0;'>
                            <h1 style='color: white; margin: 0;'>Nouvelle inscription à la newsletter</h1>
                        </div>
                        <div style='background-color: #f8f9fa; padding: 20px; border-radius: 0 0 5px 5px;'>
                            <p>Bonjour,</p>
                            <p>Une nouvelle personne vient de s'inscrire à la newsletter :</p>
                            <div style='background-color: #e5e7eb; padding: 20px; border-radius: 5px; margin: 20px 0;'>
                                <p><strong>Email :</strong> $email</p>
                                <p><strong>Date d'inscription :</strong> " . date('d/m/Y à H:i:s') . "</p>
                                <p><strong>IP :</strong> " . $_SERVER['REMOTE_ADDR'] . "</p>
                                <p><strong>Navigateur :</strong> " . $_SERVER['HTTP_USER_AGENT'] . "</p>
                            </div>
                            <p>Nombre total d'abonnés : " . getTotalSubscribers() . "</p>
                            <p>Cordialement,<br>Système de notification</p>
                        </div>
                    </div>
                ";
                sendEmail(SMTP_FROM_EMAIL, "Nouvelle inscription newsletter - Bénin Tourisme", $adminEmailBody);

                $_SESSION['success_message'] = "Inscription à la newsletter réussie !";
            } else {
                throw new PDOException("Erreur lors de l'insertion dans la base de données");
            }
        } catch (PDOException $e) {
            $errors[] = "Une erreur est survenue lors de l'inscription";
            error_log("Erreur newsletter : " . $e->getMessage());
        }
    }

    if (!empty($errors)) {
        $_SESSION['error_messages'] = $errors;
    }

    // Rediriger vers la page précédente
    header('Location: ' . $_SERVER['HTTP_REFERER']);
    exit;
} else {
    // Si ce n'est pas une requête POST, rediriger vers la page d'accueil
    header('Location: ..\index.php');
    exit;
}

// Fonction pour obtenir le nombre total d'abonnés
function getTotalSubscribers() {
    global $pdo;
    $stmt = $pdo->query("SELECT COUNT(*) FROM newsletter");
    return $stmt->fetchColumn();
} 