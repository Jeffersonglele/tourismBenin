<?php
session_start();
include_once("..\config\database.php");
include_once(__DIR__ . "/../includes/navbargest.php");
// Après l'ajout réussi
header("Location: tableau_bord.php?success=1&type=destination");
exit();

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Destinations - Bénin Tourisme</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<style>
        .hero-section {
            height: 60vh;
            background-size: cover;
            background-position: center;
        }
        .hero-overlay {
            background: rgba(0, 0, 0, 0.5);
        }
        .hero-title {
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .hero-subtitle {
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }
</style>
<section class="hero-section relative" style="background-image: url('../assets/images/h.jpeg');">
        <div class="hero-overlay absolute inset-0"></div>
        <div class="hero-content relative z-10 flex flex-col justify-center h-full px-8">
            <h1 class="hero-title text-4xl md:text-5xl font-bold text-white mb-4 animate-fade-in text-center">
            Proposez Votre hotel 
            </h1>
            <p class="hero-subtitle text-xl text-white animate-fade-in" style="animation-delay: 0.2s">
                
                
            </p>
        </div>
</section>
<section class="py-16 bg-gray-50">
    <div class="container mx-auto px-4">
        <div class="flex flex-col lg:flex-row gap-8">
            <!-- Informations principales -->
            <div class="lg:w-2/3">
                <div class="info-card bg-white rounded-xl p-8 mb-8">
                    <h2 class="text-2xl font-bold text-gray-800 mb-6">Vous êtes gestionnaire d’un hôtel?</h2>
                    <h5 class="text-1xl font-sans text-gray-800 mb-2">
                    Vous souhaitez augmenter la visibilité de votre établissement et attirer plus de touristes locaux et internationaux ?
                    Benin Découverte vous offre une opportunité unique de faire connaître votre hôtel ou site touristique à un large public passionné par la richesse culturelle et naturelle du Bénin.

                    💡 En inscrivant votre établissement sur notre plateforme, vous bénéficiez de :

                    Une vitrine en ligne avec photos, description, et services proposés

                    Un accès à un public ciblé à la recherche d’hébergements et d’expériences authentiques

                    La possibilité de recevoir directement des demandes de réservation

                    📋 Remplissez dès maintenant le formulaire ci-dessous pour enregistrer votre établissement sur notre site.
                    Notre équipe validera vos informations dans les plus brefs délais afin de les mettre en ligne.

                    ➡️ Rejoignez-nous et faites partie du réseau qui met en valeur le Bénin !
                    
                    </h5>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="lg:w-1/3">
                <div class="sticky top-8 bg-white p-8 rounded-xl shadow-lg">
                    <h2 class="text-2xl font-bold mb-6 text-gray-800 text-center">Ajouter un hotel</h2>

                    <form action="traitement_hotel.php" method="POST" enctype="multipart/form-data" class="space-y-5">
                         <!-- Nom -->
                         <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-map-marker-alt mr-1 text-blue-500"></i>Nom du lieu</label>
                            <input type="text" name="nom" required class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                        </div>

                        <!-- Description -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-align-left mr-1 text-blue-500"></i>Description</label>
                            <textarea name="description" rows="4" required class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300"></textarea>
                        </div>

                       

                        <!-- Ville -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-city mr-1 text-blue-500"></i>Ville</label>
                            <input type="text" name="ville" required class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                        </div>

                        

                        <!-- Latitude / Longitude -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-location-arrow mr-1 text-blue-500"></i>Latitude</label>
                            <input type="text" name="latitude" class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                            </div>
                            <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-location-arrow mr-1 text-blue-500"></i>Longitude</label>
                            <input type="text" name="longitude" class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                            </div>
                        </div>

                        <!-- Image -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-image mr-1 text-blue-500"></i>Image</label>
                            <input type="file" name="image" accept="image/*" required class="w-full border-gray-300 rounded-lg px-4 py-2 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:bg-blue-100 file:text-blue-700 hover:file:bg-blue-200">
                        </div>
                        <!-- Nombre d'étoiles -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1">
                                <i class="fas fa-star mr-1 text-yellow-500"></i>Nombre d'étoiles (ex : 3.5)
                            </label>
                            <input type="number" name="etoiles" min="0" max="5" step="0.1" placeholder="Ex : 4.5" class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                        </div>

                        <!-- Prix -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-money-bill-wave mr-1 text-blue-500"></i>Prix minimale (en FCFA)</label>
                            <input type="number" name="prix" min="0" step="100" class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                        </div>
                        <!-- Téléphone -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1">
                                <i class="fas fa-phone-alt mr-1 text-blue-500"></i>Téléphone
                            </label>
                            <input type="tel" name="telephone" placeholder="+229 90 00 00 00" class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                        </div>

                        <!-- Email -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1">
                                <i class="fas fa-envelope mr-1 text-blue-500"></i>Email
                            </label>
                            <input type="email" name="email" placeholder="exemple@domaine.com" class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                        </div>

                        <!-- Site Web -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1">
                                <i class="fas fa-globe mr-1 text-blue-500"></i>Site web
                            </label>
                            <input type="url" name="site_web" placeholder="https://votre-site.com" class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300">
                        </div>

                        <!-- Contenu captivant -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1">
                                <i class="fas fa-align-left mr-1 text-blue-500"></i>Description de l’établissement
                            </label>
                            <textarea name="description_supp" rows="5" placeholder="Décrivez votre établissement, ses services, son ambiance..." class="w-full border-gray-300 rounded-lg px-4 py-2 focus:ring focus:ring-blue-300"></textarea>
                        </div>
                        <!-- Image -->
                        <div>
                            <label class="block text-gray-700 font-medium mb-1"><i class="fas fa-image mr-1 text-blue-500"></i>Image supplémentaires(facultatif)</label>
                            <input type="file" name="image_supp" accept="image/*"  class="w-full border-gray-300 rounded-lg px-4 py-2 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:bg-blue-100 file:text-blue-700 hover:file:bg-blue-200">
                        </div>
                        


                        <div class="text-center pt-4">
                            <button type="submit"
                                class="bg-blue-600 hover:bg-blue-700 text-white font-semibold px-6 py-2 rounded-lg shadow-md transition duration-300">
                                <i class="fas fa-paper-plane mr-1"></i>Enregistrer
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>




<?php
include_once( "../includes/footergest.php");?>
</body>
</html>
