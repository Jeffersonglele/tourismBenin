<?php
include_once("../includes/navbar.php");
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>À Propos - Bénin Tourisme</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<body class="bg-white">
<section class="bg-white py-16 px-4 sm:px-6 lg:px-8">
  <div class="max-w-4xl mx-auto text-center">
    <h1 class="text-4xl font-extrabold text-gray-900 mb-4">🌟 Devenir gestionnaire</h1>
    <p class="text-lg text-gray-600">
      Valorisez les richesses touristiques du Bénin en rejoignant notre plateforme en tant que gestionnaire.
    </p>
  </div>

  <div class="mt-12 grid gap-12 md:grid-cols-2">
    <!-- Section texte explicatif -->
    <div>
      <h2 class="text-2xl font-semibold text-gray-800 mb-4">Pourquoi devenir gestionnaire ?</h2>
      <ul class="list-disc list-inside text-gray-700 space-y-2">
        <li>Proposez et gérez des lieux touristiques uniques</li>
        <li>Ajoutez des photos, descriptions, événements, etc.</li>
        <li>Mettez à jour vos informations à tout moment</li>
        <li>Augmentez votre visibilité gratuitement</li>
        <li>Contribuez activement au tourisme local</li>
      </ul>
    </div>

    <!-- Section procédure -->
    <div>
      <h2 class="text-2xl font-semibold text-gray-800 mb-4">Comment s'inscrire ?</h2>
      <p class="text-gray-700 mb-4">
        Remplissez simplement le formulaire ci-dessous. Après vérification par notre équipe, vous recevrez un accès à votre tableau de bord gestionnaire.
      </p>
      <p class="text-gray-700">
        Cette plateforme est dédiée à la promotion du patrimoine touristique béninois.
      </p>
    </div>
  </div>

  <!-- CTA -->
  <div class="mt-16 text-center">
    <a href="../gestionnaire/connexion.php" class="inline-block bg-blue-600 text-white text-lg font-semibold py-3 px-6 rounded-lg shadow-md hover:bg-blue-700 transition">
      👉 Je souhaite m'inscrire
    </a>
  </div>
</section>

<?php include('../includes/footer.php'); ?>
</body>
</html>