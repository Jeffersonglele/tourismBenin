<?php
session_start();
header('Content-Type: application/json');

// Récupérer les données JSON
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['transaction_id'])) {
    // Stocker l'ID de transaction dans la session
    $_SESSION['transaction_id'] = $data['transaction_id'];
    
    // Répondre avec succès
    echo json_encode(['success' => true]);
} else {
    // Répondre avec erreur
    echo json_encode(['success' => false, 'error' => 'ID de transaction manquant']);
}
?> 