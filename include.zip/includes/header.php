<?php
require_once(__DIR__ . "/../config/database.php");
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= isset($page_title) ? $page_title . ' - Bénin Tourisme' : 'Bénin Tourisme' ?></title>
    
    <!-- Favicon -->
    <link rel="icon" type="image/png" href="/ProjetBinome/assets/images/icon.png">
    
    <!-- CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/lightbox2@2.11.3/dist/css/lightbox.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#2F855A',
                        secondary: '#DD6B20',
                        dark: '#1A202C',
                    },
                    fontFamily: {
                        sans: ['Poppins', 'sans-serif'],
                    },
                }
            }
        }
    </script>

    <!-- Critical CSS (chargé en premier) -->
    <style>
        /* Reset minimal pour éviter le flash blanc */
        html {
            scroll-behavior: smooth;
        }
        
        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            color: #333;
            padding-top: 0; /* Ajusté pour la navbar fixed */
        }
        
        /* Pré-chargement des polices */
        @font-face {
            font-family: 'Poppins';
            font-style: normal;
            font-weight: 400;
            font-display: swap;
            src: local('Poppins Regular'), local('Poppins-Regular'),
                 url('https://fonts.gstatic.com/s/poppins/v15/pxiEyp8kv8JHgFVrJJfedw.ttf') format('truetype');
        }
        
        /* Styles de base pour la navbar */
        .navbar {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 50;
            background: rgba(255, 255, 255, 0.98);
            backdrop-filter: blur(8px);
            box-shadow: 0 2px 15px rgba(0,0,0,0.1);
            transform: translateY(0);
            transition: transform 0.3s ease;
        }
        
        /* Compensation pour le contenu sous la navbar */
        .content-wrapper {
            padding-top: 80px; /* Ajustez selon la hauteur de votre navbar */
        }
    </style>
</head>
<body class="antialiased">
    <!-- Navbar doit être incluse ici si elle n'est pas déjà dans le header -->
    
    <!-- Hero Section - Version corrigée -->
    <section class="hero-section relative" style="background-image: url('/ProjetBinome/assets/images/DASSA.png'); margin-top: -1px;">
        <div class="absolute inset-0 bg-gradient-to-b from-black/70 to-black/40"></div>
        <div class="relative z-10 max-w-4xl mx-auto px-4 h-screen flex flex-col justify-center items-center text-center">
            <h1 class="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6">Découvrez le Bénin</h1>
            <p class="text-xl md:text-2xl text-white mb-8 max-w-2xl">
                Explorez la richesse culturelle et la beauté naturelle du berceau du Vodoun
            </p>
            <div class="flex flex-col sm:flex-row gap-4 justify-center">
                <a href="/ProjetBinome/pages/destinations.php" 
                   class="bg-primary hover:bg-black-700 text-white font-bold py-3 px-8 rounded-full transition duration-300 no-underline">
                    Commencer l'aventure
                </a>
                <a href="/ProjetBinome/pages/reserve.php" 
                   class="border-2 border-white text-white hover:bg-black hover:text-gray-900 font-bold py-3 px-8 rounded-full transition duration-300 no-underline">
                    Réserver maintenant
                </a>
            </div>
        </div>
    </section>

    <!-- Le reste de votre contenu doit être wrappé dans -->
    <main class="content-wrapper">
        <!-- Votre contenu ici -->
    </main>

    <!-- Scripts JS -->
    <script>
        // Gestion du scroll pour la navbar
        document.addEventListener('DOMContentLoaded', function() {
            const navbar = document.querySelector('.navbar');
            let lastScroll = 0;
            
            window.addEventListener('scroll', function() {
                const currentScroll = window.pageYOffset;
                
                if (currentScroll <= 0) {
                    navbar.classList.remove('scrolled-up');
                    return;
                }
                
                if (currentScroll > lastScroll && !navbar.classList.contains('scrolled-down')) {
                    // Scroll vers le bas
                    navbar.classList.remove('scrolled-up');
                    navbar.classList.add('scrolled-down');
                } else if (currentScroll < lastScroll && navbar.classList.contains('scrolled-down')) {
                    // Scroll vers le haut
                    navbar.classList.remove('scrolled-down');
                    navbar.classList.add('scrolled-up');
                }
                
                lastScroll = currentScroll;
            });
        });
    </script>
</body>
</html>