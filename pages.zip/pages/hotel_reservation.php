<?php
session_start();
include_once("..\config\database.php");

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = $_SERVER['HTTP_REFERER'];
    header('Location: connexion.php');
    exit;
}

// Vérifier si c'est une requête POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hotel_id = isset($_POST['hotel_id']) ? (int)$_POST['hotel_id'] : 0;
    $chambre_id = isset($_POST['chambre_id']) ? (int)$_POST['chambre_id'] : 0;
    $date_arrivee = isset($_POST['date_arrivee']) ? $_POST['date_arrivee'] : '';
    $date_depart = isset($_POST['date_depart']) ? $_POST['date_depart'] : '';
    $nombre_personnes = isset($_POST['nombre_personnes']) ? (int)$_POST['nombre_personnes'] : 0;
    $telephone = isset($_POST['telephone']) ? $_POST['telephone'] : '';
    $commentaire = isset($_POST['commentaire']) ? $_POST['commentaire'] : '';
    
    // Debug - Enregistrer les données reçues
    error_log("Données reçues pour réservation hôtel : " . print_r($_POST, true));
    
    // Validation des données
    $errors = [];
    
    if ($hotel_id <= 0) {
        $errors[] = "Hôtel invalide";
    }

    if ($chambre_id <= 0) {
        $errors[] = "Veuillez sélectionner une chambre";
    }
    
    if (!strtotime($date_arrivee) || !strtotime($date_depart)) {
        $errors[] = "Dates invalides";
    }
    
    if (strtotime($date_arrivee) < strtotime('today')) {
        $errors[] = "La date d'arrivée ne peut pas être dans le passé";
    }
    
    if (strtotime($date_depart) <= strtotime($date_arrivee)) {
        $errors[] = "La date de départ doit être après la date d'arrivée";
    }
    
    if ($nombre_personnes <= 0) {
        $errors[] = "Nombre de personnes invalide";
    }

    if (empty($telephone)) {
        $errors[] = "Le numéro de téléphone est requis";
    }

    if (!preg_match("/^[0-9]{10}$/", $telephone)) {
        $errors[] = "Le numéro de téléphone doit contenir exactement 10 chiffres";
    }
    
    // Vérifier si la chambre existe et appartient à l'hôtel
    if ($hotel_id > 0 && $chambre_id > 0) {
        $stmt = $pdo->prepare("SELECT id, capacite FROM chambres WHERE id = ? AND hotel_id = ?");
        $stmt->execute([$chambre_id, $hotel_id]);
        $chambre = $stmt->fetch();
        
        if (!$chambre) {
            $errors[] = "Cette chambre n'est pas disponible";
        } else if ($nombre_personnes > $chambre['capacite']) {
            $errors[] = "Le nombre de personnes dépasse la capacité de la chambre";
        }
    }
    
    // Si pas d'erreurs, enregistrer la réservation
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            // Debug - Afficher les valeurs avant insertion
            error_log("Tentative d'insertion avec les valeurs suivantes:");
            error_log("user_id: " . $_SESSION['user_id']);
            error_log("email: " . $_SESSION['user_email']);
            error_log("hotel_id: " . $hotel_id);
            error_log("chambre_id: " . $chambre_id);
            error_log("date_arrivee: " . $date_arrivee);
            error_log("date_depart: " . $date_depart);
            error_log("nombre_personnes: " . $nombre_personnes);
            error_log("telephone: " . $telephone);

            // Insérer la réservation
            $sql = "INSERT INTO hotel_reservations (
                user_id, email, telephone, hotel_id, chambre_id,
                date_arrivee, date_depart, nombre_personnes,
                commentaire, date_reservation, statut
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NOW(), 'en_attente')";
            
            $stmt = $pdo->prepare($sql);
            $result = $stmt->execute([
                $_SESSION['user_id'],
                $_SESSION['user_email'],
                $telephone,
                $hotel_id,
                $chambre_id,
                $date_arrivee,
                $date_depart,
                $nombre_personnes,
                $commentaire
            ]);

            if (!$result) {
                throw new PDOException("Échec de l'insertion dans hotel_reservations: " . implode(" ", $stmt->errorInfo()));
            }

            $pdo->commit();
            
            // Envoyer un email de confirmation
            $to = $_SESSION['user_email'];
            $subject = "Confirmation de réservation d'hôtel - Bénin Tourisme";
            $message = "Cher(e) {$_SESSION['user_prenom']} {$_SESSION['user_nom']},\n\n";
            $message .= "Nous avons bien reçu votre réservation d'hôtel.\n";
            $message .= "Date d'arrivée : " . date('d/m/Y', strtotime($date_arrivee)) . "\n";
            $message .= "Date de départ : " . date('d/m/Y', strtotime($date_depart)) . "\n";
            $message .= "Nombre de personnes : $nombre_personnes\n\n";
            $message .= "Notre équipe va traiter votre demande dans les plus brefs délais.\n\n";
            $message .= "Cordialement,\nL'équipe Bénin Tourisme";
            $headers = "From: noreply@benintourisme.com";

            mail($to, $subject, $message, $headers);
            
            $_SESSION['success_message'] = "Votre réservation a été enregistrée avec succès !";
            header('Location: mes_reservations.php');
            exit;
            
        } catch (PDOException $e) {
            $pdo->rollBack();
            $errors[] = "Une erreur est survenue lors de l'enregistrement de votre réservation: " . $e->getMessage();
            error_log("Erreur PDO détaillée : " . $e->getMessage());
            error_log("Trace complète : " . $e->getTraceAsString());
        }
    }
    
    // S'il y a des erreurs, les stocker en session et rediriger
    if (!empty($errors)) {
        $_SESSION['error_messages'] = $errors;
        error_log("Erreurs de validation hôtel : " . print_r($errors, true));
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    }
} else {
    // Si ce n'est pas une requête POST, rediriger vers la page des hôtels
    error_log("Tentative d'accès direct à hotel_reservation.php");
    header('Location: hotels.php');
    exit;
}
?> 