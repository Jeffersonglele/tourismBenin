<?php
session_start();
include_once("..\config\database.php");
include_once(__DIR__ . "/../includes/navbargest.php");
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Destinations - Bénin Tourisme</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        window.onload = () => {
            lucide.createIcons();
        };
    </script>
</head>
<style>
        .hero-section {
            height: 60vh;
            background-size: cover;
            background-position: center;
        }
        .hero-overlay {
            background: rgba(0, 0, 0, 0.5);
        }
        .hero-title {
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .hero-subtitle {
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }
</style>
<section class="hero-section relative" style="background-image: url('../assets/images/cir.jpeg');">
        <div class="hero-overlay absolute inset-0"></div>
        <div class="hero-content relative z-10 flex flex-col justify-center h-full px-8">
            <h1 class="hero-title text-4xl md:text-5xl font-bold text-white mb-4 animate-fade-in text-center">
            Proposez Votre circuit 
            </h1>
            <p class="hero-subtitle text-xl text-white animate-fade-in" style="animation-delay: 0.2s">
                
                
            </p>
        </div>
</section>
<section class="py-16 bg-gray-50">
    <div class="container mx-auto px-4">
        <div class="flex flex-col lg:flex-row gap-8">
            <!-- Informations principales -->
            <div class="lg:w-2/3">
                <div class="info-card bg-white rounded-xl p-8 mb-8">
                    <h2 class="text-2xl font-bold text-gray-800 mb-6">Proposez votre circuit touristique dès aujourd’hui !</h2>
                    <h5 class="text-1xl font-sans text-gray-800 mb-2">
                                Vous êtes guide, agence de voyage ou gestionnaire d’un circuit touristique au Bénin ?
            Vous connaissez des lieux uniques, des expériences authentiques ou des parcours captivants qui méritent d’être découverts ?

            Rejoignez notre plateforme "Benin Découverte" et faites rayonner votre offre auprès de milliers de visiteurs !

            Nous vous offrons la possibilité de référencer gratuitement vos circuits touristiques. Il vous suffit de remplir le formulaire ci-dessous en détaillant votre parcours, les activités proposées, les lieux visités, les tarifs, et vos coordonnées. Notre équipe validera ensuite votre proposition pour la mettre en ligne.

            👉 Profitez de cette opportunité pour gagner en visibilité, attirer plus de touristes et contribuer à la promotion du patrimoine béninois.

            📝 Remplissez dès maintenant le formulaire d’inscription et faites découvrir votre circuit au monde entier !


                    
                    </h5>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="lg:w-1/3">
                <div class="sticky top-8 bg-white p-8 rounded-xl shadow-lg">
                    <h2 class="text-2xl font-bold mb-6 text-gray-800 text-center">Ajouter un circuit</h2>

                    <form action="traitement_circuit.php" method="POST" enctype="multipart/form-data" class="space-y-6">
                    <!-- Nom -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="map-pin" class="w-5 h-5"></i> Nom
                        </label>
                        <input type="text" name="nom" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300" required>
                    </div>

                    <!-- Sous-titre -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="type" class="w-5 h-5"></i> Sous-titre
                        </label>
                        <input type="text" name="sous_titre" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300">
                    </div>

                    <!-- Description courte -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="file-text" class="w-5 h-5"></i> Description courte
                        </label>
                        <textarea name="description_courte" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300" rows="2"></textarea>
                    </div>

                    <!-- Description longue -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="file-text" class="w-5 h-5"></i> Description longue
                        </label>
                        <textarea name="description_longue" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300" rows="4"></textarea>
                    </div>

                    <!-- Itinéraires -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="navigation" class="w-5 h-5"></i> Itinéraires
                        </label>
                        <input type="text" name="itineraires" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300">
                    </div>

                    <!-- Villes visitées -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="map" class="w-5 h-5"></i> Villes visitées
                        </label>
                        <input type="text" name="villes_visitees" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300">
                    </div>

                    <!-- Prix -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="dollar-sign" class="w-5 h-5"></i> Prix
                        </label>
                        <input type="number" name="prix" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300" step="0.01">
                    </div>

                    <!-- Durée -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="clock" class="w-5 h-5"></i> Durée (ex: 3 jours)
                        </label>
                        <input type="text" name="duree" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300">
                    </div>

                    <!-- Taille groupe -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="users" class="w-5 h-5"></i> Taille du groupe
                        </label>
                        <input type="number" name="taille_groupe" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300">
                    </div>

                    <!-- Lieu de départ -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="map-pin" class="w-5 h-5"></i> Lieu de départ
                        </label>
                        <input type="text" name="lieu_depart" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300">
                    </div>

                    <!-- Image -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="image" class="w-5 h-5"></i> Image
                        </label>
                        <input type="file" name="image" class="w-full border px-4 py-2 rounded-lg">
                    </div>

                    <!-- Type -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="tag" class="w-5 h-5"></i> Type
                        </label>
                        <select name="type" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300">
                            <option value="">Choisir un type</option>
                            <option value="Culturel">Culturel</option>
                            <option value="Aventure">Aventure</option>
                            <option value="Historique">Historique</option>
                            <option value="Nature">Nature</option>
                        </select>
                    </div>

                    <!-- Téléphone -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="phone" class="w-5 h-5"></i> Téléphone
                        </label>
                        <input type="tel" name="tel" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300">
                    </div>

                    <!-- Inclus -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="check-circle" class="w-5 h-5"></i> Inclus
                        </label>
                        <textarea name="inclus" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300" rows="2"></textarea>
                    </div>

                    <!-- Non inclus -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="x-circle" class="w-5 h-5"></i> Non inclus
                        </label>
                        <textarea name="non_inclus" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300" rows="2"></textarea>
                    </div>

                    <!-- Places disponibles -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="list" class="w-5 h-5"></i> Places disponibles
                        </label>
                        <input type="number" name="places_disponibles" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300">
                    </div>

                    <!-- Site -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="globe" class="w-5 h-5"></i> Site web
                        </label>
                        <input type="url" name="site" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300">
                    </div>

                    <!-- Email -->
                    <div>
                        <label class="block font-semibold mb-1 flex items-center gap-2">
                            <i data-lucide="mail" class="w-5 h-5"></i> Email
                        </label>
                        <input type="email" name="email" class="w-full border px-4 py-2 rounded-lg focus:ring focus:ring-blue-300">
                    </div>

                    <!-- Bouton submit -->
                    <div class="text-center">
                        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition">
                            <i data-lucide="send" class="inline-block w-5 h-5 mr-2"></i>Envoyer
                        </button>
                    </div>
                </form>
                </div>
            </div>
        </div>
    </div>
</section>




<?php
include_once( "../includes/footergest.php");?>
</body>
</html>

