<?php
session_start();
include_once("..\config\database.php");

// Récupération de l'ID de l'hôtel
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Récupération des détails de l'hôtel
$sql = "SELECT * FROM hotels WHERE id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$id]);
$hotel = $stmt->fetch();

// Récupération des chambres disponibles pour cet hôtel
$sql_chambres = "SELECT * FROM chambres WHERE hotel_id = ? ORDER BY prix ASC";
$stmt_chambres = $pdo->prepare($sql_chambres);
$stmt_chambres->execute([$id]);
$chambres = $stmt_chambres->fetchAll();

// Redirection si l'hôtel n'existe pas
if (!$hotel) {
    header('Location: hotel.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($hotel['nom']) ?> - Bénin Tourisme</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .hotel-header {
            position: relative;
            height: 60vh;
            background-size: cover;
            background-position: center;
            color: white;
        }
        .header-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.7));
            display: flex;
            align-items: flex-end;
            padding: 2rem 0;
        }
        .rating {
            color: #ffc107;
            font-size: 1.2rem;
        }
        .amenity-icon {
            width: 40px;
            height: 40px;
            background: #f8f9fa;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 0.5rem;
            color: #0d6efd;
        }
        .booking-card {
            position: sticky;
            top: 2rem;
        }
        .gallery-img {
            height: 200px;
            object-fit: cover;
            cursor: pointer;
            transition: transform 0.3s;
        }
        .gallery-img:hover {
            transform: scale(1.05);
        }
        .price-tag {
            font-size: 2rem;
            color: #0d6efd;
            font-weight: bold;
        }
        .review-card {
            border-left: 4px solid #0d6efd;
        }
    </style>
</head>
<body>
    <?php include_once(__DIR__ . "/../includes/navbar.php"); ?>

    <!-- En-tête de l'hôtel -->
    <header class="hotel-header" style="background-image: url('<?= htmlspecialchars($hotel['image']) ?>');">
        <div class="header-overlay">
            <div class="container">
                <div class="row">
                    <div class="col-lg-8">
                        <h1 class="display-4 mb-3"><?= htmlspecialchars($hotel['nom']) ?></h1>
                        <div class="rating mb-3">
                            <?php
                            $etoiles = $hotel['etoiles'];
                            $pleines = floor($etoiles);
                            $demi = ($etoiles - $pleines) >= 0.5;
                            
                            for ($i = 0; $i < $pleines; $i++) {
                                echo '<i class="fas fa-star"></i>';
                            }
                            if ($demi) {
                                echo '<i class="fas fa-star-half-alt"></i>';
                            }
                            for ($i = ceil($etoiles); $i < 5; $i++) {
                                echo '<i class="far fa-star"></i>';
                            }
                            ?>
                        </div>
                        <p class="lead mb-0">
                            <i class="fas fa-map-marker-alt me-2"></i>
                            <?= htmlspecialchars($hotel['ville']) ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Contenu principal -->
    <div class="container py-5">
        <div class="row">
            <!-- Informations principales -->
            <div class="col-lg-8">
                <!-- Description -->
                <section class="mb-5">
                    <h2 class="h4 mb-4">À propos de l'hôtel</h2>
                    <p class="lead"><?= htmlspecialchars($hotel['description']) ?></p>
                </section>

                <!-- Équipements -->
                <section class="mb-5">
                    <h2 class="h4 mb-4">Équipements et services</h2>
                    <div class="row g-4">
                        <div class="col-6 col-md-3 text-center">
                            <div class="amenity-icon mx-auto">
                                <i class="fas fa-wifi"></i>
                            </div>
                            <p class="mb-0">WiFi gratuit</p>
                        </div>
                        <div class="col-6 col-md-3 text-center">
                            <div class="amenity-icon mx-auto">
                                <i class="fas fa-swimming-pool"></i>
                            </div>
                            <p class="mb-0">Piscine</p>
                        </div>
                        <div class="col-6 col-md-3 text-center">
                            <div class="amenity-icon mx-auto">
                                <i class="fas fa-parking"></i>
                            </div>
                            <p class="mb-0">Parking gratuit</p>
                        </div>
                        <div class="col-6 col-md-3 text-center">
                            <div class="amenity-icon mx-auto">
                                <i class="fas fa-utensils"></i>
                            </div>
                            <p class="mb-0">Restaurant</p>
                        </div>
                    </div>
                </section>

                <!-- Galerie photos -->
                <section class="mb-5">
                    <h2 class="h4 mb-4">Galerie photos</h2>
                    <div class="row g-3">
                        <div class="col-md-4">
                            <img src="<?= htmlspecialchars($hotel['image']) ?>" class="img-fluid rounded gallery-img" alt="Vue de l'hôtel">
                        </div>
                       
                        <!-- Ajoutez plus d'images ici -->
                    </div>
                </section>
            </div>

            <!-- Carte de réservation -->
            <div class="col-lg-4">
                <div class="card booking-card shadow-sm" id="reservation">
                    <div class="card-body">
                        <h3 class="card-title mb-4">Réserver une chambre</h3>
                        <div class="price-tag mb-4">
                            À partir de <?= number_format($hotel['prix_min'], 0, ',', ' ') ?>€
                            <small class="text-muted">/nuit</small>
                        </div>
                        
                        <?php if (isset($_SESSION['user_id'])): ?>
                            <!-- Formulaire de réservation pour utilisateurs connectés -->
                            <form action="hotel_reservation.php" method="POST" id="reservationForm">
                                <input type="hidden" name="hotel_id" value="<?= $hotel['id'] ?>">
                                
                                <!-- Sélection de la chambre -->
                                <div class="mb-3">
                                    <label class="form-label">Type de chambre</label>
                                    <select class="form-select" name="chambre_id" required id="chambreSelect">
                                        <option value="">Choisissez une chambre</option>
                                        <?php foreach ($chambres as $chambre): ?>
                                            <option value="<?= $chambre['id'] ?>" data-prix="<?= $chambre['prix'] ?>" data-max-personnes="<?= $chambre['capacite'] ?>">
                                                <?= htmlspecialchars($chambre['type']) ?> - 
                                                <?= number_format($chambre['prix'], 0, ',', ' ') ?>€/nuit - 
                                                Max <?= $chambre['capacite'] ?> pers.
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label">Date d'arrivée</label>
                                    <input type="date" class="form-control" name="date_arrivee" required 
                                           min="<?= date('Y-m-d') ?>" 
                                           value="<?= date('Y-m-d') ?>"
                                           id="dateArrivee">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Date de départ</label>
                                    <input type="date" class="form-control" name="date_depart" required
                                           min="<?= date('Y-m-d', strtotime('+1 day')) ?>"
                                           value="<?= date('Y-m-d', strtotime('+1 day')) ?>"
                                           id="dateDepart">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Nombre de personnes</label>
                                    <select class="form-select" name="nombre_personnes" required id="nombrePersonnes">
                                        <option value="1">1 personne</option>
                                        <option value="2" selected>2 personnes</option>
                                        <option value="3">3 personnes</option>
                                        <option value="4">4 personnes</option>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Téléphone</label>
                                    <input type="tel" class="form-control" name="telephone" required
                                           pattern="[0-9]{10}" title="Veuillez entrer un numéro de téléphone valide (10 chiffres)">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Commentaires (optionnel)</label>
                                    <textarea class="form-control" name="commentaire" rows="3"></textarea>
                                </div>

                                <!-- Résumé de la réservation -->
                                <div class="card mb-3 bg-light">
                                    <div class="card-body">
                                        <h5 class="card-title">Résumé de la réservation</h5>
                                        <div id="resumePrix" class="d-none">
                                            <p class="mb-2">Prix par nuit: <span id="prixParNuit">0</span>€</p>
                                            <p class="mb-2">Nombre de nuits: <span id="nombreNuits">0</span></p>
                                            <p class="mb-0 fw-bold">Prix total: <span id="prixTotal">0</span>€</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" id="conditions" required>
                                        <label class="form-check-label" for="conditions">
                                            J'accepte les conditions de réservation
                                        </label>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary w-100 btn-lg">
                                    <i class="fas fa-calendar-check me-2"></i>Réserver maintenant
                                </button>
                            </form>

                            <?php if (isset($_SESSION['error_messages']) && !empty($_SESSION['error_messages'])): ?>
                                <div class="alert alert-danger mt-3">
                                    <?php 
                                    foreach ($_SESSION['error_messages'] as $error) {
                                        echo "<p class='mb-0'><i class='fas fa-exclamation-circle me-2'></i>$error</p>";
                                    }
                                    unset($_SESSION['error_messages']);
                                    ?>
                                </div>
                            <?php endif; ?>

                            <script>
                            document.addEventListener('DOMContentLoaded', function() {
                                const form = document.getElementById('reservationForm');
                                const chambreSelect = document.getElementById('chambreSelect');
                                const nombrePersonnes = document.getElementById('nombrePersonnes');
                                const dateArrivee = document.getElementById('dateArrivee');
                                const dateDepart = document.getElementById('dateDepart');
                                const resumePrix = document.getElementById('resumePrix');
                                const prixParNuitElement = document.getElementById('prixParNuit');
                                const nombreNuitsElement = document.getElementById('nombreNuits');
                                const prixTotalElement = document.getElementById('prixTotal');

                                function updatePrixTotal() {
                                    if (chambreSelect.value && dateArrivee.value && dateDepart.value) {
                                        const selectedOption = chambreSelect.options[chambreSelect.selectedIndex];
                                        const prixParNuit = parseInt(selectedOption.dataset.prix);
                                        const debut = new Date(dateArrivee.value);
                                        const fin = new Date(dateDepart.value);
                                        const nombreNuits = Math.ceil((fin - debut) / (1000 * 60 * 60 * 24));
                                        
                                        if (nombreNuits > 0) {
                                            const prixTotal = prixParNuit * nombreNuits;
                                            prixParNuitElement.textContent = prixParNuit;
                                            nombreNuitsElement.textContent = nombreNuits;
                                            prixTotalElement.textContent = prixTotal;
                                            resumePrix.classList.remove('d-none');
                                        }
                                    }
                                }

                                // Mettre à jour les options de nombre de personnes en fonction de la chambre
                                chambreSelect.addEventListener('change', function() {
                                    const selectedOption = this.options[this.selectedIndex];
                                    const maxPersonnes = parseInt(selectedOption.dataset.maxPersonnes) || 4;
                                    
                                    // Réinitialiser les options
                                    nombrePersonnes.innerHTML = '';
                                    
                                    // Ajouter les nouvelles options
                                    for (let i = 1; i <= maxPersonnes; i++) {
                                        const option = document.createElement('option');
                                        option.value = i;
                                        option.text = i === 1 ? '1 personne' : i + ' personnes';
                                        if (i === 2) option.selected = true;
                                        nombrePersonnes.appendChild(option);
                                    }
                                    
                                    updatePrixTotal();
                                });

                                // Mettre à jour le prix total quand les dates changent
                                dateArrivee.addEventListener('change', updatePrixTotal);
                                dateDepart.addEventListener('change', updatePrixTotal);

                                form.addEventListener('submit', function(e) {
                                    const dateDebut = new Date(dateArrivee.value);
                                    const dateFin = new Date(dateDepart.value);
                                    const today = new Date();
                                    today.setHours(0, 0, 0, 0);

                                    if (!chambreSelect.value) {
                                        e.preventDefault();
                                        alert("Veuillez sélectionner une chambre");
                                        return;
                                    }

                                    if (dateDebut < today) {
                                        e.preventDefault();
                                        alert("La date d'arrivée ne peut pas être dans le passé");
                                        return;
                                    }

                                    if (dateFin <= dateDebut) {
                                        e.preventDefault();
                                        alert("La date de départ doit être après la date d'arrivée");
                                        return;
                                    }

                                    const telephone = this.telephone.value;
                                    if (!/^[0-9]{10}$/.test(telephone)) {
                                        e.preventDefault();
                                        alert("Le numéro de téléphone doit contenir exactement 10 chiffres");
                                        return;
                                    }

                                    const selectedOption = chambreSelect.options[chambreSelect.selectedIndex];
                                    const maxPersonnes = parseInt(selectedOption.dataset.maxPersonnes);
                                    const nbPersonnes = parseInt(nombrePersonnes.value);
                                    
                                    if (nbPersonnes > maxPersonnes) {
                                        e.preventDefault();
                                        alert(`Cette chambre ne peut accueillir que ${maxPersonnes} personnes maximum`);
                                        return;
                                    }
                                });
                            });
                            </script>
                        <?php else: ?>
                            <!-- Message pour utilisateurs non connectés -->
                            <div class="text-center">
                                <p class="alert alert-info">
                                    <i class="fas fa-info-circle me-2"></i>
                                    Vous devez être connecté pour effectuer une réservation
                                </p>
                                <a href="connexion.php?redirect=<?= urlencode($_SERVER['REQUEST_URI'] . '#reservation') ?>" 
                                   class="btn btn-primary btn-lg w-100">
                                    <i class="fas fa-sign-in-alt me-2"></i>Se connecter
                                </a>
                                <p class="mt-3 text-muted">
                                    Pas encore de compte ? 
                                    <a href="inscription.php" class="text-decoration-none">S'inscrire</a>
                                </p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include_once(__DIR__ . "/../includes/footer.php"); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 