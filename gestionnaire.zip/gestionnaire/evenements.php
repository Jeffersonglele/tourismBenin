<?php
session_start();
include_once("..\config\database.php");
include_once(__DIR__ . "/../includes/navbargest.php");
// Après l'ajout réussi
header("Location: tableau_bord.php?success=1&type=destination");
exit();


?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Destinations - Bénin Tourisme</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
</head>
<style>
        .hero-section {
            height: 60vh;
            background-size: cover;
            background-position: center;
        }
        .hero-overlay {
            background: rgba(0, 0, 0, 0.5);
        }
        .hero-title {
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .hero-subtitle {
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }
</style>
<section class="hero-section relative" style="background-image: url('../assets/images/ev.jpeg');">
        <div class="hero-overlay absolute inset-0"></div>
        <div class="hero-content relative z-10 flex flex-col justify-center h-full px-8">
            <h1 class="hero-title text-4xl md:text-5xl font-bold text-white mb-4 animate-fade-in text-center">
            Proposez un évènement 
            </h1>
            <p class="hero-subtitle text-xl text-white animate-fade-in" style="animation-delay: 0.2s">
                
                
            </p>
        </div>
</section>
<section class="py-16 bg-gray-50">
    <div class="container mx-auto px-4">
        <div class="flex flex-col lg:flex-row gap-8">
            <!-- Informations principales -->
            <div class="lg:w-2/3">
                <div class="info-card bg-white rounded-xl p-8 mb-8">
                    <h2 class="text-2xl font-bold text-gray-800 mb-6">Proposez vos Événements Touristiques !</h2>
                    <h5 class="text-1xl font-sans text-gray-800 mb-2">
                    Vous êtes organisateur ou gestionnaire d’un événement culturel, touristique, festif ou artistique ?
                    Vous connaissez un festival, une exposition, une célébration traditionnelle ou toute autre activité capable d’attirer les visiteurs dans votre région ?

                    Partagez-le avec nous !

                    Nous vous offrons la possibilité d’inscrire gratuitement vos événements sur notre plateforme pour leur donner plus de visibilité auprès des touristes et passionnés de découvertes.

                    👉 Remplissez simplement le formulaire ci-dessous pour nous proposer un événement.

                    Qu’il s’agisse d’un festival local, d’un marché artisanal, d’un spectacle ou d’un événement historique, votre contribution aide à faire rayonner la richesse culturelle de notre territoire.

                    🔗 Ajouter un événement via le formulaire

                    Merci de participer à la promotion du tourisme local !
                    
                    </h5>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="lg:w-1/3">
                <div class="sticky top-8 bg-white p-8 rounded-xl shadow-lg">
                    <h2 class="text-2xl font-bold mb-6 text-gray-800 text-center">Ajouter un hotel</h2>

                    <form action="traitement_evenement.php" method="POST" enctype="multipart/form-data" class="space-y-5">
      
                <!-- Nom -->
                <div>
                    <label class="block text-sm font-medium mb-1 flex items-center">
                    <i data-lucide="type" class="w-5 h-5 mr-2"></i> Nom de l'événement
                    </label>
                    <input type="text" name="nom" required class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>
                
                <!-- Description -->
                <div>
                    <label class="block text-sm font-medium mb-1 flex items-center">
                    <i data-lucide="file-text" class="w-5 h-5 mr-2"></i> Description
                    </label>
                    <textarea name="description" rows="3" required class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500"></textarea>
                </div>
                
                <!-- Dates et Heure -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                    <label class="block text-sm font-medium mb-1 flex items-center">
                        <i data-lucide="calendar" class="w-5 h-5 mr-2"></i> Date de début
                    </label>
                    <input type="date" name="date_debut" required class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                    <label class="block text-sm font-medium mb-1 flex items-center">
                        <i data-lucide="calendar" class="w-5 h-5 mr-2"></i> Date de fin
                    </label>
                    <input type="date" name="date_fin" required class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                    <div>
                    <label class="block text-sm font-medium mb-1 flex items-center">
                        <i data-lucide="clock" class="w-5 h-5 mr-2"></i> Heure
                    </label>
                    <input type="time" name="heure" required class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
                    </div>
                </div>

                <!-- Ville -->
                <div>
                    <label class="block text-sm font-medium mb-1 flex items-center">
                    <i data-lucide="map-pin" class="w-5 h-5 mr-2"></i> Ville
                    </label>
                    <input type="text" name="ville" required class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>

                <!-- Prix -->
                <div>
                    <label class="block text-sm font-medium mb-1 flex items-center">
                    <i data-lucide="dollar-sign" class="w-5 h-5 mr-2"></i> Prix
                    </label>
                    <input type="number" name="prix" min="0" step="0.01" required class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>

                <!-- Image -->
                <div>
                    <label class="block text-sm font-medium mb-1 flex items-center">
                    <i data-lucide="image" class="w-5 h-5 mr-2"></i> Image (affiche ou bannière)
                    </label>
                    <input type="file" name="image" accept="image/*" required class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>

                <!-- Site -->
                <div>
                    <label class="block text-sm font-medium mb-1 flex items-center">
                    <i data-lucide="globe" class="w-5 h-5 mr-2"></i> Site web (facultatif)
                    </label>
                    <input type="url" name="site" placeholder="https://example.com" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>

                <!-- Phrase d'incitation -->
                <div>
                    <label class="block text-sm font-medium mb-1 flex items-center">
                    <i data-lucide="megaphone" class="w-5 h-5 mr-2"></i> Phrase d'incitation
                    </label>
                    <input type="text" name="incitation" placeholder="Ne manquez pas cet événement unique !" required class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500">
                </div>

                <!-- Bouton -->
                <div class="text-center pt-4">
                    <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition">
                    <i data-lucide="plus" class="inline w-5 h-5 mr-1"></i> Ajouter
                    </button>
                </div>

                </form>
                </div>
            </div>
        </div>
    </div>
</section>




<?php
include_once( "../includes/footergest.php");?>
</body>
</html>
