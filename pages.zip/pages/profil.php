<?php
session_start();
require_once '../config/database.php';

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header('Location: connexion.php');
    exit();
}

// Récupérer les informations de l'utilisateur
$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Profil - Bénin Tourisme</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .profile-header {
            background: linear-gradient(135deg, #1a365d 0%, #2d3748 100%);
        }
        .profile-card {
            backdrop-filter: blur(10px);
            background-color: rgba(255, 255, 255, 0.9);
        }
    </style>
</head>
<body class="bg-gray-50">
    <?php include '../includes/navbar.php'; ?>

    <!-- En-tête du profil -->
    <div class="profile-header text-white py-20">
        <div class="container mx-auto px-4">
            <div class="flex items-center space-x-6">
                <div class="relative">
                    <img src="<?= $base_path ?>assets/images/users.jpg" 
                         alt="Photo de profil" 
                         class="w-32 h-32 rounded-full border-4 border-white shadow-lg object-cover"
                         onerror="this.src='<?= $base_path ?>assets/images/default-user.png'">
                    <button class="absolute bottom-0 right-0 bg-primary text-white p-2 rounded-full shadow-lg hover:bg-primary-dark transition-colors">
                        <i class="fas fa-camera"></i>
                    </button>
                </div>
                <div>
                    <h1 class="text-3xl font-bold"><?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?></h1>
                    <p class="text-gray-300 mt-1"><?= htmlspecialchars($user['email']) ?></p>
                    <p class="text-gray-300 mt-1">Membre depuis <?= date('F Y', strtotime($user['date_inscription'])) ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Contenu principal -->
    <div class="container mx-auto px-4 py-8">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Informations personnelles -->
            <div class="profile-card rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-semibold mb-4 text-gray-800">Informations personnelles</h2>
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-600">Nom complet</label>
                        <p class="mt-1 text-gray-800"><?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?></p>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-600">Email</label>
                        <p class="mt-1 text-gray-800"><?= htmlspecialchars($user['email']) ?></p>
                    </div>
                    <button class="w-full mt-4 bg-primary text-black py-2 px-4 rounded-md hover:bg-primary-dark transition-colors">
                        Modifier mes informations
                    </button>
                </div>
            </div>

            <!-- Préférences -->
            <div class="profile-card rounded-lg shadow-lg p-6">
                <h2 class="text-xl font-semibold mb-4 text-gray-800">Mes préférences</h2>
                <div class="space-y-4">
                    <div>
                        <label class="block text-sm font-medium text-gray-600">Type de voyage préféré</label>
                        <div class="mt-2 flex flex-wrap gap-2">
                            <span class="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Culturel</span>
                            <span class="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Nature</span>
                            <span class="px-3 py-1 bg-primary/10 text-primary rounded-full text-sm">Plage</span>
                        </div>
                    </div>
                    <div>
                        <label class="block text-sm font-medium text-gray-600">Budget moyen</label>
                        <p class="mt-1 text-gray-800">(Personnelle)</p>
                    </div>
                    <button class="w-full mt-4 bg-gray-100 text-gray-700 py-2 px-4 rounded-md hover:bg-gray-200 transition-colors">
                        Modifier mes préférences
                    </button>
                </div>
            </div>
        </div>
    </div>
</body>
</html> 