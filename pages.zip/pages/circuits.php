<?php
session_start();
include_once( "../config/database.php");

// Récupérer les circuits depuis la base de données avec les filtres
$sql = "SELECT * FROM circuits";
$params = [];
$where = [];

if (isset($_GET['duree']) && !empty($_GET['duree'])) {
    switch($_GET['duree']) {
        case '1-2':
            $where[] = "duree BETWEEN 1 AND 2";
            break;
        case '3-5':
            $where[] = "duree BETWEEN 3 AND 5";
            break;
        case '6-7':
            $where[] = "duree BETWEEN 6 AND 7";
            break;
        case '8+':
            $where[] = "duree >= 8";
            break;
    }
}

if (isset($_GET['type']) && !empty($_GET['type'])) {
    $where[] = "type = ?";
    $params[] = $_GET['type'];
}

if (isset($_GET['budget']) && !empty($_GET['budget'])) {
    switch($_GET['budget']) {
        case 'economique':
            $where[] = "prix < 100000";
            break;
        case 'standard':
            $where[] = "prix BETWEEN 100000 AND 200000";
            break;
        case 'luxe':
            $where[] = "prix > 200000";
            break;
    }
}

if (!empty($where)) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$sql .= " ORDER BY prix ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$circuits = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Circuits Touristiques - Bénin Tourisme</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Poppins', sans-serif;
        }
        
        .btn-reserve {
            background: #e67e22;
            color: white;
            padding: 1rem 2rem;
            border-radius: 30px;
            text-decoration: none;
            display: block;
            text-align: center;
            font-weight: bold;
            transition: all 0.3s ease;
        }
    </style>
</head>
<body class="bg-gray-50 text-gray-800">
    <?php include('../includes/navbar.php'); ?>

    <!-- Hero Section -->
    <section 
        class="relative bg-cover bg-center min-h-[60vh] flex items-center justify-center mb-12"
        style="background-image: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('../assets/images/circuit.jpeg');"
    >
        <div class="text-center max-w-3xl px-4">
            <h1 class="text-white text-4xl md:text-5xl font-bold mb-4 drop-shadow-lg" data-aos="fade-up">Circuits Touristiques</h1>
            <p class="text-xl text-white mb-2" data-aos="fade-up" data-aos-delay="100">
                Découvrez le Bénin authentique avec nos circuits guidés
            </p>
            <p class="text-white/90 text-lg md:text-xl mb-2 drop-shadow" data-aos="fade-up" data-aos-delay="200">
                Des expériences uniques à travers le pays
            </p>
        </div>
    </section>

    <main class="container mx-auto px-4 md:px-8 lg:px-12 flex flex-col md:flex-row gap-8">

    <!-- Circuits Section -->
    <section class="py-16">
        <div class="container mx-auto px-4">
            <div class="flex flex-col lg:flex-row gap-8">
                <!-- Filtres -->
                <aside class="md:w-1/4 bg-white rounded-lg shadow p-6 sticky top-6 h-fit">
                    <h2 class="text-xl font-semibold mb-6">Affiner votre recherche</h2>
                    <form method="GET" id="filterForm" class="space-y-5">
                            <div>
                                <label class="block mb-1 font-medium">Durée</label>
                                <select name="duree" class="w-full rounded-md border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    <option value="">Toutes les durées</option>
                                    <option value="1-2" <?= (isset($_GET['duree']) && $_GET['duree'] === '1-2') ? 'selected' : '' ?>>1-2 jours</option>
                                    <option value="3-5" <?= (isset($_GET['duree']) && $_GET['duree'] === '3-5') ? 'selected' : '' ?>>3-5 jours</option>
                                    <option value="6-7" <?= (isset($_GET['duree']) && $_GET['duree'] === '6-7') ? 'selected' : '' ?>>6-7 jours</option>
                                    <option value="8+" <?= (isset($_GET['duree']) && $_GET['duree'] === '8+') ? 'selected' : '' ?>>8 jours et plus</option>
                                </select>
                            </div>
                            <div>
                                <label class="block mb-1 font-medium">Type de circuit</label>
                                <select name="type" class="w-full rounded-md border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                                    <option value="">Tous les types</option>
                                    <option value="culturel" <?= (isset($_GET['type']) && $_GET['type'] === 'culturel') ? 'selected' : '' ?>>Circuit culturel</option>
                                    <option value="aventure" <?= (isset($_GET['type']) && $_GET['type'] === 'aventure') ? 'selected' : '' ?>>Circuit aventure</option>
                                    <option value="nature" <?= (isset($_GET['type']) && $_GET['type'] === 'nature') ? 'selected' : '' ?>>Circuit nature</option>
                                    <option value="historique" <?= (isset($_GET['type']) && $_GET['type'] === 'historique') ? 'selected' : '' ?>>Circuit historique</option>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label class="block mb-1 font-medium">Budget</label>
                                <select class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500" name="budget">
                                    <option value="">Tous les budgets</option>
                                    <option value="economique" <?= (isset($_GET['budget']) && $_GET['budget'] === 'economique') ? 'selected' : '' ?>>Économique (< 100 000 FCFA)</option>
                                    <option value="standard" <?= (isset($_GET['budget']) && $_GET['budget'] === 'standard') ? 'selected' : '' ?>>Standard (100 000 - 200 000 FCFA)</option>
                                    <option value="luxe" <?= (isset($_GET['budget']) && $_GET['budget'] === 'luxe') ? 'selected' : '' ?>>Luxe (> 200 000 FCFA)</option>
                                </select>
                            </div>
                            <div class="flex flex-col gap-2">
                                <button type="submit" class="bg-indigo-600 text-white font-semibold py-2 rounded hover:bg-indigo-700 transition">
                                    <i class="fas fa-filter mr-2"></i>Filtrer
                                </button>
                                <a href="circuits.php" class="text-center text-indigo-600 border border-indigo-600 rounded py-2 hover:text-white transition">
                                    <i class="fas fa-undo mr-2"></i>Réinitialiser
                                </a>
                            </div>
                        </form>

                        <?php if (!empty($_GET)): ?>
                        <div class="mt-6">
                            <h3 class="text-lg font-semibold mb-3">Filtres actifs :</h5>
                            <div class="flex flex-wrap gap-2">
                                <?php if (!empty($_GET['duree'])): ?>
                                    <span class="bg-indigo-100 text-indigo-700 rounded-full px-3 py-1 text-sm font-medium">
                                        Durée: <?php
                                            switch($_GET['duree']) {
                                                case '1-2':
                                                    echo '1-2 jours';
                                                    break;
                                                case '3-5':
                                                    echo '3-5 jours';
                                                    break;
                                                case '6-7':
                                                    echo '6-7 jours';
                                                    break;
                                                case '8+':
                                                    echo '8 jours et plus';
                                                    break;
                                            }
                                        ?>
                                    </span>
                                <?php endif; ?>
                                <?php if (!empty($_GET['type'])): ?>
                                    <span class="bg-indigo-100 text-indigo-700 rounded-full px-3 py-1 text-sm font-medium">
                                        Type: Circuit <?= ucfirst(htmlspecialchars($_GET['type'])) ?>
                                    </span>
                                <?php endif; ?>
                                <?php if (!empty($_GET['budget'])): ?>
                                    <span class="bg-indigo-100 text-indigo-700 rounded-full px-3 py-1 text-sm font-medium">
                                        Budget: <?php
                                            switch($_GET['budget']) {
                                                case 'economique':
                                                    echo 'Économique (< 100 000 FCFA)';
                                                    break;
                                                case 'standard':
                                                    echo 'Standard (100 000 - 200 000 FCFA)';
                                                    break;
                                                case 'luxe':
                                                    echo 'Luxe (> 200 000 FCFA)';
                                                    break;
                                            }
                                        ?>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endif; ?>
                    </aside>    
    
                <section class="md:w-3/4 grid grid-cols-1 sm:grid-cols-2 gap-8">
                    <?php if (empty($circuits)): ?>
                        <div class="col-span-full text-center py-16 text-gray-600">
                            <h3 class="text-2xl font-semibold mb-2">Aucun circuits disponible</h3>
                            <p>Aucun circuit ne correspond à vos critères de recherche.</p>
                        </div>

                        <?php else: ?>
                    <?php foreach ($circuits as $circuit): ?>
                        <article class="bg-white rounded-lg shadow-md overflow-hidden flex flex-col hover:shadow-lg transition">
                        <div class="relative overflow-hidden h-64">
                            <img src="<?= htmlspecialchars($circuit['image']) ?>" alt="<?= htmlspecialchars($circuit['nom']) ?>" class="w-full h-full object-cover transition-transform duration-300 hover:scale-105" />
                            <div class="absolute top-4 right-4 bg-gray-700 bg-opacity-70 text-white rounded-full px-3 py-1 flex items-center space-x-1 text-sm select-none">
                                <i class="fas fa-clock me-2"></i><?= $circuit['duree'] ?> jours
                            </div>
                        </div>
                        <div class="p-6 flex flex-col flex-grow">
                            <h3 class="text-xl font-semibold mb-2 text-indigo-800"><?= htmlspecialchars($circuit['nom']) ?></h3>
                            <p class="text-gray-600 mb-4 flex-grow"><?= htmlspecialchars(mb_strimwidth($circuit['sous_titre'], 0, 100, '...')) ?></p>

                            <div class="mb-5 space-y-1">
                                <p class="text-indigo-700 font-semibold text-lg">
                                    À partir de <?= number_format($circuit['prix'], 0, ',', ' ') ?> FCFA / nuit
                                </p>
                            </div>
                            <a href="circuit_detail.php?id=<?= $circuit['id'] ?>" class="block text-center bg-secondary hover:bg-orange-600 text-white font-bold py-2 px-4 rounded-lg transition duration-300">
                                Voir les détails
                            </a>
                            
                        </div>
                    </article>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>
    </main>
    <?php include('../includes/footer.php'); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 800,
            once: true,
            easing: 'ease-out-quad'
        });

        // Filtrage des circuits
        document.getElementById('filterForm').addEventListener('submit', function(e) {
            e.preventDefault();
            // Logique de filtrage à implémenter
            console.log('Filtres appliqués');
        });
    </script>
</body>
</html>