<?php
session_start();
include_once("../config/database.php");


$page_title = "Tableau de Bord - Bénin Tourisme";

// Récupération des informations de l'utilisateur
$user_id = $_SESSION['gestionnaire_id'];
$user_type = $_SESSION['gestionnaire_type'];

// Récupération des statistiques selon le type de compte
try {
    switch($user_type) {
        case 'destination':
            // Total des destinations
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM lieux WHERE gestionnaire_id = ?");
            $stmt->execute([$user_id]);
            $total_items = $stmt->fetchColumn();
            
            // Destinations ajoutées ce mois
            $stmt_mois = $pdo->prepare("
                SELECT COUNT(*) 
                FROM lieux 
                WHERE gestionnaire_id = ? 
                AND MONTH(date_ajout) = MONTH(CURRENT_DATE())
                AND YEAR(date_ajout) = YEAR(CURRENT_DATE())
            ");
            $stmt_mois->execute([$user_id]);
            $items_mois = $stmt_mois->fetchColumn();

            // Récupération des vues totales
            $stmt_vues = $pdo->prepare("
                SELECT COUNT(*) as total_vues 
                FROM vues v
                INNER JOIN lieux d ON v.element_id = d.id
                WHERE d.gestionnaire_id = ? 
                AND v.element_type = 'destination'
            ");
            $stmt_vues->execute([$user_id]);
            $total_vues = $stmt_vues->fetchColumn() ?: 0;

            // Récupération des vues du mois
            $stmt_vues_mois = $pdo->prepare("
                SELECT COUNT(*) as vues_mois 
                FROM vues v
                INNER JOIN lieux d ON v.element_id = d.id
                WHERE d.gestionnaire_id = ? 
                AND v.element_type = 'destination'
                AND MONTH(v.date_vue) = MONTH(CURRENT_DATE())
                AND YEAR(v.date_vue) = YEAR(CURRENT_DATE())
            ");
            $stmt_vues_mois->execute([$user_id]);
            $vues_mois = $stmt_vues_mois->fetchColumn() ?: 0;

            // Top 3 des destinations les plus vues
            $stmt_top = $pdo->prepare("
                SELECT d.nom, COUNT(v.id) as nombre_vues 
                FROM lieux d
                LEFT JOIN vues v ON v.element_id = d.id AND v.element_type = 'destination'
                WHERE d.gestionnaire_id = ?
                GROUP BY d.id, d.nom
                ORDER BY nombre_vues DESC 
                LIMIT 3
            ");
            $stmt_top->execute([$user_id]);
            $top_items = $stmt_top->fetchAll(PDO::FETCH_ASSOC);
            break;

        case 'circuit':
            // Total des circuits
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM circuits WHERE gestionnaire_id = ?");
            $stmt->execute([$user_id]);
            $total_items = $stmt->fetchColumn();
            
            // Circuits ajoutés ce mois
            $stmt_mois = $pdo->prepare("
                SELECT COUNT(*) 
                FROM circuits 
                WHERE gestionnaire_id = ? 
                AND MONTH(date_ajout) = MONTH(CURRENT_DATE())
                AND YEAR(date_ajout) = YEAR(CURRENT_DATE())
            ");
            $stmt_mois->execute([$user_id]);
            $items_mois = $stmt_mois->fetchColumn();

            // Récupération des vues totales
            $stmt_vues = $pdo->prepare("
                SELECT COUNT(*) as total_vues 
                FROM vues v
                INNER JOIN circuits c ON v.element_id = c.id
                WHERE c.gestionnaire_id = ? 
                AND v.element_type = 'circuit'
            ");
            $stmt_vues->execute([$user_id]);
            $total_vues = $stmt_vues->fetchColumn() ?: 0;

            // Récupération des vues du mois
            $stmt_vues_mois = $pdo->prepare("
                SELECT COUNT(*) as vues_mois 
                FROM vues v
                INNER JOIN circuits c ON v.element_id = c.id
                WHERE c.gestionnaire_id = ? 
                AND v.element_type = 'circuit'
                AND MONTH(v.date_vue) = MONTH(CURRENT_DATE())
                AND YEAR(v.date_vue) = YEAR(CURRENT_DATE())
            ");
            $stmt_vues_mois->execute([$user_id]);
            $vues_mois = $stmt_vues_mois->fetchColumn() ?: 0;

            // Top 3 des circuits les plus vus
            $stmt_top = $pdo->prepare("
                SELECT c.nom, COUNT(v.id) as nombre_vues 
                FROM circuits c
                LEFT JOIN vues v ON v.element_id = c.id AND v.element_type = 'circuit'
                WHERE c.gestionnaire_id = ?
                GROUP BY c.id, c.nom
                ORDER BY nombre_vues DESC 
                LIMIT 3
            ");
            $stmt_top->execute([$user_id]);
            $top_items = $stmt_top->fetchAll(PDO::FETCH_ASSOC);
            break;

        case 'hotel':
            // Total des hôtels
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM hotels WHERE gestionnaire_id = ?");
            $stmt->execute([$user_id]);
            $total_items = $stmt->fetchColumn();
            
            // Hôtels ajoutés ce mois
            $stmt_mois = $pdo->prepare("
                SELECT COUNT(*) 
                FROM hotels 
                WHERE gestionnaire_id = ? 
                AND MONTH(date_ajout) = MONTH(CURRENT_DATE())
                AND YEAR(date_ajout) = YEAR(CURRENT_DATE())
            ");
            $stmt_mois->execute([$user_id]);
            $items_mois = $stmt_mois->fetchColumn();

            // Récupération des vues totales
            $stmt_vues = $pdo->prepare("
                SELECT COUNT(*) as total_vues 
                FROM vues v
                INNER JOIN hotels h ON v.element_id = h.id
                WHERE h.gestionnaire_id = ? 
                AND v.element_type = 'hotel'
            ");
            $stmt_vues->execute([$user_id]);
            $total_vues = $stmt_vues->fetchColumn() ?: 0;

            // Récupération des vues du mois
            $stmt_vues_mois = $pdo->prepare("
                SELECT COUNT(*) as vues_mois 
                FROM vues v
                INNER JOIN hotels h ON v.element_id = h.id
                WHERE h.gestionnaire_id = ? 
                AND v.element_type = 'hotel'
                AND MONTH(v.date_vue) = MONTH(CURRENT_DATE())
                AND YEAR(v.date_vue) = YEAR(CURRENT_DATE())
            ");
            $stmt_vues_mois->execute([$user_id]);
            $vues_mois = $stmt_vues_mois->fetchColumn() ?: 0;

            // Top 3 des hôtels les plus vus
            $stmt_top = $pdo->prepare("
                SELECT h.nom, COUNT(v.id) as nombre_vues 
                FROM hotels h
                LEFT JOIN vues v ON v.element_id = h.id AND v.element_type = 'hotel'
                WHERE h.gestionnaire_id = ?
                GROUP BY h.id, h.nom
                ORDER BY nombre_vues DESC 
                LIMIT 3
            ");
            $stmt_top->execute([$user_id]);
            $top_items = $stmt_top->fetchAll(PDO::FETCH_ASSOC);
            break;

        case 'evenement':
            // Total des événements
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM evenements WHERE gestionnaire_id = ?");
            $stmt->execute([$user_id]);
            $total_items = $stmt->fetchColumn();
            
            // Événements ajoutés ce mois
            $stmt_mois = $pdo->prepare("
                SELECT COUNT(*) 
                FROM evenements 
                WHERE gestionnaire_id = ? 
                AND MONTH(date_ajout) = MONTH(CURRENT_DATE())
                AND YEAR(date_ajout) = YEAR(CURRENT_DATE())
            ");
            $stmt_mois->execute([$user_id]);
            $items_mois = $stmt_mois->fetchColumn();

            // Récupération des vues totales
            $stmt_vues = $pdo->prepare("
                SELECT COUNT(*) as total_vues 
                FROM vues v
                INNER JOIN evenements e ON v.element_id = e.id
                WHERE e.gestionnaire_id = ? 
                AND v.element_type = 'evenement'
            ");
            $stmt_vues->execute([$user_id]);
            $total_vues = $stmt_vues->fetchColumn() ?: 0;

            // Récupération des vues du mois
            $stmt_vues_mois = $pdo->prepare("
                SELECT COUNT(*) as vues_mois 
                FROM vues v
                INNER JOIN evenements e ON v.element_id = e.id
                WHERE e.gestionnaire_id = ? 
                AND v.element_type = 'evenement'
                AND MONTH(v.date_vue) = MONTH(CURRENT_DATE())
                AND YEAR(v.date_vue) = YEAR(CURRENT_DATE())
            ");
            $stmt_vues_mois->execute([$user_id]);
            $vues_mois = $stmt_vues_mois->fetchColumn() ?: 0;

            // Top 3 des événements les plus vus
            $stmt_top = $pdo->prepare("
                SELECT e.nom, COUNT(v.id) as nombre_vues 
                FROM evenements e
                LEFT JOIN vues v ON v.element_id = e.id AND v.element_type = 'evenement'
                WHERE e.gestionnaire_id = ?
                GROUP BY e.id, e.nom
                ORDER BY nombre_vues DESC 
                LIMIT 3
            ");
            $stmt_top->execute([$user_id]);
            $top_items = $stmt_top->fetchAll(PDO::FETCH_ASSOC);
            break;
    }
} catch (PDOException $e) {
    $total_items = 0;
    $total_vues = 0;
    $vues_mois = 0;
    $items_mois = 0;
    $top_items = [];
    error_log("Erreur lors de la récupération des statistiques : " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', sans-serif;
        }

        body {
            background: #f5f6fa;
            min-height: 100vh;
        }

        .dashboard {
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 280px;
            background: linear-gradient(180deg, #1a237e 0%, #0d47a1 100%);
            color: white;
            padding: 25px;
            position: fixed;
            height: 100vh;
            transition: all 0.3s ease;
            box-shadow: 4px 0 10px rgba(0, 0, 0, 0.1);
        }

        .sidebar-header {
            padding: 20px 0;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            margin-bottom: 30px;
        }

        .sidebar-header .logo {
            width: 50px;
            height: 50px;
            margin-bottom: 10px;
            border-radius: 10px;
        }

        .sidebar-header h2 {
            font-size: 24px;
            margin-bottom: 10px;
            background: linear-gradient(135deg, #fff 0%, #e3f2fd 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .user-info {
            font-size: 14px;
            color: rgba(255,255,255,0.8);
            padding: 10px;
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            margin-top: 10px;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .user-info i {
            font-size: 18px;
        }

        .nav-menu {
            margin-top: 30px;
        }

        .nav-item {
            padding: 15px 20px;
            margin: 8px 0;
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 12px;
            color: rgba(255,255,255,0.8);
        }

        .nav-item:hover {
            background: rgba(255,255,255,0.1);
            transform: translateX(5px);
        }

        .nav-item.active {
            background: rgba(255,255,255,0.2);
            color: white;
        }

        .nav-item i {
            width: 24px;
            font-size: 18px;
        }

        .logout-link {
            text-decoration: none;
            color: inherit;
            display: flex;
            align-items: center;
            gap: 12px;
            width: 100%;
        }

        .logout-link:hover {
            color: white;
        }

        .nav-item.logout {
            margin-top: auto;
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
        }

        .nav-item.logout:hover {
            background: rgba(255,255,255,0.2);
            border-color: rgba(255,255,255,0.3);
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: 280px;
            padding: 30px;
        }

        .header {
            background: white;
            padding: 25px 30px;
            border-radius: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .welcome-text h1 {
            font-size: 28px;
            color: #1a237e;
            margin-bottom: 5px;
        }

        .welcome-text p {
            color: #666;
            font-size: 15px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            padding: 25px;
            border-radius: 20px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }

        .stat-card.new-update {
            animation: highlight 2s ease;
        }

        @keyframes highlight {
            0% {
                transform: scale(1);
                box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            }
            50% {
                transform: scale(1.05);
                box-shadow: 0 8px 25px rgba(26, 35, 126, 0.2);
            }
            100% {
                transform: scale(1);
                box-shadow: 0 5px 20px rgba(0,0,0,0.05);
            }
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, #1a237e 0%, #0d47a1 100%);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
        }

        .stat-card h3 {
            color: #666;
            font-size: 16px;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .stat-card h3 i {
            color: #1a237e;
            font-size: 20px;
        }

        .stat-card .number {
            font-size: 36px;
            color: #1a237e;
            font-weight: 600;
            margin-bottom: 10px;
        }

        .stat-card .trend {
            font-size: 14px;
            color: #4caf50;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .action-buttons {
            display: flex;
            gap: 15px;
            position: relative;
        }

        .btn {
            padding: 12px 25px;
            border-radius: 12px;
            border: none;
            cursor: pointer;
            font-weight: 500;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 10px;
            font-size: 15px;
        }

        .dropdown-menu {
            position: absolute;
            top: 100%;
            left: 0;
            background: white;
            border-radius: 12px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
            padding: 10px;
            min-width: 200px;
            display: none;
            z-index: 1000;
            margin-top: 10px;
        }

        .dropdown-menu.show {
            display: block;
        }

        .dropdown-item {
            padding: 12px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: #1a237e;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s ease;
        }

        .dropdown-item:hover {
            background: #f5f6fa;
            color: #0d47a1;
        }

        .dropdown-item i {
            width: 20px;
            text-align: center;
        }

        /* Ajustement pour le bouton avec dropdown */
        #addButton {
            position: relative;
        }

        #addButton .fa-chevron-down {
            transition: transform 0.3s ease;
        }

        #addButton.active .fa-chevron-down {
            transform: rotate(180deg);
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(-10px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .btn-primary {
            background: linear-gradient(135deg, #1a237e 0%, #0d47a1 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(26, 35, 126, 0.3);
        }

        .btn-secondary {
            background: #f5f6fa;
            color: #1a237e;
            border: 1px solid #1a237e;
        }

        .btn-secondary:hover {
            background: #e8eaf6;
            transform: translateY(-2px);
        }

        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #4CAF50;
            color: white;
            padding: 15px 25px;
            border-radius: 10px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            display: none;
            z-index: 1000;
            animation: slideIn 0.5s ease;
        }

        @keyframes slideIn {
            from {
                transform: translateX(100%);
                opacity: 0;
            }
            to {
                transform: translateX(0);
                opacity: 1;
            }
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 80px;
                padding: 20px 10px;
            }

            .sidebar-header h2,
            .user-info,
            .nav-item span {
                display: none;
            }

            .main-content {
                margin-left: 80px;
                padding: 20px;
            }

            .stats-grid {
                grid-template-columns: 1fr;
            }

            .header {
                flex-direction: column;
                gap: 20px;
                text-align: center;
            }

            .action-buttons {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <?php if (isset($_GET['success'])): ?>
    <div class="notification" id="successNotification">
        <i class="fas fa-check-circle"></i>
        <?php 
        switch($_GET['type']) {
            case 'destination':
                echo "Destination ajoutée avec succès !";
                break;
            case 'circuit':
                echo "Circuit ajouté avec succès !";
                break;
            case 'hotel':
                echo "Hôtel ajouté avec succès !";
                break;
            case 'evenement':
                echo "Événement ajouté avec succès !";
                break;
        }
        ?>
    </div>
    <?php endif; ?>

    <div class="dashboard">
        <!-- Sidebar -->
        <div class="sidebar">
            <div class="sidebar-header">
                <img src="../assets/images/icon.png" alt="logo" class="logo">
                <h2>Bénin Tourisme</h2>
                <div class="user-info">
                    <i class="fas fa-user-circle"></i>
                    <?php echo htmlspecialchars($_SESSION['nom']); ?>
                </div>
            </div>
            <nav class="nav-menu">
                <div class="nav-item active">
                    <i class="fas fa-home"></i>
                    <span>Tableau de bord</span>
                </div>
                <div class="nav-item">
                    <i class="fas fa-list"></i>
                    <span>Liste</span>
                </div>
                <div class="nav-item">
                    <i class="fas fa-cog"></i>
                    <span>Paramètres</span>
                </div>
                <div class="nav-item logout">
                    <i class="fas fa-sign-out-alt"></i>
                    <a href="deconnexion.php" class="logout-link">Déconnexion</a>
                </div>
            </nav>
        </div>

        <!-- Main Content -->
        <div class="main-content">
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success">
                    <?php 
                    echo $_SESSION['success_message'];
                    unset($_SESSION['success_message']);
                    ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['error_message'])): ?>
                <div class="alert alert-danger">
                    <?php 
                    echo $_SESSION['error_message'];
                    unset($_SESSION['error_message']);
                    ?>
                </div>
            <?php endif; ?>

            <div class="header">
                <div class="welcome-text">
                    <h1>Bienvenue, <?php echo htmlspecialchars($_SESSION['nom']); ?> !</h1>
                    <p>Voici un aperçu de votre activité</p>
                </div>
                <div class="action-buttons">
                    <div class="btn btn-primary" id="addButton">
                        <i class="fas fa-plus"></i>
                        Ajouter
                        <i class="fas fa-chevron-down" style="margin-left: 5px;"></i>
                    </div>
                    <div class="dropdown-menu" id="addDropdown">
                        <?php
                        switch($user_type) {
                            case 'destination':
                                echo '<a href="destinations.php" class="dropdown-item">
                                    <i class="fas fa-map-marker-alt"></i>
                                    Destination
                                </a>';
                                break;
                            case 'circuit':
                                echo '<a href="circuits.php" class="dropdown-item">
                                    <i class="fas fa-route"></i>
                                    Circuit
                                </a>';
                                break;
                            case 'evenement':
                                echo '<a href="evenements.php" class="dropdown-item">
                                    <i class="fas fa-calendar-alt"></i>
                                    Événement
                                </a>';
                                break;
                            case 'hotel':
                                echo '<a href="hotels.php" class="dropdown-item">
                                    <i class="fas fa-hotel"></i>
                                    Hôtel
                                </a>';
                                break;
                        }
                        ?>
                    </div>
                    <button class="btn btn-secondary">
                        <i class="fas fa-cog"></i>
                        Paramètres
                    </button>
                </div>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <h3><i class="fas fa-map-marker-alt"></i> Total <?php echo ucfirst($user_type); ?>s</h3>
                    <div class="number"><?php echo $total_items; ?></div>
                    <div class="trend">
                        <i class="fas fa-arrow-up"></i>
                        <span><?php echo $items_mois; ?> ajoutés ce mois</span>
                    </div>
                </div>
                <div class="stat-card">
                    <h3><i class="fas fa-eye"></i> Vues totales</h3>
                    <div class="number"><?php echo $total_vues; ?></div>
                    <div class="trend">
                        <i class="fas fa-arrow-up"></i>
                        <span><?php echo $vues_mois; ?> vues ce mois</span>
                    </div>
                </div>
                <div class="stat-card">
                    <h3><i class="fas fa-chart-line"></i> Performance</h3>
                    <div class="number">
                        <?php 
                        if ($total_items > 0) {
                            echo round(($total_vues / $total_items), 1);
                        } else {
                            echo "0";
                        }
                        ?>
                    </div>
                    <div class="trend">
                        <i class="fas fa-chart-bar"></i>
                        <span>Vues par élément</span>
                    </div>
                </div>
            </div>

            <!-- Top 3 des éléments les plus vus -->
            <div class="top-items-section" style="margin-top: 30px; background: white; padding: 25px; border-radius: 20px; box-shadow: 0 5px 20px rgba(0,0,0,0.05);">
                <h3 style="color: #1a237e; margin-bottom: 20px; display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-trophy"></i>
                    Top 3 des <?php echo ucfirst($user_type); ?>s les plus vus
                </h3>
                <div class="top-items-list" style="display: grid; gap: 15px;">
                    <?php foreach ($top_items as $index => $item): ?>
                    <div class="top-item" style="display: flex; justify-content: space-between; align-items: center; padding: 15px; background: #f5f6fa; border-radius: 10px;">
                        <div style="display: flex; align-items: center; gap: 10px;">
                            <span style="font-weight: 600; color: #1a237e;"><?php echo $index + 1; ?>.</span>
                            <span><?php echo htmlspecialchars($item['nom']); ?></span>
                        </div>
                        <div style="color: #666;">
                            <i class="fas fa-eye"></i>
                            <?php echo $item['nombre_vues']; ?> vues
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', function() {
                document.querySelector('.nav-item.active').classList.remove('active');
                this.classList.add('active');
            });
        });

        // Gestion du menu déroulant
        const addButton = document.getElementById('addButton');
        const addDropdown = document.getElementById('addDropdown');

        addButton.addEventListener('click', function(e) {
            e.stopPropagation();
            addDropdown.classList.toggle('show');
        });

        // Fermer le menu déroulant quand on clique ailleurs
        document.addEventListener('click', function(e) {
            if (!addButton.contains(e.target) && !addDropdown.contains(e.target)) {
                addDropdown.classList.remove('show');
            }
        });

        // Afficher la notification si elle existe
        const notification = document.getElementById('successNotification');
        if (notification) {
            notification.style.display = 'block';
            setTimeout(() => {
                notification.style.display = 'none';
            }, 3000);

            // Ajouter l'animation aux cartes statistiques
            document.querySelectorAll('.stat-card').forEach(card => {
                card.classList.add('new-update');
            });
        }
    </script>
</body>
</html> 