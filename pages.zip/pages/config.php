<?php
// Configuration de la base de données
include_once("..\config\database.php");

// Configuration des couleurs
$primary_color = '#1e40af';
$secondary_color = '#f97316';

// Configuration des chemins
$base_url = '/ProjetBinome';

// Configuration des couleurs et du thème
$theme = [
    'primary' => '#1e40af',
    'secondary' => '#f97316',
    'dark' => '#1f2937',
    'light' => '#f3f4f6',
    'white' => '#ffffff'
];

// Configuration des chemins
$config = [
    'base_url' => '/ProjetBinome',
    'assets_url' => '/ProjetBinome/assets',
    'images_url' => '/ProjetBinome/assets/images'
];

// Fonction pour inclure les fichiers CSS et JS nécessaires
function include_assets() {
    ?>
    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '<?= $theme['primary'] ?>',
                        secondary: '<?= $theme['secondary'] ?>',
                        dark: '<?= $theme['dark'] ?>',
                    },
                    fontFamily: {
                        sans: ['Poppins', 'sans-serif'],
                    }
                }
            }
        }
    </script>
    <!-- Custom CSS -->
    <style>
        /* Styles communs */
        .glass-effect {
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }
        .scroll-reveal {
            opacity: 0;
            transform: translateY(20px);
            transition: all 0.6s ease;
        }
        .scroll-reveal.active {
            opacity: 1;
            transform: translateY(0);
        }
        .btn-hover {
            transition: all 0.3s ease;
        }
        .btn-hover:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        }
    </style>
    <?php
}

// Fonction pour initialiser les animations
function init_animations() {
    ?>
    <script>
        // Scroll reveal animation
        const scrollReveal = () => {
            const elements = document.querySelectorAll('.scroll-reveal');
            elements.forEach(element => {
                const elementTop = element.getBoundingClientRect().top;
                const elementVisible = 150;
                if (elementTop < window.innerHeight - elementVisible) {
                    element.classList.add('active');
                }
            });
        };

        window.addEventListener('scroll', scrollReveal);
        scrollReveal(); // Initial check
    </script>
    <?php
}
?> 