<?php
session_start();
include_once(__DIR__ . "/../config/database.php");

// Récupérer l'ID du lieu depuis l'URL
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header('Location: ../pages/destinations.php');
    exit;
}

$id = (int)$_GET['id'];

// Requête pour récupérer les détails du lieu
$stmt = $pdo->prepare("SELECT * FROM lieux WHERE id = ?");
$stmt->execute([$id]);
$lieu = $stmt->fetch();

if (!$lieu) {
    header('Location: ../pages/destinations.php');
    exit;
}

// Fonction pour corriger le chemin de l'image
function getCorrectImagePath($imagePath) {
    // Si le chemin commence déjà par http, on le garde tel quel
    if (strpos($imagePath, 'http') === 0) {
        return $imagePath;
    }
    
    // Supprimer les éventuels slashs ou backslashes au début
    $imagePath = ltrim($imagePath, '/\\');
    
    // Construire le chemin relatif depuis la racine du site
    return '../' . $imagePath;
}

// Définir le titre de la page
$page_title = htmlspecialchars($lieu['nom']) . " - Bénin Tourisme";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .hero-section {
            height: 60vh;
            background-size: cover;
            background-position: center;
        }
        .hero-overlay {
            background: rgba(0, 0, 0, 0.5);
        }
        .hero-title {
            text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
        }
        .hero-subtitle {
            text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.5);
        }
        .info-card {
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .map-container {
            height: 400px;
        }
        .btn-reserve {
            transition: all 0.3s ease;
        }
        .btn-reserve:hover {
            transform: translateY(-2px);
        }
        .animate-fade-in {
            animation: fadeIn 1s ease-in;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</head>
<body class="bg-gray-50">
    <?php include_once(__DIR__ . "/../includes/navbar.php"); ?>

    <!-- Hero Section -->
    <section class="hero-section relative" style="background-image: url('<?= getCorrectImagePath($lieu['image']) ?>');">
        <div class="hero-overlay absolute inset-0"></div>
        <div class="hero-content relative z-10 flex flex-col justify-center h-full px-8">
            <h1 class="hero-title text-4xl md:text-5xl font-bold text-white mb-4 animate-fade-in">
                <?= htmlspecialchars($lieu['nom']) ?>
            </h1>
            <p class="hero-subtitle text-xl text-white animate-fade-in" style="animation-delay: 0.2s">
                <i class="fas fa-map-marker-alt mr-2"></i>
                <?= htmlspecialchars($lieu['adresse']) ?>, <?= htmlspecialchars($lieu['ville']) ?>
            </p>
        </div>
    </section>

    <!-- Detail Section -->
    <section class="py-16 bg-gray-50">
        <div class="container mx-auto px-4">
            <div class="flex flex-col lg:flex-row gap-8">
                <!-- Informations principales -->
                <div class="lg:w-2/3">
                    <div class="info-card bg-white rounded-xl p-8 mb-8">
                        <h2 class="text-2xl font-bold text-gray-800 mb-6">À propos</h2>
                        <p class="text-gray-700 mb-6"><?= nl2br(htmlspecialchars($lieu['description'])) ?></p>
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div class="flex items-center">
                                <i class="fas fa-clock text-orange-500 text-xl mr-3 w-6"></i>
                                <span class="text-gray-700">Durée : <?= isset($lieu['duree_visite']) ? htmlspecialchars($lieu['duree_visite']) : 'Non spécifiée' ?></span>
                            </div>
                            <div class="flex items-center">
                                <i class="fas fa-ticket-alt text-orange-500 text-xl mr-3 w-6"></i>
                                <span class="text-gray-700">Prix : <?= isset($lieu['prix']) ? htmlspecialchars($lieu['prix']) . ' FCFA' : 'Non spécifié' ?></span>
                            </div>
                            <div class="flex items-center">
                                <i class="fas fa-calendar-alt text-orange-500 text-xl mr-3 w-6"></i>
                                <span class="text-gray-700">Horaires : <?= isset($lieu['horaires']) ? htmlspecialchars($lieu['horaires']) : 'Non spécifiés' ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Carte -->
                    <div class="info-card bg-white rounded-xl p-8">
                        <h2 class="text-2xl font-bold text-gray-800 mb-6">Localisation</h2>
                        <div class="map-container rounded-xl overflow-hidden">
                            <iframe
                                src="https://www.google.com/maps?q=<?= $lieu['latitude'] ?>,<?= $lieu['longitude'] ?>&output=embed"
                                width="100%"
                                height="100%"
                                style="border:0;"
                                allowfullscreen>
                            </iframe>
                        </div>
                    </div>
                </div>

                <!-- Réservation -->
                <div class="lg:w-1/3">
                    <div class="reservation-card bg-white rounded-xl p-8 sticky top-8">
                        <h2 class="text-2xl font-bold text-gray-800 mb-6">Réserver</h2>
                        <?php if (isset($_SESSION['user_id'])): ?>
                            <a href="../pages/reservation.php?lieu=<?= $lieu['id'] ?>" class="btn-reserve bg-orange-500 hover:bg-orange-600 text-white font-bold py-4 px-6 rounded-full w-full text-center block">
                                <i class="fas fa-calendar-check mr-2"></i>Réserver ce lieu
                            </a>
                        <?php else: ?>
                            <a href="../pages/connexion.php?redirect=<?= urlencode($_SERVER['REQUEST_URI']) ?>" class="btn-reserve bg-orange-500 hover:bg-orange-600 text-white font-bold py-4 px-6 rounded-full w-full text-center block">
                                <i class="fas fa-sign-in-alt mr-2"></i>Se connecter pour réserver
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include_once(__DIR__ . "/../includes/footer.php"); ?>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>