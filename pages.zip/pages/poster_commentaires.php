<?php
session_start();
require 'connexion.php';

if (!isset($_SESSION['user_id'], $_POST['post_id'], $_POST['contenu'])) {
    header('Location: afficher_posts.php');
    exit;
}

$utilisateur_id = $_SESSION['user_id'];
$post_id = intval($_POST['post_id']);
$contenu = trim($_POST['contenu']);

if ($contenu === '') {
    header("Location: commentaires.php?post_id=$post_id");
    exit;
}

$stmt = $pdo->prepare("INSERT INTO commentaires (utilisateur_id, post_id, contenu) VALUES (?, ?, ?)");
$stmt->execute([$utilisateur_id, $post_id, $contenu]);

header("Location: commentaires.php?post_id=$post_id");
exit;
