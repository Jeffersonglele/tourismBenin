<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once(__DIR__ . '/../vendor/autoload.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Vérifier si le fichier database.php existe
if (!file_exists(__DIR__ . '/database.php')) {
    header('Content-Type: application/json');
    echo json_encode([
        'success' => false,
        'error' => 'Fichier de configuration de la base de données introuvable'
    ]);
    exit;
}

include_once("database.php");

header('Content-Type: application/json');

// Fonction pour envoyer l'email de confirmation
function sendConfirmationEmail($email) {
    $mail = new PHPMailer(true);
    try {
        // Configuration du serveur
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'contactbenintourisme@gmail.com';
        $mail->Password   = 'mbrl pvvm gczs feqt';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->CharSet    = 'UTF-8';

        // Destinataires
        $mail->setFrom('contactbenintourisme@gmail.com', 'Bénin Tourisme');
        $mail->addAddress($email);

        // Contenu
        $mail->isHTML(true);
        $mail->Subject = 'Bienvenue à la newsletter - Bénin Tourisme';
        $mail->Body    = '
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #1a1a1a, #4a4a4a); padding: 20px; text-align: center; }
                .header h1 { color: #fff; margin: 0; font-size: 24px; }
                .content { padding: 30px; background: #fff; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
                .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
                .button { display: inline-block; padding: 12px 24px; background: #007bff; color: #fff; text-decoration: none; border-radius: 5px; margin: 20px 0; }
                .social-links { margin: 20px 0; }
                .social-links a { margin: 0 10px; color: #007bff; text-decoration: none; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Bénin Tourisme</h1>
                </div>
                <div class="content">
                    <h2>Bienvenue à la newsletter de Bénin Tourisme !</h2>
                    <p>Cher(e) visiteur,</p>
                    <p>Nous sommes ravis de vous accueillir dans notre communauté de passionnés du tourisme béninois. Votre inscription à notre newsletter vous permettra de :</p>
                    <ul>
                        <li>Recevoir nos dernières actualités touristiques</li>
                        <li>Découvrir des destinations inédites</li>
                        <li>Profiter d\'offres exclusives</li>
                        <li>Être informé des événements à ne pas manquer</li>
                    </ul>
                    <p>Restez connecté avec nous sur les réseaux sociaux :</p>
                    <div class="social-links">
                        <a href="#">Facebook</a> |
                        <a href="#">Twitter</a> |
                        <a href="#">Instagram</a>
                    </div>
                    <p>À très bientôt !</p>
                    <p>L\'équipe Bénin Tourisme</p>
                </div>
                <div class="footer">
                    <p>© ' . date('Y') . ' Bénin Tourisme. Tous droits réservés.</p>
                    <p>Pour vous désinscrire, cliquez <a href="#">ici</a></p>
                </div>
            </div>
        </body>
        </html>';

        $mail->send();
        return true;
    } catch (Exception $e) {
        logError("Erreur d'envoi d'email: " . $mail->ErrorInfo);
        return false;
    }
}

// Fonction pour envoyer l'email de notification à l'admin
function sendAdminNotification($email) {
    $mail = new PHPMailer(true);
    try {
        // Configuration du serveur
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'contactbenintourisme@gmail.com';
        $mail->Password   = 'mbrl pvvm gczs feqt';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;
        $mail->CharSet    = 'UTF-8';

        // Destinataires
        $mail->setFrom('contactbenintourisme@gmail.com', 'Bénin Tourisme');
        $mail->addAddress('contactbenintourisme@gmail.com', 'Admin Bénin Tourisme');

        // Contenu
        $mail->isHTML(true);
        $mail->Subject = 'Nouvelle inscription à la newsletter';
        $mail->Body    = '
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                .header { background: linear-gradient(135deg, #1a1a1a, #4a4a4a); padding: 20px; text-align: center; }
                .header h1 { color: #fff; margin: 0; font-size: 24px; }
                .content { padding: 30px; background: #fff; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
                .footer { text-align: center; padding: 20px; color: #666; font-size: 12px; }
                .info-box { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 20px 0; }
                .info-box p { margin: 5px 0; }
                .button { display: inline-block; padding: 12px 24px; background: #007bff; color: #fff; text-decoration: none; border-radius: 5px; margin: 20px 0; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>Nouvelle Inscription Newsletter</h1>
                </div>
                <div class="content">
                    <h2>Notification d\'inscription</h2>
                    <p>Une nouvelle personne s\'est inscrite à la newsletter :</p>
                    <div class="info-box">
                        <p><strong>Email :</strong> ' . htmlspecialchars($email) . '</p>
                        <p><strong>Date d\'inscription :</strong> ' . date('d/m/Y H:i:s') . '</p>
                        <p><strong>IP :</strong> ' . $_SERVER['REMOTE_ADDR'] . '</p>
                    </div>
                    <p>Vous pouvez gérer les abonnés depuis votre espace d\'administration.</p>
                    <a href="http://localhost/ProjetBinome/newsletter.php?admin=1" class="button">Accéder à l\'administration</a>
                </div>
                <div class="footer">
                    <p>© ' . date('Y') . ' Bénin Tourisme. Tous droits réservés.</p>
                </div>
            </div>
        </body>
        </html>';

        $mail->send();
        return true;
    } catch (Exception $e) {
        logError("Erreur d'envoi d'email admin: " . $mail->ErrorInfo);
        return false;
    }
}

// Fonction pour logger les erreurs
function logError($message) {
    $logDir = __DIR__;
    $logFile = $logDir . '/newsletter_errors.log';
    
    // Vérifier si le dossier est accessible en écriture
    if (!is_writable($logDir)) {
        error_log("Le dossier n'est pas accessible en écriture: " . $logDir);
        return;
    }
    
    // Créer le fichier s'il n'existe pas
    if (!file_exists($logFile)) {
        touch($logFile);
        chmod($logFile, 0666);
    }
    
    // Vérifier si le fichier est accessible en écriture
    if (!is_writable($logFile)) {
        error_log("Le fichier de log n'est pas accessible en écriture: " . $logFile);
        return;
    }
    
    $logMessage = date('[Y-m-d H:i:s] ') . $message . "\n";
    file_put_contents($logFile, $logMessage, FILE_APPEND);
}

// Log initial pour vérifier que le système fonctionne
logError("Script démarré - " . date('Y-m-d H:i:s'));

try {
    // Vérification de la méthode HTTP
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        logError("Méthode non autorisée: " . $_SERVER['REQUEST_METHOD']);
        throw new Exception('Méthode non autorisée');
    }

    // Vérification de la présence de l'email
    if (!isset($_POST['email'])) {
        logError("Email manquant dans la requête");
        throw new Exception('Email manquant');
    }

    // Validation de l'email
    $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
    logError("Email reçu: " . $email);
    
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        logError("Email invalide: " . $email);
        throw new Exception('Adresse email invalide');
    }

    // Vérification de la connexion à la base de données
    try {
        logError("Tentative de connexion à la base de données...");
        $pdo->query("SELECT 1");
        logError("Connexion à la base de données réussie");
    } catch (PDOException $e) {
        logError("Erreur de connexion à la base de données: " . $e->getMessage());
        throw new Exception('Erreur de connexion à la base de données: ' . $e->getMessage());
    }

    // Vérification si l'email existe déjà
    logError("Vérification si l'email existe déjà...");
    $stmt = $pdo->prepare("SELECT id FROM newsletter WHERE email = ?");
    $stmt->execute([$email]);
    if ($stmt->rowCount() > 0) {
        logError("Email déjà inscrit: " . $email);
        throw new Exception('Cette adresse email est déjà inscrite');
    }

    // Insertion dans la base de données
    try {
        logError("Tentative d'insertion dans la base de données...");
        $stmt = $pdo->prepare("INSERT INTO newsletter (email, date_inscription, ip, user_agent) VALUES (?, NOW(), ?, ?)");
        $success = $stmt->execute([
            $email,
            $_SERVER['REMOTE_ADDR'],
            $_SERVER['HTTP_USER_AGENT']
        ]);

        if (!$success) {
            logError("Erreur lors de l'insertion dans la base de données pour l'email: " . $email);
            throw new Exception('Erreur lors de l\'inscription dans la base de données');
        }

        logError("Inscription réussie pour l'email: " . $email);

        // Envoi des emails de confirmation
        logError("Tentative d'envoi des emails de confirmation...");
        $userEmailSent = sendConfirmationEmail($email);
        $adminEmailSent = sendAdminNotification($email);
        
        if ($userEmailSent && $adminEmailSent) {
            logError("Emails de confirmation envoyés avec succès");
            echo json_encode([
                'success' => true,
                'message' => 'Inscription réussie à la newsletter ! Un email de confirmation vous a été envoyé.'
            ]);
        } else {
            logError("Échec de l'envoi d'un ou plusieurs emails de confirmation");
            echo json_encode([
                'success' => true,
                'message' => 'Inscription réussie à la newsletter ! (L\'email de confirmation n\'a pas pu être envoyé)'
            ]);
        }
    } catch (PDOException $e) {
        logError("Erreur PDO lors de l'insertion: " . $e->getMessage());
        throw new Exception('Erreur lors de l\'inscription dans la base de données: ' . $e->getMessage());
    }

} catch (Exception $e) {
    logError("Erreur finale: " . $e->getMessage());
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>