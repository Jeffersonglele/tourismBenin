<?php
// Connexion à la base de données
require_once '../config/database.php'; // à adapter selon ton projet


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Récupération des champs texte
    $nom = $_POST['nom'];
    $description = $_POST['description'];
    $adresse = $_POST['adresse'];
    $ville = $_POST['ville'];
    $region = $_POST['region'];
    $latitude = $_POST['latitude'];
    $longitude = $_POST['longitude'];
    $type = $_POST['type'];
    $prix = $_POST['prix'];
    $video_url = ''; // Par défaut

    // Gestion de l'image
    $image_nom = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $image_tmp = $_FILES['image']['tmp_name'];
        $image_nom = basename($_FILES['image']['name']);
        $image_destination = '../assets/images/' . $image_nom;
        move_uploaded_file($image_tmp, $image_destination);
    }

    // Gestion de la vidéo (URL ou fichier à uploader)
    if (isset($_FILES['video']) && $_FILES['video']['error'] === UPLOAD_ERR_OK) {
        $video_tmp = $_FILES['video']['tmp_name'];
        $video_nom = basename($_FILES['video']['name']);
        $video_destination = '../assets/video/' . $video_nom;
        move_uploaded_file($video_tmp, $video_destination);
        $video_url = $video_destination;
    } elseif (!empty($_POST['video'])) {
        $video_url = $_POST['video']; // URL externe
    }

    // Requête d'insertion
    $sql = "INSERT INTO lieux (nom, description, adresse, ville, region, latitude, longitude, image, type, prix, video)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        $nom,
        $description,
        $adresse,
        $ville,
        $region,
        $latitude,
        $longitude,
        $image_nom,
        $type,
        $prix,
        $video_url
    ]);

    $_SESSION['message'] = "✅ Lieu ajouté avec succès !";
    $_SESSION['message_type'] = "success"; // ou "error", selon le besoin
    header('Location: destinations.php');
    exit();
}else {
    $_SESSION['message'] = "erreur lors de l'ajout ";
$_SESSION['message_type'] = "warning"; // ou "error", selon le besoin
header('Location: destinations.php');
}
?>


