<?php
session_start();
include_once("..\config\database.php");

$page_title = "Blog - Bénin Tourisme";

// Nombre d'articles par page
$articlesParPage = 6;

// Page actuelle (depuis l'URL)
$page = isset($_GET['page']) && is_numeric($_GET['page']) && $_GET['page'] > 0 ? (int) $_GET['page'] : 1;

// Calcul de l'offset pour la requête SQL
$offset = ($page - 1) * $articlesParPage;

// Récupérer le nombre total d'articles
$totalStmt = $pdo->query("SELECT COUNT(*) FROM articles");
$totalArticles = $totalStmt->fetchColumn();
$totalPages = ceil($totalArticles / $articlesParPage);

// Récupérer les articles pour la page courante
$sql = "SELECT id, titre, contenu, DATE_FORMAT(date_publication, '%d %M %Y') AS date_fr 
        FROM articles 
        ORDER BY date_publication DESC 
        LIMIT :limit OFFSET :offset";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':limit', $articlesParPage, PDO::PARAM_INT);
$stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
$stmt->execute();
$articles = $stmt->fetchAll();

?>

<!DOCTYPE html>
<html lang="fr" class="scroll-smooth">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?= htmlspecialchars($page_title) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 text-gray-800 flex flex-col min-h-screen">

    <!-- Inclusion navbar -->
    <?php include_once(__DIR__ . "/../includes/navbar.php"); ?>

    <main class="container mx-auto px-4 py-12 flex-grow max-w-6xl">
        <h1 class="text-4xl font-bold text-indigo-700 mb-10 text-center">Notre Blog</h1>

        <?php if (empty($articles)): ?>
            <p class="text-center text-gray-600">Aucun article publié pour le moment. Revenez bientôt !</p>
        <?php else: ?>
            <div class="grid gap-10 md:grid-cols-2 lg:grid-cols-3">
                <?php foreach ($articles as $article): ?>
                    <article class="bg-white rounded-lg shadow hover:shadow-lg transition p-6 flex flex-col">
                        <h2 class="text-2xl font-semibold mb-2 text-indigo-700 hover:text-indigo-900 transition">
                            <a href="article.php?id=<?= $article['id'] ?>" class="block">
                                <?= htmlspecialchars($article['titre']) ?>
                            </a>
                        </h2>
                        <time datetime="<?= date('Y-m-d', strtotime($article['date_fr'])) ?>" class="text-sm text-gray-500 mb-4">
                            <?= $article['date_fr'] ?>
                        </time>
                        <p class="text-gray-700 flex-grow"><?= htmlspecialchars(mb_strimwidth(strip_tags($article['contenu']), 0, 150, '...')) ?></p>
                        <a href="article.php?id=<?= $article['id'] ?>" class="mt-6 inline-block text-indigo-600 font-semibold hover:underline">
                            Lire la suite &rarr;
                        </a>
                    </article>
                <?php endforeach; ?>
            </div>

            <!-- Pagination -->
            <nav class="mt-12 flex justify-center items-center space-x-3" aria-label="Pagination">
                <?php if ($page > 1): ?>
                    <a href="?page=<?= $page - 1 ?>" class="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition">Précédent</a>
                <?php else: ?>
                    <span class="px-4 py-2 bg-gray-300 text-gray-600 rounded cursor-not-allowed">Précédent</span>
                <?php endif; ?>

                <?php
                // Affiche les numéros de pages (limité à max 5 autour de la page courante)
                $startPage = max(1, $page - 2);
                $endPage = min($totalPages, $page + 2);

                if ($startPage > 1) {
                    echo '<a href="?page=1" class="px-3 py-1 rounded hover:bg-indigo-100">1</a>';
                    if ($startPage > 2) echo '<span class="px-2">...</span>';
                }

                for ($i = $startPage; $i <= $endPage; $i++) {
                    if ($i == $page) {
                        echo '<span class="px-4 py-2 bg-indigo-600 text-white rounded">' . $i . '</span>';
                    } else {
                        echo '<a href="?page=' . $i . '" class="px-3 py-1 rounded hover:bg-indigo-100">' . $i . '</a>';
                    }
                }

                if ($endPage < $totalPages) {
                    if ($endPage < $totalPages - 1) echo '<span class="px-2">...</span>';
                    echo '<a href="?page=' . $totalPages . '" class="px-3 py-1 rounded hover:bg-indigo-100">' . $totalPages . '</a>';
                }
                ?>

                <?php if ($page < $totalPages): ?>
                    <a href="?page=<?= $page + 1 ?>" class="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition">Suivant</a>
                <?php else: ?>
                    <span class="px-4 py-2 bg-gray-300 text-gray-600 rounded cursor-not-allowed">Suivant</span>
                <?php endif; ?>
            </nav>
        <?php endif; ?>

        <div class="container mx-auto px-4 py-12 flex-grow max-w-6xl">
            <button class="text-4xl font-bold text-indigo-700 mb-10 text-center"><a href="poster.php">Vouliez-vous faire un post?</a></button>
        </div>
    </main>

    <!-- Inclusion footer -->
    <?php include_once(__DIR__ . "/../includes/footer.php"); ?>

</body>
</html>
