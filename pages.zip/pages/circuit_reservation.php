<?php
session_start();
include_once("..\config\database.php");
include_once("..\config\mail.php");

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = $_SERVER['HTTP_REFERER'];
    header('Location: connexion.php');
    exit;
}

// Vérifier si c'est une requête POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $circuit_id = isset($_POST['circuit_id']) ? (int)$_POST['circuit_id'] : 0;
    $date_depart = isset($_POST['date_depart']) ? $_POST['date_depart'] : '';
    $nombre_personnes = isset($_POST['nombre_personnes']) ? (int)$_POST['nombre_personnes'] : 0;
    $telephone = isset($_POST['telephone']) ? $_POST['telephone'] : '';
    $commentaire = isset($_POST['commentaire']) ? $_POST['commentaire'] : '';
    
    // Validation des données
    $errors = [];
    
    if ($circuit_id <= 0) {
        $errors[] = "Circuit invalide";
    }
    
    if (!strtotime($date_depart)) {
        $errors[] = "Date de départ invalide";
    }
    
    if (strtotime($date_depart) < strtotime('today')) {
        $errors[] = "La date de départ ne peut pas être dans le passé";
    }
    
    if ($nombre_personnes <= 0) {
        $errors[] = "Nombre de personnes invalide";
    }

    if (empty($telephone)) {
        $errors[] = "Le numéro de téléphone est requis";
    }

    if (!preg_match("/^[0-9]{10}$/", $telephone)) {
        $errors[] = "Le numéro de téléphone doit contenir exactement 10 chiffres";
    }
    
    // Vérifier si le circuit existe et a des places disponibles
    if ($circuit_id > 0) {
        $stmt = $pdo->prepare("SELECT id, capacite_max, places_disponibles FROM circuits WHERE id = ?");
        $stmt->execute([$circuit_id]);
        $circuit = $stmt->fetch();
        
        if (!$circuit) {
            $errors[] = "Ce circuit n'est pas disponible";
        } else if ($nombre_personnes > $circuit['places_disponibles']) {
            $errors[] = "Il n'y a pas assez de places disponibles pour ce circuit";
        }
    }
    
    // Si pas d'erreurs, enregistrer la réservation
    if (empty($errors)) {
        try {
            $pdo->beginTransaction();

            // Insérer la réservation
            $sql = "INSERT INTO circuit_reservations (
                user_id, email, telephone, circuit_id,
                date_depart, nombre_personnes,
                commentaire, date_reservation, statut
            ) VALUES (?, ?, ?, ?, ?, ?, ?, NOW(), 'en_attente')";
            
            $stmt = $pdo->prepare($sql);
            $result = $stmt->execute([
                $_SESSION['user_id'],
                $_SESSION['user_email'],
                $telephone,
                $circuit_id,
                $date_depart,
                $nombre_personnes,
                $commentaire
            ]);

            if (!$result) {
                throw new PDOException("Échec de l'insertion dans circuit_reservations");
            }

            // Mettre à jour le nombre de places disponibles
            $stmt = $pdo->prepare("UPDATE circuits SET places_disponibles = places_disponibles - ? WHERE id = ?");
            $stmt->execute([$nombre_personnes, $circuit_id]);

            $pdo->commit();
            
            // Préparer le contenu de l'email
            $emailBody = "
                <h2>Confirmation de réservation de circuit - Bénin Tourisme</h2>
                <p>Cher(e) {$_SESSION['user_prenom']} {$_SESSION['user_nom']},</p>
                <p>Nous avons bien reçu votre réservation de circuit.</p>
                <div style='background-color: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;'>
                    <p><strong>Date de départ :</strong> " . date('d/m/Y', strtotime($date_depart)) . "</p>
                    <p><strong>Nombre de personnes :</strong> $nombre_personnes</p>
                </div>
                <p>Notre équipe va traiter votre demande dans les plus brefs délais.</p>
                <p>Cordialement,<br>L'équipe Bénin Tourisme</p>
            ";
            
            // Envoyer l'email de confirmation
            if (sendEmail($_SESSION['user_email'], "Confirmation de réservation de circuit - Bénin Tourisme", $emailBody)) {
                $_SESSION['success_message'] = "Votre réservation a été enregistrée avec succès ! Un email de confirmation vous a été envoyé.";
            } else {
                $_SESSION['success_message'] = "Votre réservation a été enregistrée avec succès !";
            }
            
            header('Location: mes_reservations.php');
            exit;
            
        } catch (PDOException $e) {
            $pdo->rollBack();
            $errors[] = "Une erreur est survenue lors de l'enregistrement de votre réservation: " . $e->getMessage();
            error_log("Erreur PDO détaillée : " . $e->getMessage());
        }
    }
    
    // S'il y a des erreurs, les stocker en session et rediriger
    if (!empty($errors)) {
        $_SESSION['error_messages'] = $errors;
        error_log("Erreurs de validation circuit : " . print_r($errors, true));
        header('Location: ' . $_SERVER['HTTP_REFERER']);
        exit;
    }
} else {
    // Si ce n'est pas une requête POST, rediriger vers la page des circuits
    header('Location: circuits.php');
    exit;
} 