<?php
session_start();
include_once("..\config\database.php");

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header("Location: connexion.php");
    exit();
}

// Récupérer l'ID de la réservation
$reservation_id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

if (!$reservation_id) {
    header("Location: ..\index.php");
    exit();
}

try {
    // Récupérer les détails de la réservation
    $stmt = $pdo->prepare("
        SELECT r.*, h.nom as hotel_nom, h.adresse as hotel_adresse 
        FROM reservations r 
        JOIN hotels h ON r.hotel_id = h.id 
        WHERE r.id = ? AND r.user_id = ?
    ");
    $stmt->execute([$reservation_id, $_SESSION['user_id']]);
    $reservation = $stmt->fetch();
    
    if (!$reservation) {
        header("Location: ..\index.php");
        exit();
    }
} catch (PDOException $e) {
    header("Location: ..\index.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Confirmation de Réservation - Bénin Tourisme</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .confirmation-container {
            padding-top: 100px;
            min-height: 100vh;
            background-color: #f8f9fa;
        }
        .confirmation-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0,0,0,0.1);
        }
        .status-badge {
            font-size: 0.9rem;
            padding: 0.5rem 1rem;
            border-radius: 20px;
        }
        .status-en_attente {
            background-color: #ffc107;
            color: #000;
        }
    </style>
</head>
<body>
    <?php include_once(__DIR__ . "/../includes/navbar.php"); ?>

    <div class="confirmation-container">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="confirmation-card p-4">
                        <div class="text-center mb-4">
                            <i class="fas fa-check-circle text-success" style="font-size: 4rem;"></i>
                            <h2 class="mt-3">Réservation Confirmée !</h2>
                            <p class="text-muted">Votre réservation a été enregistrée avec succès.</p>
                        </div>

                        <div class="reservation-details">
                            <h4 class="mb-3">Détails de la réservation</h4>
                            
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <p class="mb-1"><strong>Numéro de réservation :</strong></p>
                                    <p class="text-muted">#<?php echo str_pad($reservation['id'], 6, '0', STR_PAD_LEFT); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p class="mb-1"><strong>Statut :</strong></p>
                                    <span class="status-badge status-<?php echo $reservation['statut']; ?>">
                                        <?php echo ucfirst(str_replace('_', ' ', $reservation['statut'])); ?>
                                    </span>
                                </div>
                            </div>

                            <div class="hotel-info mb-4">
                                <h5>Hôtel</h5>
                                <p class="mb-1"><?php echo htmlspecialchars($reservation['hotel_nom']); ?></p>
                                <p class="text-muted"><?php echo htmlspecialchars($reservation['hotel_adresse']); ?></p>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <p class="mb-1"><strong>Date d'arrivée :</strong></p>
                                    <p class="text-muted"><?php echo date('d/m/Y', strtotime($reservation['date_arrivee'])); ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p class="mb-1"><strong>Date de départ :</strong></p>
                                    <p class="text-muted"><?php echo date('d/m/Y', strtotime($reservation['date_depart'])); ?></p>
                                </div>
                            </div>

                            <div class="row mb-4">
                                <div class="col-md-6">
                                    <p class="mb-1"><strong>Nombre de personnes :</strong></p>
                                    <p class="text-muted"><?php echo $reservation['nombre_personnes']; ?></p>
                                </div>
                                <div class="col-md-6">
                                    <p class="mb-1"><strong>Date de réservation :</strong></p>
                                    <p class="text-muted"><?php echo date('d/m/Y H:i', strtotime($reservation['date_creation'])); ?></p>
                                </div>
                            </div>

                            <?php if (!empty($reservation['commentaires'])): ?>
                            <div class="commentaires mb-4">
                                <h5>Commentaires</h5>
                                <p class="text-muted"><?php echo nl2br(htmlspecialchars($reservation['commentaires'])); ?></p>
                            </div>
                            <?php endif; ?>

                            <div class="text-center mt-4">
                                <a href="..\index.php" class="btn btn-primary me-2">
                                    <i class="fas fa-home me-2"></i>Retour à l'accueil
                                </a>
                                <a href="mes_reservations.php" class="btn btn-outline-primary">
                                    <i class="fas fa-list me-2"></i>Voir mes réservations
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include_once(__DIR__ . "/../includes/footer.php"); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 