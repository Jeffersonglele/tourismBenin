<?php
$host = 'localhost';
$dbname = 'tourism';
$username = 'root'; 
$password = '';    

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Création de la table publications si elle n'existe pas
    $pdo->exec("CREATE TABLE IF NOT EXISTS publications (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        titre VARCHAR(255) NOT NULL,
        contenu TEXT NOT NULL,
        media_path VARCHAR(255),
        media_type ENUM('image', 'video'),
        date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
        date_modification DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES utilisateurs(id) ON DELETE CASCADE
    )");

    // Création de la table likes si elle n'existe pas
    $pdo->exec("CREATE TABLE IF NOT EXISTS likes (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        publication_id INT NOT NULL,
        date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
        FOREIGN KEY (publication_id) REFERENCES publications(id) ON DELETE CASCADE,
        UNIQUE KEY unique_like (user_id, publication_id)
    )");
    
    // Création de la table commentaires si elle n'existe pas
    $pdo->exec("CREATE TABLE IF NOT EXISTS commentaires (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        publication_id INT NOT NULL,
        contenu TEXT NOT NULL,
        date_creation DATETIME DEFAULT CURRENT_TIMESTAMP,
        date_modification DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES utilisateurs(id) ON DELETE CASCADE,
        FOREIGN KEY (publication_id) REFERENCES publications(id) ON DELETE CASCADE
    )");

} catch (PDOException $e) {
    die("Erreur de connexion à la base de données : " . $e->getMessage());
}
?>
