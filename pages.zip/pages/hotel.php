<?php
session_start();
include_once("..\config\database.php");

$page_title = "Hôtels - Bénin Tourisme";

// Requête avec filtres
$sql = "SELECT * FROM hotels";
$params = [];
$where = [];

if (isset($_GET['etoiles']) && !empty($_GET['etoiles'])) {
    $where[] = "etoiles = ?";
    $params[] = $_GET['etoiles'];
}

if (isset($_GET['ville']) && !empty($_GET['ville'])) {
    $where[] = "ville = ?";
    $params[] = $_GET['ville'];
}

if (isset($_GET['budget']) && !empty($_GET['budget'])) {
    switch($_GET['budget']) {
        case 'economique':
            $where[] = "prix_min < 50000";
            break;
        case 'standard':
            $where[] = "prix_min BETWEEN 50000 AND 100000";
            break;
        case 'luxe':
            $where[] = "prix_min > 100000";
            break;
    }
}

if (!empty($where)) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$sql .= " ORDER BY prix_min ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$hotels = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr" class="scroll-smooth">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?= htmlspecialchars($page_title) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<style>
    .btn-reserve {
            background: #e67e22;
            color: white;
            padding: 1rem 2rem;
            border-radius: 30px;
            text-decoration: none;
            display: block;
            text-align: center;
            font-weight: bold;
            transition: all 0.3s ease;
        }
</style>
<body class="bg-gray-50 text-gray-800">
    <?php include_once(__DIR__ . "/../includes/navbar.php"); ?>

    <!-- Hero Section -->
    <section 
        class="relative bg-cover bg-center min-h-[60vh] flex items-center justify-center mb-12"
        style="background-image: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('../assets/images/hotel.jpeg');"
    >
        <div class="text-center max-w-3xl px-4">
            <h1 class="text-white text-4xl md:text-5xl font-bold mb-4 drop-shadow-lg">
                Nos Hôtels Partenaires
            </h1>
            <p class="text-white/90 text-lg md:text-xl mb-2 drop-shadow">
                Découvrez notre sélection d'hôtels confortables pour votre séjour au Bénin
            </p>
            <p class="text-white/70 text-md md:text-lg drop-shadow">
                Des hébergements de qualité pour tous les budgets
            </p>
        </div>
    </section>

    <main class="container mx-auto px-4 md:px-8 lg:px-12 flex flex-col md:flex-row gap-8">

        <!-- Filters -->
        <aside class="md:w-1/4 bg-white rounded-lg shadow p-6 sticky top-6 h-fit">
            <h2 class="text-xl font-semibold mb-6">Affiner votre recherche</h2>
            <form method="GET" id="filterForm" class="space-y-5">
                <div>
                    <label for="etoiles" class="block mb-1 font-medium">Nombre d'étoiles</label>
                    <select name="etoiles" id="etoiles" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="">Toutes les catégories</option>
                        <option value="3" <?= (isset($_GET['etoiles']) && $_GET['etoiles'] === '3') ? 'selected' : '' ?>>3 étoiles</option>
                        <option value="4" <?= (isset($_GET['etoiles']) && $_GET['etoiles'] === '4') ? 'selected' : '' ?>>4 étoiles</option>
                        <option value="5" <?= (isset($_GET['etoiles']) && $_GET['etoiles'] === '5') ? 'selected' : '' ?>>5 étoiles</option>
                    </select>
                </div>
                <div>
                    <label for="ville" class="block mb-1 font-medium">Ville</label>
                    <select name="ville" id="ville" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="">Toutes les villes</option>
                        <option value="Cotonou" <?= (isset($_GET['ville']) && $_GET['ville'] === 'Cotonou') ? 'selected' : '' ?>>Cotonou</option>
                        <option value="Porto-Novo" <?= (isset($_GET['ville']) && $_GET['ville'] === 'Porto-Novo') ? 'selected' : '' ?>>Porto-Novo</option>
                        <option value="Ouidah" <?= (isset($_GET['ville']) && $_GET['ville'] === 'Ouidah') ? 'selected' : '' ?>>Ouidah</option>
                        <option value="Abomey" <?= (isset($_GET['ville']) && $_GET['ville'] === 'Abomey') ? 'selected' : '' ?>>Abomey</option>
                    </select>
                </div>
                <div>
                    <label for="budget" class="block mb-1 font-medium">Budget</label>
                    <select name="budget" id="budget" class="w-full rounded-md border border-gray-300 px-3 py-2 focus:outline-none focus:ring-2 focus:ring-indigo-500">
                        <option value="">Tous les budgets</option>
                        <option value="economique" <?= (isset($_GET['budget']) && $_GET['budget'] === 'economique') ? 'selected' : '' ?>>Économique (&lt; 50 000 FCFA)</option>
                        <option value="standard" <?= (isset($_GET['budget']) && $_GET['budget'] === 'standard') ? 'selected' : '' ?>>Standard (50 000 - 100 000 FCFA)</option>
                        <option value="luxe" <?= (isset($_GET['budget']) && $_GET['budget'] === 'luxe') ? 'selected' : '' ?>>Luxe (&gt; 100 000 FCFA)</option>
                    </select>
                </div>
                <div class="flex flex-col gap-2">
                    <button type="submit" class="bg-indigo-600 text-white font-semibold py-2 rounded hover:bg-indigo-700 transition">
                        <i class="fas fa-filter mr-2"></i> Filtrer
                    </button>
                    <a href="hotel.php" class="text-center text-indigo-600 border border-indigo-600 rounded py-2 hover:bg-indigo-600 hover:text-white transition">
                        <i class="fas fa-undo mr-2"></i> Réinitialiser
                    </a>
                </div>
            </form>

            <?php if (!empty($_GET)): ?>
                <div class="mt-6">
                    <h3 class="text-lg font-semibold mb-3">Filtres actifs :</h3>
                    <div class="flex flex-wrap gap-2">
                        <?php if (!empty($_GET['etoiles'])): ?>
                            <span class="bg-indigo-100 text-indigo-700 rounded-full px-3 py-1 text-sm font-medium">
                                <?= htmlspecialchars($_GET['etoiles']) ?> étoiles
                            </span>
                        <?php endif; ?>
                        <?php if (!empty($_GET['ville'])): ?>
                            <span class="bg-indigo-100 text-indigo-700 rounded-full px-3 py-1 text-sm font-medium">
                                <?= htmlspecialchars($_GET['ville']) ?>
                            </span>
                        <?php endif; ?>
                        <?php if (!empty($_GET['budget'])): ?>
                            <span class="bg-indigo-100 text-indigo-700 rounded-full px-3 py-1 text-sm font-medium">
                                Budget : <?= htmlspecialchars($_GET['budget']) ?>
                            </span>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </aside>

        <!-- Hotel List -->
        <section class="md:w-3/4 grid grid-cols-1 sm:grid-cols-2 gap-8">
            <?php if (empty($hotels)): ?>
                <div class="col-span-full text-center py-16 text-gray-600">
                    <h3 class="text-2xl font-semibold mb-2">Aucun hôtel disponible</h3>
                    <p>Aucun hôtel ne correspond à vos critères de recherche.</p>
                </div>
            <?php else: ?>
                <?php foreach ($hotels as $hotel): ?>
                    <article class="bg-white rounded-lg shadow-md overflow-hidden flex flex-col hover:shadow-lg transition">
                        <div class="relative overflow-hidden h-64">
                            <img src="<?= htmlspecialchars($hotel['image']) ?>" alt="<?= htmlspecialchars($hotel['nom']) ?>" class="w-full h-full object-cover transition-transform duration-300 hover:scale-105" />
                            <div class="absolute top-4 right-4 bg-gray-700 bg-opacity-70 text-white rounded-full px-3 py-1 flex items-center space-x-1 text-sm select-none">
                                <?php 
                                for ($i = 0; $i < $hotel['etoiles']; $i++) {
                                    echo '<svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 fill-yellow-400" viewBox="0 0 20 20" fill="currentColor"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.286 3.958a1 1 0 00.95.69h4.162c.969 0 1.371 1.24.588 1.81l-3.37 2.448a1 1 0 00-.364 1.118l1.287 3.957c.3.921-.755 1.688-1.54 1.118l-3.37-2.447a1 1 0 00-1.176 0l-3.37 2.447c-.784.57-1.838-.197-1.539-1.118l1.287-3.957a1 1 0 00-.364-1.118L2.034 9.385c-.783-.57-.38-1.81.588-1.81h4.162a1 1 0 00.95-.69l1.286-3.958z" /></svg>';
                                }
                                ?>
                            </div>
                        </div>
                        <div class="p-6 flex flex-col flex-grow">
                            <h3 class="text-xl font-semibold mb-2 text-indigo-800"><?= htmlspecialchars($hotel['nom']) ?></h3>
                            <p class="text-gray-600 mb-4 flex-grow"><?= htmlspecialchars(mb_strimwidth($hotel['description'], 0, 100, '...')) ?></p>

                            <div class="mb-5 space-y-1">
                                <p class="flex items-center text-gray-700">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2 text-indigo-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17.657 16.657L13.414 12.414a2 2 0 10-2.828 2.828l4.243 4.243a8 8 0 1111.314-11.314 8 8 0 01-11.314 11.314z" />
                                    </svg>
                                    <?= htmlspecialchars($hotel['ville']) ?>
                                </p>
                                <p class="text-indigo-700 font-semibold text-lg">
                                    À partir de <?= number_format($hotel['prix_min'], 0, ',', ' ') ?> FCFA / nuit
                                </p>
                            </div>

                            <?php if (isset($_SESSION['user_id'])): ?>
                                <a href="../pages/hotel_detail.php?id=<?= $hotel['id'] ?>" 
                                   class="mt-auto inline-flex items-center justify-center bg-indigo-600 text-white font-semibold rounded-md py-3 px-5 hover:bg-indigo-700 transition">
                                    <i class="fas fa-calendar-check mr-2"></i> Réserver
                                </a>
                                <?php else: ?>
                                    <a href="../pages/connexion.php?redirect=<?= urlencode('hotel_detail.php?id=' . $hotel['id']) ?>" class="bg-indigo-600 text-white font-semibold py-2 rounded hover:bg-indigo-700 transition">
                                        <i class="fas fa-filter mr-2"></i>
                                        Se connecter pour réserver
                                    </a>
                                <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            <?php endif; ?>
        </section>
    </main>
    <?php include_once(__DIR__ . "/../includes/footer.php"); ?>

</body>
</html>
