<?php
// Connexion à la base de données (modifie selon tes infos)
require_once '../config/database.php'; // à adapter selon ton projet

// Récupération et validation des champs
$nom = $_POST['nom'] ?? '';
$description = $_POST['description'] ?? '';
$date_debut = $_POST['date_debut'] ?? '';
$date_fin = $_POST['date_fin'] ?? '';
$heure = $_POST['heure'] ?? '';
$ville = $_POST['ville'] ?? '';
$prix = $_POST['prix'] ?? 0;
$site = $_POST['site'] ?? '';
$incitation = $_POST['incitation'] ?? '';

// Gestion de l'upload d'image
$image_name = '';
if (isset($_FILES['image']) && $_FILES['image']['error'] === 0) {
    $upload_dir = '../assets/images/';
    $tmp_name = $_FILES['image']['tmp_name'];
    $original_name = basename($_FILES['image']['name']);
    $extension = pathinfo($original_name, PATHINFO_EXTENSION);
    $image_name = uniqid('img_') . '.' . $extension;
    $destination = $upload_dir . $image_name;

    // Déplacement de l'image
    if (!move_uploaded_file($tmp_name, $destination)) {
        die("Erreur lors du téléchargement de l'image.");
    }
} else {
    die("Aucune image envoyée ou erreur.");
}

// Insertion en base de données
$sql = "INSERT INTO evenements (nom, description, date_debut, date_fin, heure, ville, prix, image, site, incitation)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

$stmt = $pdo->prepare($sql);
$success = $stmt->execute([$nom, $description, $date_debut, $date_fin, $heure, $ville, $prix, $image_name, $site, $incitation]);

if ($success) {

    $_SESSION['message'] = "✅ Lieu ajouté avec succès !";
    $_SESSION['message_type'] = "success"; // ou "error", selon le besoin
    header('Location: evenements.php');
    exit();
}else {
    $_SESSION['message'] = "erreur lors de l'ajout ";
$_SESSION['message_type'] = "warning"; // ou "error", selon le besoin
header('Location: evenements.php');
}
?>
