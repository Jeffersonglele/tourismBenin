<?php
session_start();
include_once("..\config\database.php");

// Vérifier si l'utilisateur est connecté
if (!isset($_SESSION['user_id'])) {
    header('Location: connexion.php');
    exit;
}

// Vérifier si l'ID de l'événement est présent
if (!isset($_GET['id'])) {
    header('Location: evenements.php');
    exit;
}

$event_id = $_GET['id'];
$user_id = $_SESSION['user_id'];
$success = false;
$error = null;

// Récupérer les informations de l'événement
$stmt = $pdo->prepare("SELECT * FROM evenements WHERE id = ?");
$stmt->execute([$event_id]);
$evenement = $stmt->fetch();

if (!$evenement) {
    header('Location: evenements.php');
    exit;
}

// Traitement du formulaire de réservation
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nombre_places = isset($_POST['nombre_places']) ? intval($_POST['nombre_places']) : 0;
    
    if ($nombre_places <= 0) {
        $error = "Le nombre de places doit être supérieur à 0";
    } else {
        try {
            // Vérifier si l'utilisateur a déjà réservé pour cet événement
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM reservations_evenements WHERE id_utilisateur = ? AND id_evenement = ?");
            $stmt->execute([$user_id, $event_id]);
            $existe = $stmt->fetchColumn() > 0;
            
            if ($existe) {
                $error = "Vous avez déjà réservé pour cet événement";
            } else {
                // Insérer la réservation
                $stmt = $pdo->prepare("INSERT INTO reservations_evenements (id_utilisateur, id_evenement, nombre_places, date_reservation) VALUES (?, ?, ?, NOW())");
                $stmt->execute([$user_id, $event_id, $nombre_places]);
                $success = true;
            }
        } catch (PDOException $e) {
            $error = "Une erreur est survenue lors de la réservation";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réservation - <?= htmlspecialchars($evenement['nom']) ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .reservation-header {
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), 
                        url('<?= htmlspecialchars($evenement['image']) ?>');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 4rem 0;
            margin-bottom: 2rem;
        }
        .event-details {
            background: #f8f9fa;
            padding: 2rem;
            border-radius: 10px;
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>
    <?php include_once(__DIR__ . "/../includes/navbar.php"); ?>

    <header class="reservation-header">
        <div class="container text-center">
            <h1 class="display-4">Réservation pour <?= htmlspecialchars($evenement['nom']) ?></h1>
            <p class="lead">Réservez vos places pour cet événement unique</p>
        </div>
    </header>

    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <?php if ($success): ?>
                    <div class="alert alert-success">
                        <i class="fas fa-check-circle me-2"></i>
                        Votre réservation a été effectuée avec succès ! 
                        <a href="mes_reservations.php" class="alert-link">Voir mes réservations</a>
                    </div>
                <?php endif; ?>

                <?php if ($error): ?>
                    <div class="alert alert-danger">
                        <i class="fas fa-exclamation-circle me-2"></i>
                        <?= $error ?>
                    </div>
                <?php endif; ?>

                <div class="event-details">
                    <h3>Détails de l'événement</h3>
                    <p><strong>Date :</strong> <?= htmlspecialchars($evenement['date_evenement']) ?></p>
                    <p><strong>Lieu :</strong> <?= htmlspecialchars($evenement['lieu']) ?></p>
                    <p><strong>Prix :</strong> <?= number_format($evenement['prix'], 2, ',', ' ') ?> FCFA</p>
                    <p><?= nl2br(htmlspecialchars($evenement['description'])) ?></p>
                </div>

                <?php if (!$success): ?>
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h3 class="card-title">Formulaire de réservation</h3>
                            <form method="POST" action="">
                                <div class="mb-3">
                                    <label for="nombre_places" class="form-label">Nombre de places</label>
                                    <input type="number" class="form-control" id="nombre_places" name="nombre_places" min="1" required>
                                </div>
                                <button type="submit" class="btn btn-primary">
                                    <i class="fas fa-ticket-alt me-2"></i>
                                    Réserver
                                </button>
                            </form>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <?php include_once(__DIR__ . "/../includes/footer.php"); ?>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 