<?php
session_start();
include_once("../config/database.php");

// Récupération des événements depuis la base de données avec filtres
$sql = "SELECT * FROM evenements";
$params = [];
$where = [];

if (isset($_GET['type']) && !empty($_GET['type'])) {
    $where[] = "type = ?";
    $params[] = $_GET['type'];
}

if (isset($_GET['ville']) && !empty($_GET['ville'])) {
    $where[] = "ville = ?";
    $params[] = $_GET['ville'];
}

if (isset($_GET['periode']) && !empty($_GET['periode'])) {
    $today = date('Y-m-d');
    switch($_GET['periode']) {
        case 'semaine':
            $where[] = "date_debut <= DATE_ADD(CURDATE(), INTERVAL 7 DAY) AND date_fin >= CURDATE()";
            break;
        case 'mois':
            $where[] = "date_debut <= LAST_DAY(CURDATE()) AND date_fin >= CURDATE()";
            break;
        case 'trimestre':
            $where[] = "date_debut <= DATE_ADD(CURDATE(), INTERVAL 3 MONTH) AND date_fin >= CURDATE()";
            break;
    }
}

if (!empty($where)) {
    $sql .= " WHERE " . implode(" AND ", $where);
}

$sql .= " ORDER BY date_debut ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$evenements = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Événements - Bénin Tourisme</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#2F855A',
                        secondary: '#DD6B20',
                        dark: '#1A202C',
                    },
                    fontFamily: {
                        sans: ['Poppins', 'sans-serif'],
                    },
                }
            }
        }
    </script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        
        body {
            font-family: 'Poppins', sans-serif;
        }
        
        .hero-section {
            background: linear-gradient(rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.7)), 
                        url('../assets/images/defile.jpeg');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        
        .event-card {
            transition: all 0.3s ease;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }
        
        .event-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.15);
        }
        
        .event-card img {
            transition: transform 0.3s ease;
        }
        
        .event-card:hover img {
            transform: scale(1.05);
        }
        
        .filter-card {
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.05);
        }
        
        .select-input {
            transition: all 0.3s ease;
            border: 1px solid #e2e8f0;
        }
        
        .select-input:focus {
            border-color: #2F855A;
            box-shadow: 0 0 0 3px rgba(47, 133, 90, 0.2);
        }
    </style>
</head>
<body class="bg-gray-50">
    <?php include_once(__DIR__ . "/../includes/navbar.php"); ?>

    <!-- Hero Section -->
    <section class="hero-section flex items-center justify-center py-20">
        <div class="container mx-auto px-4 text-center">
            <h1 class="text-4xl md:text-5xl font-bold text-white mb-4" data-aos="fade-up">
                Événements Culturels
            </h1>
            <p class="text-xl text-white max-w-2xl mx-auto" data-aos="fade-up" data-aos-delay="100">
                Découvrez les événements à ne pas manquer au Bénin
            </p>
            <p class="text-white/80 mt-2" data-aos="fade-up" data-aos-delay="200">
                Des expériences culturelles uniques
            </p>
        </div>
    </section>

    <!-- Events Section -->
    <section class="py-16">
        <div class="container mx-auto px-4">
            <div class="grid grid-cols-1 lg:grid-cols-4 gap-8">
                <!-- Filters -->
                <div class="lg:col-span-1">
                    <div class="bg-white rounded-xl filter-card p-6 sticky top-6">
                        <h3 class="text-xl font-bold text-gray-800 mb-6">Affiner votre recherche</h3>
                        
                        <form id="filterForm" method="GET" class="space-y-4">
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Type d'événement</label>
                                <select name="type" class="w-full px-4 py-2 rounded-lg select-input focus:outline-none">
                                    <option value="">Tous les types</option>
                                    <option value="festival" <?= (isset($_GET['type']) && $_GET['type'] === 'festival') ? 'selected' : '' ?>>Festival</option>
                                    <option value="ceremonie" <?= (isset($_GET['type']) && $_GET['type'] === 'ceremonie') ? 'selected' : '' ?>>Cérémonie</option>
                                    <option value="exposition" <?= (isset($_GET['type']) && $_GET['type'] === 'exposition') ? 'selected' : '' ?>>Exposition</option>
                                    <option value="concert" <?= (isset($_GET['type']) && $_GET['type'] === 'concert') ? 'selected' : '' ?>>Concert</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Ville</label>
                                <select name="ville" class="w-full px-4 py-2 rounded-lg select-input focus:outline-none">
                                    <option value="">Toutes les villes</option>
                                    <option value="cotonou" <?= (isset($_GET['ville']) && $_GET['ville'] === 'cotonou') ? 'selected' : '' ?>>Cotonou</option>
                                    <option value="porto-novo" <?= (isset($_GET['ville']) && $_GET['ville'] === 'porto-novo') ? 'selected' : '' ?>>Porto-Novo</option>
                                    <option value="ouidah" <?= (isset($_GET['ville']) && $_GET['ville'] === 'ouidah') ? 'selected' : '' ?>>Ouidah</option>
                                    <option value="abomey" <?= (isset($_GET['ville']) && $_GET['ville'] === 'abomey') ? 'selected' : '' ?>>Abomey</option>
                                </select>
                            </div>
                            
                            <div>
                                <label class="block text-sm font-medium text-gray-700 mb-1">Période</label>
                                <select name="periode" class="w-full px-4 py-2 rounded-lg select-input focus:outline-none">
                                    <option value="">Toutes les périodes</option>
                                    <option value="semaine" <?= (isset($_GET['periode']) && $_GET['periode'] === 'semaine') ? 'selected' : '' ?>>Cette semaine</option>
                                    <option value="mois" <?= (isset($_GET['periode']) && $_GET['periode'] === 'mois') ? 'selected' : '' ?>>Ce mois</option>
                                    <option value="trimestre" <?= (isset($_GET['periode']) && $_GET['periode'] === 'trimestre') ? 'selected' : '' ?>>Ce trimestre</option>
                                </select>
                            </div>
                            
                            <div class="grid grid-cols-2 gap-3 pt-2">
                                <button type="submit" class="w-full bg-primary hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg transition">
                                    <i class="fas fa-filter mr-2"></i>Filtrer
                                </button>
                                <a href="evenements.php" class="w-full bg-gray-200 hover:bg-gray-300 text-gray-800 font-medium py-2 px-4 rounded-lg text-center transition">
                                    <i class="fas fa-undo mr-2"></i>Réinitialiser
                                </a>
                            </div>
                        </form>

                        <?php if (!empty($_GET)): ?>
                            <div class="mt-6 pt-4 border-t border-gray-200">
                                <h4 class="text-sm font-medium text-gray-700 mb-2">Filtres actifs :</h4>
                                <div class="flex flex-wrap gap-2">
                                    <?php if (!empty($_GET['type'])): ?>
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
                                            Type: <?= htmlspecialchars($_GET['type']) ?>
                                        </span>
                                    <?php endif; ?>
                                    <?php if (!empty($_GET['ville'])): ?>
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
                                            Ville: <?= htmlspecialchars($_GET['ville']) ?>
                                        </span>
                                    <?php endif; ?>
                                    <?php if (!empty($_GET['periode'])): ?>
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-primary/10 text-primary">
                                            Période: <?= htmlspecialchars($_GET['periode']) ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Events List -->
                <div class="lg:col-span-3">
                    <?php if (empty($evenements)): ?>
                        <div class="bg-white rounded-xl p-8 text-center">
                            <h3 class="text-xl font-medium text-gray-800 mb-2">Aucun événement disponible</h3>
                            <p class="text-gray-600">Aucun événement ne correspond à vos critères de recherche.</p>
                        </div>
                    <?php else: ?>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <?php foreach ($evenements as $evenement): ?>
                                <div class="event-card bg-white rounded-xl overflow-hidden" data-aos="fade-up">
                                    <div class="relative overflow-hidden">
                                        <img src="<?= htmlspecialchars($evenement['image']) ?>" 
                                             alt="<?= htmlspecialchars($evenement['nom']) ?>" 
                                             class="w-full h-56 object-cover">
                                        <div class="absolute top-4 right-4 bg-white/90 text-gray-800 px-3 py-1 rounded-full text-sm font-medium">
                                            <?= date('d M', strtotime($evenement['date_debut'])) ?>
                                        </div>
                                    </div>
                                    <div class="p-6">
                                        <h3 class="text-xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($evenement['nom']) ?></h3>
                                        <p class="text-gray-600 mb-4"><?= htmlspecialchars(substr($evenement['description'], 0, 100)) ?>...</p>
                                        
                                        <div class="space-y-2 mb-5">
                                            <div class="flex items-center text-gray-700">
                                                <i class="fas fa-calendar-alt text-primary mr-2"></i>
                                                <span>Du <?= date('d/m/Y', strtotime($evenement['date_debut'])) ?> au <?= date('d/m/Y', strtotime($evenement['date_fin'])) ?></span>
                                            </div>
                                            <div class="flex items-center text-gray-700">
                                                <i class="fas fa-clock text-primary mr-2"></i>
                                                <span><?= $evenement['heure'] ?></span>
                                            </div>
                                            <div class="flex items-center text-gray-700">
                                                <i class="fas fa-map-marker-alt text-primary mr-2"></i>
                                                <span><?= htmlspecialchars($evenement['ville']) ?></span>
                                            </div>
                                            <div class="text-lg font-semibold text-gray-800 mt-3">
                                                <?= number_format($evenement['prix'], 0, ',', ' ') ?> FCFA
                                            </div>
                                        </div>
                                        
                                        <a href="evenement_detail.php?id=<?= $evenement['id'] ?>" class="block w-full bg-primary hover:bg-green-700 text-white font-medium py-2 px-4 rounded-lg text-center transition">
                                            <i class="fas fa-info-circle mr-2"></i>
                                            Voir les détails
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <?php include_once(__DIR__ . "/../includes/footer.php"); ?>

    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 800,
            once: true,
            easing: 'ease-out-quad'
        });
    </script>
</body>
</html>