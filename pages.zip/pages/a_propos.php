<?php include_once(__DIR__ . "/../includes/navbar.php"); ?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>À Propos - Bénin Tourisme</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .hero-section {
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)),
                        url('../assets/images/collage.jpeg');
            background-size: cover;
            background-position: center;
            color: white;
            padding: 8rem 0;
            margin-bottom: 3rem;
            min-height: 80vh;
            display: flex;
            align-items: center;
            position: relative;
        }
        .hero-section .container {
            position: relative;
            z-index: 2;
        }
        .hero-section h1 {
            font-size: 3.5rem;
            margin-bottom: 1.5rem;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        .hero-section .lead {
            font-size: 1.4rem;
            max-width: 800px;
            margin: 0 auto;
            text-shadow: 1px 1px 2px rgba(0,0,0,0.3);
        }
        .section-image {
            width: 100%;
            height: 300px;
            object-fit: cover;
            border-radius: 10px;
            margin-bottom: 1.5rem;
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            transition: transform 0.3s ease;
        }
        .section-image:hover {
            transform: scale(1.03);
        }
        .stat-card {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            text-align: center;
            transition: transform 0.3s ease;
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .stat-number {
            font-size: 2.5rem;
            font-weight: bold;
            color: #0d6efd;
            margin-bottom: 0.5rem;
        }
        .content-section {
            padding: 4rem 0;
        }
        .section-title {
            margin-bottom: 2rem;
            position: relative;
            padding-bottom: 1rem;
        }
        .section-title::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100px;
            height: 3px;
            background-color: #0d6efd;
        }
    </style>
</head>
<body>
    <!-- Section Héro -->
    <section class="hero-section text-center">
        <div class="container">
            <h1 class="display-4">Découvrez l'Héritage du Bénin</h1>
            <p class="lead">Bienvenue au Bénin, une terre riche en histoire et en culture vibrante. Rejoignez BéninDécouverte pour explorer les royaumes anciens, les marchés animés et les paysages à couper le souffle. Découvrez le cœur de l'Afrique de l'Ouest avec nos circuits et expériences soigneusement sélectionnés. Commencez votre aventure aujourd'hui !</p>
        </div>
    </section>

    <!-- Section Histoire -->
    <section class="content-section">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <img src="..\assets\images\Monuments Bio Guera.jpeg" alt="Histoire du Bénin" class="section-image">
                </div>
                <div class="col-md-6">
                    <h2 class="section-title">Explorez l'Histoire Riche du Bénin</h2>
                    <p>Plongez dans le passé fascinant du Bénin, où les royaumes anciens ont prospéré et les cultures vibrantes se sont épanouies. Ce voyage dans le temps révèle les racines du riche patrimoine du Bénin, mettant en lumière son importance dans l'histoire de l'Afrique de l'Ouest.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Section Culture -->
    <section class="content-section bg-light">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 order-md-2">
                    <img src="..\assets\images\Tradition.jpeg" alt="Culture du Bénin" class="section-image">
                </div>
                <div class="col-md-6 order-md-1">
                    <h2 class="section-title">Découvrez la Culture Vibrante</h2>
                    <p>Le Bénin est une terre de traditions riches et de cultures vibrantes, où les pratiques ancestrales se mêlent harmonieusement aux influences modernes. Des festivals colorés aux formes d'art uniques, chaque aspect de la culture béninoise raconte une histoire qui attend d'être découverte.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Section Statistiques -->
    <section class="content-section">
        <div class="container">
            <div class="row">
                <div class="col-md-3 mb-4 ">
                    <div class="stat-card">
                    <img src="..\assets\images\art.jpg" alt="Art du Bénin" class="section-image">
                        
                        <div class="stat-number">500+</div>
                        <h3 class="h5">Œuvres d'Art</h3>
                        <p>Explorez la diversité des artisanats traditionnels, incluant les textiles complexes et les sculptures impressionnantes qui reflètent la créativité des artisans locaux.</p>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stat-card">
                    <img src="..\assets\images\festival.jpeg" alt="Festivals du Bénin" class="section-image">
                        <div class="stat-number">200+</div>
                        <h3 class="h5">Festivals</h3>
                        <p>Participez aux célébrations des festivals animés du Bénin, où la musique, la danse et les rituels traditionnels se réunissent pour créer des expériences inoubliables.</p>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stat-card">
                    <img src="..\assets\images\cuisine.jpeg" alt="Cuisine du Bénin" class="section-image">
                        <div class="stat-number">30+</div>
                        <h3 class="h5">Cuisines</h3>
                        <p>Savourez les saveurs du Bénin à travers ses délicieuses cuisines, qui sont une fusion d'ingrédients locaux et de traditions culinaires transmises de génération en génération.</p>
                    </div>
                </div>
                <div class="col-md-3 mb-4">
                    <div class="stat-card">
                    <img src="..\assets\images\langues.jpg" alt="Langues du Bénin" class="section-image">
                        <div class="stat-number">15+</div>
                        <h3 class="h5">Langues</h3>
                        <p>Découvrez la diversité linguistique du Bénin, où de multiples langues sont parlées, chacune ajoutant à la riche tapisserie de l'identité de la nation.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include_once(__DIR__ . "/../includes/footer.php"); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 