<?php
session_start();
require 'connexion.php';

// Récupérer tous les posts
$posts = $pdo->query("
    SELECT posts.*, utilisateurs.nom, utilisateurs.prenom 
    FROM posts 
    JOIN utilisateurs ON posts.utilisateur_id = utilisateurs.id 
    ORDER BY posts.date_post DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Posts</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <?php include_once(__DIR__ . "/../includes/navbar.php"); ?>

    <div class="max-w-4xl mx-auto mt-10 space-y-6">
        <?php foreach ($posts as $post): ?>
        <div class="bg-white p-6 rounded-xl shadow-md">
            <div class="flex justify-between items-center mb-2">
                <p class="text-sm text-gray-600">Posté par <strong><?= htmlspecialchars($post['prenom'] . ' ' . $post['nom']) ?></strong> le <?= date('d/m/Y H:i', strtotime($post['date_post'])) ?></p>
            </div>

            <?php if ($post['type_media'] == 'image'): ?>
                <img src="<?= htmlspecialchars($post['media']) ?>" alt="post image" class="w-full rounded-lg">
            <?php elseif ($post['type_media'] == 'video'): ?>
                <video controls class="w-full rounded-lg">
                    <source src="<?= htmlspecialchars($post['media']) ?>" type="video/mp4">
                    Votre navigateur ne prend pas en charge la vidéo.
                </video>
            <?php endif; ?>

            <?php if (!empty($post['texte'])): ?>
                <p class="mt-3"><?= nl2br(htmlspecialchars($post['texte'])) ?></p>
            <?php endif; ?>

            <div class="flex justify-between mt-4">
                <!-- Likes -->
                <form action="like_post.php" method="post">
                    <input type="hidden" name="post_id" value="<?= $post['id'] ?>">
                    <button type="submit" class="text-blue-500 hover:underline">❤️ J'aime</button>
                </form>

                <!-- Commentaires -->
                <a href="commentaires.php?post_id=<?= $post['id'] ?>" class="text-gray-700 hover:underline">💬 Commenter</a>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <?php include_once(__DIR__ . "/../includes/footer.php"); ?>
</body>
</html>
