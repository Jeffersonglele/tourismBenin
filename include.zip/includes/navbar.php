<?php
// Démarrage systématique de session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Chemin de base absolu
$base_path = '/stage/ProjetBinome/'; // Chemin corrigé pour correspondre à la structure du projet

// Détermination de la page active
$current_script = basename($_SERVER['SCRIPT_NAME']);
$current_page = str_replace('.php', '', $current_script);

// Menu unifié avec icônes
$menu_items = [
    'destinations' => ['title' => 'Destinations', 'url' => $base_path . 'pages/destinations.php', 'icon' => 'fa-map-marked-alt'],
    'hotels' => ['title' => 'Hôtels', 'url' => $base_path . 'pages/hotel.php', 'icon' => 'fa-hotel'],
    'circuits' => ['title' => 'Circuits', 'url' => $base_path . 'pages/circuits.php', 'icon' => 'fa-route'],
    'evenements' => ['title' => 'Evènements', 'url' => $base_path . 'pages/evenements.php', 'icon' => 'fa-calendar-alt'],
    'blog' => ['title' => 'Blog', 'url' => $base_path . 'pages/blog.php', 'icon' => 'fa-blog'],
    'contact' => ['title' => 'Contact', 'url' => $base_path . 'pages/contact.php', 'icon' => 'fa-envelope'],
    'gestionnaire' => ['title' => 'Gestionnaire', 'url' => $base_path . 'pages/gestion.php', 'icon' => 'fa-user-tie']
];

// Pages où afficher les boutons de connexion
$auth_pages = ['blogs','gestionnaire'];
$show_auth_buttons = in_array($current_page, $auth_pages);

// Vérifier si l'utilisateur est connecté
$isLoggedIn = isset($_SESSION['user_id']);
$isAdmin = isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'admin';

// Récupérer les informations de l'utilisateur si connecté
$user_name = '';
if ($isLoggedIn && !$isAdmin) {
    require_once (__DIR__ . '/../config/database.php');
    $stmt = $pdo->prepare("SELECT prenom, nom FROM utilisateurs WHERE id = ?");
    $stmt->execute([$_SESSION['user_id']]);
    $user = $stmt->fetch();
    if ($user) {
        $user_name = $user['prenom'] . ' ' . $user['nom'];
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bénin Tourisme</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        .dropdown-menu {
            display: none;
            opacity: 0;
            transform: translateY(-10px);
            transition: opacity 0.2s ease, transform 0.2s ease;
        }
        
        .dropdown:hover .dropdown-menu,
        .dropdown:focus-within .dropdown-menu {
            display: block;
            opacity: 1;
            transform: translateY(0);
        }
        
        /* Fix pour le z-index */
        nav {
            z-index: 1000;
        }
        
        .dropdown-menu {
            z-index: 1001;
        }
        
        /* Compensation pour la navbar fixe */
        body {
            padding-top: 4rem;
        }
        
        /* Ajustement pour les petits écrans */
        @media (max-width: 640px) {
            .auth-buttons-mobile {
                display: flex !important;
                flex-direction: column;
                padding: 0.5rem 0;
            }
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Navbar Structure -->
    <nav class="bg-white shadow-lg fixed top-0 w-full">
        <div class="container mx-auto px-4">
            <div class="flex justify-between items-center h-16">

                <!-- Logo -->
                <div class="flex-shrink-0 flex items-center">
                    <a href="<?= $base_path ?>index.php" class="flex items-center no-underline">
                        <img src="<?= $base_path ?>assets/images/icon.png" 
                             alt="Bénin Tourisme" 
                             class="h-10 w-auto"
                             onerror="this.src='<?= $base_path ?>assets/images/default-logo.png'">
                        <span class="ml-2 text-xl font-bold text-gray-800">Bénin Tourisme</span>
                    </a>
                </div>

                <!-- Menu Desktop -->
                <div class="hidden md:flex items-center space-x-1">
                    <?php foreach ($menu_items as $page => $item): ?>
                        <a href="<?= $item['url'] ?>" 
                           class="<?= ($current_page === $page) ? 'bg-gray-100 text-primary' : 'text-gray-600 hover:bg-gray-50' ?> 
                                  px-4 py-2 rounded-md text-sm font-medium transition-colors duration-200 flex items-center">
                            <i class="fas <?= $item['icon'] ?> mr-2 text-sm"></i>
                            <?= $item['title'] ?>
                        </a>
                    <?php endforeach; ?>
                </div>

                <!-- Section Utilisateur -->
                <div class="flex items-center ml-4">
                    <?php if ($isAdmin): ?>
                        <a href="/stage/ProjetBinome/admin/dashboard.php" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                            <i class="fas fa-user-shield mr-2"></i>
                            Administration
                        </a>
                    <?php elseif ($isLoggedIn): ?>
                        <div class="relative" x-data="{ open: false }">
                            <button @click="open = !open" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                                <i class="fas fa-user mr-2"></i>
                                <?php echo htmlspecialchars($user_name); ?>
                            </button>
                            <div x-show="open" @click.away="open = false" class="absolute right-0 mt-2 w-48 rounded-md shadow-lg bg-white ring-1 ring-black ring-opacity-5">
                                <div class="py-1">
                                    <a href="/stage/ProjetBinome/pages/gestion.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                        Mon espace
                                    </a>
                                    <?php if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'gestionnaire'): ?>
                                        <a href="/stage/ProjetBinome/pages/tableau_bord.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                            Tableau de bord
                                        </a>
                                    <?php endif; ?>
                                    <a href="/stage/ProjetBinome/pages/profil.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                        Mon profil
                                    </a>
                                    <a href="/stage/ProjetBinome/pages/deconnexion.php" class="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-100">
                                        Déconnexion
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php elseif ($show_auth_buttons): ?>
                        <div class="space-x-4">
                            <a href="/stage/ProjetBinome/pages/connexion.php" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700">
                                <i class="fas fa-sign-in-alt mr-2"></i>
                                Connexion
                            </a>
                            <a href="/stage/ProjetBinome/pages/inscription.php" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-blue-600 bg-blue-100 hover:bg-blue-200">
                                <i class="fas fa-user-plus mr-2"></i>
                                Inscription
                            </a>
                        </div>
                    <?php endif; ?>

                    <!-- Bouton Mobile -->
                    <button id="mobile-menu-button" class="md:hidden text-gray-500 hover:text-gray-900 focus:outline-none ml-4">
                        <svg class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"/>
                        </svg>
                    </button>
                </div>
            </div>
        </div>

        <!-- Menu Mobile -->
        <div id="mobile-menu" class="md:hidden hidden bg-white border-t">
            <div class="px-2 pt-2 pb-3 space-y-1">
                <?php foreach ($menu_items as $page => $item): ?>
                    <a href="<?= $item['url'] ?>" 
                       class="<?= ($current_page === $page) ? 'bg-gray-100 text-primary' : 'text-gray-600 hover:bg-gray-50' ?> 
                              block px-3 py-2 rounded-md text-base font-medium flex items-center">
                        <i class="fas <?= $item['icon'] ?> mr-3 w-5 text-center"></i>
                        <?= $item['title'] ?>
                    </a>
                <?php endforeach; ?>

                <?php if ($isAdmin): ?>
                    <div class="pt-4 border-t">
                        <a href="/stage/ProjetBinome/admin/dashboard.php" class="block px-3 py-2 text-gray-600 hover:bg-gray-50 flex items-center">
                            <i class="fas fa-user-shield mr-3 w-5 text-center"></i>
                            Administration
                        </a>
                    </div>
                <?php elseif ($isLoggedIn): ?>
                    <div class="pt-4 border-t">
                        <div class="px-3 py-2 flex items-center text-gray-800">
                            <img src="<?= $base_path ?>assets/images/users.jpg" 
                                 alt="Photo de profil" 
                                 class="h-8 w-8 rounded-full border-2 border-gray-200 object-cover mr-3"
                                 onerror="this.src='<?= $base_path ?>assets/images/default-user.png'">
                            <?php echo htmlspecialchars($user_name); ?>
                        </div>
                        <a href="/stage/ProjetBinome/pages/gestion.php" class="block px-3 py-2 text-gray-600 hover:bg-gray-50 flex items-center pl-11">
                            <i class="fas fa-user-shield mr-3 w-5 text-center"></i>Mon espace
                        </a>
                        <?php if (isset($_SESSION['user_type']) && $_SESSION['user_type'] === 'gestionnaire'): ?>
                            <a href="/stage/ProjetBinome/pages/tableau_bord.php" class="block px-3 py-2 text-gray-600 hover:bg-gray-50 flex items-center pl-11">
                                <i class="fas fa-table mr-3 w-5 text-center"></i>Tableau de bord
                            </a>
                        <?php endif; ?>
                        <a href="/stage/ProjetBinome/pages/profil.php" class="block px-3 py-2 text-gray-600 hover:bg-gray-50 flex items-center pl-11">
                            <i class="fas fa-user-circle mr-3 w-5 text-center"></i>Profil
                        </a>
                        <a href="/stage/ProjetBinome/pages/deconnexion.php" class="block px-3 py-2 text-gray-600 hover:bg-gray-50 flex items-center pl-11">
                            <i class="fas fa-sign-out-alt mr-3 w-5 text-center"></i>Déconnexion
                        </a>
                    </div>
                <?php elseif ($show_auth_buttons): ?>
                    <div class="pt-4 border-t">
                        <a href="/stage/ProjetBinome/pages/connexion.php" class="block px-3 py-2 text-gray-600 hover:bg-gray-50 flex items-center">
                            <i class="fas fa-sign-in-alt mr-3 w-5 text-center"></i>Connexion
                        </a>
                        <a href="/stage/ProjetBinome/pages/inscription.php" class="block px-3 py-2 text-gray-600 hover:bg-gray-50 flex items-center">
                            <i class="fas fa-user-plus mr-3 w-5 text-center"></i>Inscription
                        </a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <script>
        // Gestion du menu mobile
        document.addEventListener('DOMContentLoaded', function() {
            const mobileMenuButton = document.getElementById('mobile-menu-button');
            const mobileMenu = document.getElementById('mobile-menu');
            
            if (mobileMenuButton && mobileMenu) {
                mobileMenuButton.addEventListener('click', function(e) {
                    e.stopPropagation();
                    mobileMenu.classList.toggle('hidden');
                });
            }

            // Fermer le menu au clic ailleurs
            document.addEventListener('click', function() {
                if (mobileMenu && !mobileMenu.classList.contains('hidden')) {
                    mobileMenu.classList.add('hidden');
                }
            });

            // Empêcher la fermeture quand on clique dans le menu
            if (mobileMenu) {
                mobileMenu.addEventListener('click', function(e) {
                    e.stopPropagation();
                });
            }
        });
    </script>

    <!-- Script Alpine.js pour le menu déroulant -->
    <script src="//unpkg.com/alpinejs" defer></script>
</body>
</html>