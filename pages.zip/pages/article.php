<?php
session_start();
include_once("..\config\database.php");

$page_title = "Article";

// Récupérer l'id de l'article depuis l'URL
$id = isset($_GET['id']) && is_numeric($_GET['id']) ? (int) $_GET['id'] : 0;

if ($id <= 0) {
    // ID invalide, on peut rediriger ou afficher un message d'erreur
    header("Location: blog.php");
    exit;
}

// Préparer et exécuter la requête pour récupérer l'article
$sql = "SELECT titre, contenu, DATE_FORMAT(date_publication, '%d %M %Y') AS date_fr FROM articles WHERE id = :id";
$stmt = $pdo->prepare($sql);
$stmt->execute([':id' => $id]);
$article = $stmt->fetch();

if (!$article) {
    // Article non trouvé
    header("Location: blog.php");
    exit;
}

$page_title = $article['titre'];

?>

<!DOCTYPE html>
<html lang="fr" class="scroll-smooth">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title><?= htmlspecialchars($page_title) ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 text-gray-800 flex flex-col min-h-screen">

    <?php include_once(__DIR__ . "/../includes/navbar.php"); ?>

    <main class="container mx-auto px-4 py-12 max-w-3xl flex-grow">
        <article class="bg-white rounded-lg shadow p-8">
            <h1 class="text-4xl font-bold text-indigo-700 mb-4"><?= htmlspecialchars($article['titre']) ?></h1>
            <time datetime="<?= date('Y-m-d', strtotime($article['date_fr'])) ?>" class="text-gray-500 mb-6 block">
                Publié le <?= $article['date_fr'] ?>
            </time>
            <div class="prose max-w-full text-gray-700">
                <?= $article['contenu'] // On suppose que contenu contient du HTML sûr ?>
            </div>
            <a href="blog.php" class="inline-block mt-8 text-indigo-600 font-semibold hover:underline">
                &larr; Retour au blog
            </a>
        </article>
    </main>

    <?php include_once(__DIR__ . "/../includes/footer.php"); ?>

</body>
</html>
