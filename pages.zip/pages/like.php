<?php
session_start();
require 'connexion.php';

if (!isset($_SESSION['user_id']) || !isset($_POST['post_id'])) {
    header('Location: affichage.php');
    exit;
}

$utilisateur_id = $_SESSION['user_id'];
$post_id = $_POST['post_id'];

// Vérifier si déjà liké
$check = $pdo->prepare("SELECT * FROM likes WHERE utilisateur_id = ? AND post_id = ?");
$check->execute([$utilisateur_id, $post_id]);

if ($check->rowCount() == 0) {
    $stmt = $pdo->prepare("INSERT INTO likes (utilisateur_id, post_id) VALUES (?, ?)");
    $stmt->execute([$utilisateur_id, $post_id]);
}

header('Location: affichage.php');
exit;
