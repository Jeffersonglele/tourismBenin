<?php
session_start();
include_once(__DIR__ . "/../config/database.php");
include_once(__DIR__ . "/../includes/navbar.php");

// Récupérer les filtres
$region = $_GET['region'] ?? '';
$type = $_GET['type'] ?? '';
$search = $_GET['search'] ?? '';

try {
    // Construire la requête SQL
    $sql = "SELECT * FROM lieux WHERE 1=1";
    $params = [];

    if ($region) {
        $sql .= " AND region = ?";
        $params[] = $region;
    }
    if ($type) {
        $sql .= " AND type = ?";
        $params[] = $type;
    }
    if ($search) {
        $sql .= " AND (nom LIKE ? OR description LIKE ? OR ville LIKE ?)";
        $searchTerm = "%$search%";
        $params[] = $searchTerm;
        $params[] = $searchTerm;
        $params[] = $searchTerm;
    }

    $sql .= " ORDER BY date_ajout DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $lieux = $stmt->fetchAll();
} catch (PDOException $e) {
    $error = "Erreur lors de la récupération des destinations : " . $e->getMessage();
    $lieux = [];
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Destinations - Bénin Tourisme</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .hero-section {
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), 
                        url('../assets/images/destination.jpeg');
            background-size: cover;
            background-position: center;
            min-height: 60vh;
            display: flex;
            align-items: center;
            color: white;
            margin-bottom: 3rem;
        }
        .destination-card {
            transition: all 0.3s ease;
        }
        .destination-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body class="bg-gray-50">
    <!-- Hero Section -->
    <section class="hero-section flex items-center justify-center py-20">
        <div class="container mx-auto px-4 text-center">
            <h1 class="text-4xl md:text-5xl text-white mb-4">Découvrez nos Destinations</h1>
            <p class="text-xl text-white max-w-2xl mx-auto">Explorez les merveilles du Bénin à travers nos destinations sélectionnées</p>
        </div>
    </section>

    <!-- Filtres -->
    <section class="container mx-auto px-4 mt-10">
        <div class="bg-white rounded-xl shadow-md p-6">
            <form method="GET" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                    <input type="text" name="search" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent" 
                           placeholder="Rechercher..." value="<?= htmlspecialchars($search) ?>">
                </div>
                <div>
                    <select name="region" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
                        <option value="">Toutes les régions</option>
                        <option value="Nord" <?= $region === 'Nord' ? 'selected' : '' ?>>Nord</option>
                        <option value="Centre" <?= $region === 'Centre' ? 'selected' : '' ?>>Centre</option>
                        <option value="Sud" <?= $region === 'Sud' ? 'selected' : '' ?>>Sud</option>
                    </select>
                </div>
                <div>
                    <select name="type" class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent">
                        <option value="">Tous les types</option>
                        <option value="Culturel" <?= $type === 'Culturel' ? 'selected' : '' ?>>Culturel</option>
                        <option value="Nature" <?= $type === 'Nature' ? 'selected' : '' ?>>Nature</option>
                        <option value="Plage" <?= $type === 'Plage' ? 'selected' : '' ?>>Plage</option>
                    </select>
                </div>
                <div>
                    <button type="submit" class="w-full bg-primary hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg transition duration-300">
                        Filtrer
                    </button>
                </div>
            </form>
        </div>
    </section>

    <!-- Liste des destinations -->
    <section class="container mx-auto px-4 my-12">
        <?php if (isset($error)): ?>
            <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6">
                <?= htmlspecialchars($error) ?>
            </div>
        <?php endif; ?>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php if (!empty($lieux)): ?>
                <?php foreach ($lieux as $lieu): ?>
                    <div class="bg-white rounded-xl shadow-md overflow-hidden destination-card">
                        <div class="relative">
                            <img src="../<?= htmlspecialchars($lieu['image']) ?>" class="w-full h-48 object-cover" alt="<?= htmlspecialchars($lieu['nom']) ?>">
                            <span class="absolute top-4 right-4 bg-primary text-white px-3 py-1 rounded-full text-xs font-semibold">
                                <?= htmlspecialchars($lieu['type']) ?>
                            </span>
                        </div>
                        <div class="p-6">
                            <h3 class="text-xl font-bold text-gray-800 mb-2"><?= htmlspecialchars($lieu['nom']) ?></h3>
                            <p class="text-gray-600 mb-4"><?= htmlspecialchars(substr($lieu['description'], 0, 100)) ?>...</p>
                            
                            <div class="flex flex-col space-y-2 mb-6">
                                <div class="flex items-center">
                                    <i class="fas fa-map-marker-alt text-secondary mr-2"></i>
                                    <span class="text-gray-700"><?= htmlspecialchars($lieu['ville']) ?></span>
                                </div>
                                <?php if (isset($lieu['duree_visite']) && !empty($lieu['duree_visite'])): ?>
                                <div class="flex items-center">
                                    <i class="fas fa-clock text-secondary mr-2"></i>
                                    <span class="text-gray-700"><?= htmlspecialchars($lieu['duree_visite']) ?></span>
                                </div>
                                <?php endif; ?>
                            </div>
                            
                            <a href="lieu_detail.php?id=<?= $lieu['id'] ?>" class="block text-center bg-secondary hover:bg-orange-600 text-white font-bold py-2 px-4 rounded-lg transition duration-300">
                                Voir les détails
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="col-span-full text-center py-12">
                    <div class="bg-gray-100 rounded-xl p-8 max-w-md mx-auto">
                        <i class="fas fa-search text-gray-400 text-4xl mb-4"></i>
                        <h3 class="text-xl font-bold text-gray-700 mb-2">Aucune destination trouvée</h3>
                        <p class="text-gray-500">Essayez de modifier vos critères de recherche</p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <?php include_once(__DIR__ . "/../includes/footer.php"); ?>

    
</body>
</html>