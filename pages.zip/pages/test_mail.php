<?php
include_once("..\config\mail.php");

// Adresse email de test
$test_email = "contactbenintourisme@gmail.com"; // Remplacez par votre email de test

// Contenu du test
$subject = "Test d'envoi d'email - Bénin Tourisme";
$body = "
    <h2>Test d'envoi d'email</h2>
    <p>Bonjour,</p>
    <p>Ceci est un email de test pour vérifier que la configuration SMTP fonctionne correctement.</p>
    <p>Si vous recevez cet email, cela signifie que :</p>
    <ul>
        <li>La configuration SMTP est correcte</li>
        <li>Les identifiants sont valides</li>
        <li>PHPMailer fonctionne correctement</li>
    </ul>
    <p>Date et heure du test : " . date('d/m/Y H:i:s') . "</p>
    <p>Cordialement,<br>L'équipe Bénin Tourisme</p>
";

// Tentative d'envoi
echo "Tentative d'envoi d'email...<br>";

if (sendEmail($test_email, $subject, $body)) {
    echo "✅ Email envoyé avec succès !";
} else {
    echo "❌ Erreur lors de l'envoi de l'email. Vérifiez les logs pour plus de détails.";
} 