<?php
// actions/envoyer_contact.php

function envoyerContact(string $nom, string $email, string $message): bool {
    // Préparer l'email
    $to = "contactbenintourisme@gmail.com"; // À modifier selon l'adresse de contact réelle
    $subject = "Nouveau message de contact depuis le site Benin Découverte";
    
    $headers = "From: " . $email . "\r\n";
    $headers .= "Reply-To: " . $email . "\r\n";
    $headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
    
    $body = "Vous avez reçu un nouveau message de contact sur le site Benin Découverte :\n\n";
    $body .= "Nom : $nom\n";
    $body .= "Email : $email\n\n";
    $body .= "Message :\n$message\n";
    
    // Envoyer le mail
    return mail($to, $subject, $body, $headers);
}
