<?php
require_once '../config/database.php';

// Clé secrète du webhook (à remplacer par celle fournie par FedaPay)
$webhook_secret = 'wh_live_nUaL67BLNYEkcfBKKhHMcgNr';

// Récupérer la signature et le payload
$payload = file_get_contents('php://input');
$signature = $_SERVER['HTTP_X_FEDAPAY_SIGNATURE'] ?? '';

// Vérifier la signature
$computed_signature = hash_hmac('sha256', $payload, $webhook_secret);
if (!hash_equals($computed_signature, $signature)) {
    // La signature ne correspond pas, rejeter la requête
    http_response_code(401);
    echo json_encode(['error' => 'Invalid signature']);
    exit();
}

// Décoder le payload JSON
$data = json_decode($payload, true);

if ($data && isset($data['event'])) {
    try {
        switch ($data['event']) {
            case 'payment.succeeded':
                // Récupérer l'ID de l'utilisateur depuis les métadonnées du paiement
                $user_id = $data['data']['metadata']['user_id'] ?? null;
                
                if ($user_id) {
                    // Mettre à jour le statut de paiement en 'en_attente'
                    $stmt = $pdo->prepare("UPDATE utilisateurs SET statut_paiement = 'en_attente' WHERE id = ?");
                    $stmt->execute([$user_id]);
                    
                    // Envoyer un email de confirmation à l'utilisateur
                    $stmt = $pdo->prepare("SELECT email, prenom, nom FROM utilisateurs WHERE id = ?");
                    $stmt->execute([$user_id]);
                    $user = $stmt->fetch();
                    
                    if ($user) {
                        $to = $user['email'];
                        $subject = "Confirmation de paiement - Bénin Tourisme";
                        $message = "Bonjour " . $user['prenom'] . ",\n\n";
                        $message .= "Votre paiement a été reçu avec succès. Votre demande est maintenant en cours d'examen par notre équipe.\n";
                        $message .= "Vous recevrez une notification dès que votre compte sera validé.\n\n";
                        $message .= "Cordialement,\nL'équipe Bénin Tourisme";
                        
                        $headers = "From: noreply@benintourisme.com\r\n";
                        $headers .= "Reply-To: support@benintourisme.com\r\n";
                        
                        mail($to, $subject, $message, $headers);
                    }
                }
                break;

            case 'payment.failed':
                // Gérer le cas d'un paiement échoué
                $user_id = $data['data']['metadata']['user_id'] ?? null;
                if ($user_id) {
                    $stmt = $pdo->prepare("UPDATE utilisateurs SET statut_paiement = 'refuse' WHERE id = ?");
                    $stmt->execute([$user_id]);
                }
                break;
        }
        
        // Répondre avec un statut 200 pour confirmer la réception
        http_response_code(200);
        echo json_encode(['status' => 'success']);
        exit();
        
    } catch (Exception $e) {
        // Logger l'erreur
        error_log("Erreur webhook FedaPay: " . $e->getMessage());
        http_response_code(500);
        echo json_encode(['error' => 'Internal server error']);
        exit();
    }
}

// Si on arrive ici, c'est qu'il y a eu une erreur
http_response_code(400);
echo json_encode(['error' => 'Invalid event']);
?> 