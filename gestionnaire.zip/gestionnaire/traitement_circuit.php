<?php
// Connexion à la base de données (à adapter)
session_start();
include_once("..\config\database.php");

// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Gérer l'upload de l'image
    $imageName = null;
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);
        $imageName = time() . '_' . basename($_FILES['image']['name']);
        move_uploaded_file($_FILES['image']['tmp_name'], $uploadDir . $imageName);
    }

    // Préparation de la requête
    $sql = "INSERT INTO circuits (
        nom, sous_titre, description_courte, description_longue, itineraire, villes_visitees,
        prix, duree, taille_groupe, lieu_depart, image, type, tel, inclus, non_inclus,
        places_disponibles, site, email
    ) VALUES (
        :nom, :sous_titre, :description_courte, :description_longue, :itineraires, :villes_visitees,
        :prix, :duree, :taille_groupe, :lieu_depart, :image, :type, :tel, :inclus, :non_inclus,
        :places_disponibles, :site, :email
    )";

    $stmt = $pdo->prepare($sql);

    // Exécution avec les données
    $stmt->execute([
        ':nom' => $_POST['nom'] ?? '',
        ':sous_titre' => $_POST['sous_titre'] ?? '',
        ':description_courte' => $_POST['description_courte'] ?? '',
        ':description_longue' => $_POST['description_longue'] ?? '',
        ':itineraires' => $_POST['itineraires'] ?? '',
        ':villes_visitees' => $_POST['villes_visitees'] ?? '',
        ':prix' => $_POST['prix'] ?? 0,
        ':duree' => $_POST['duree'] ?? '',
        ':taille_groupe' => $_POST['taille_groupe'] ?? 0,
        ':lieu_depart' => $_POST['lieu_depart'] ?? '',
        ':image' => $imageName,
        ':type' => $_POST['type'] ?? '',
        ':tel' => $_POST['tel'] ?? '',
        ':inclus' => $_POST['inclus'] ?? '',
        ':non_inclus' => $_POST['non_inclus'] ?? '',
        ':places_disponibles' => $_POST['places_disponibles'] ?? 0,
        ':site' => $_POST['site'] ?? '',
        ':email' => $_POST['email'] ?? ''
    ]);

    $_SESSION['message'] = "✅ Lieu ajouté avec succès !";
    $_SESSION['message_type'] = "success"; // ou "error", selon le besoin
    header('Location: circuits.php');
    exit();
}else {
    $_SESSION['message'] = "erreur lors de l'ajout ";
$_SESSION['message_type'] = "warning"; // ou "error", selon le besoin
header('Location: circuits.php');
}
?>
