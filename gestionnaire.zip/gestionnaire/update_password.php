<?php
require_once('../config/database.php');

try {
    // Mettre à jour le mot de passe de l'administrateur
    $password = 'michee.01';
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    
    $stmt = $pdo->prepare("UPDATE gestionnaires SET mot_de_passe = ? WHERE email = ?");
    $stmt->execute([$hashed_password, 'micheeglele@gmail.com']);
    
    header("Location: tableau_bord.php");
} catch (PDOException $e) {
    echo "Erreur : " . $e->getMessage();
    
}
?> 