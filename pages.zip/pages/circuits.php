<?php
session_start();
include_once(__DIR__ . "/../config/database.php");

// Définir le titre de la page
$page_title = "Circuits Touristiques - Bénin Tourisme";
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/aos@next/dist/aos.css" />
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        primary: '#2F855A',
                        secondary: '#DD6B20',
                        dark: '#1A202C',
                        light: '#F7FAFC'
                    }
                }
            }
        }
    </script>
    <style>
        .hero-section {
            background: linear-gradient(rgba(0,0,0,0.6), rgba(0,0,0,0.6)), url('https://images.unsplash.com/photo-1540541338287-41700207dee6?w=800');
            background-size: cover;
            background-position: center;
        }
        .circuit-card {
            transition: all 0.3s ease;
        }
        .circuit-card:hover {
            transform: translateY(-5px);
        }
    </style>
</head>
<body class="bg-gray-50">
    <?php include_once(__DIR__ . "/../includes/navbar.php"); ?>

    <!-- Hero Section -->
    <section class="hero-section flex items-center justify-center h-96">
        <div class="text-center px-4">
            <h1 class="text-4xl md:text-5xl font-bold text-white mb-4" data-aos="fade-up">Circuits Touristiques</h1>
            <p class="text-xl text-white max-w-2xl mx-auto" data-aos="fade-up" data-aos-delay="100">
                Découvrez le Bénin avec nos guides experts à travers des expériences inoubliables
            </p>
        </div>
    </section>

    <!-- Circuits Section -->
    <section class="py-16">
        <div class="container mx-auto px-4">
            <div class="flex flex-col lg:flex-row gap-8">
                <!-- Filters -->
                <div class="lg:w-1/4">
                    <div class="bg-white p-6 rounded-xl shadow-md sticky top-4">
                        <h4 class="text-xl font-bold text-dark mb-6">Filtres</h4>
                        <form id="filterForm" class="space-y-4">
                            <div>
                                <label class="block text-gray-700 mb-2">Durée</label>
                                <select class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent" name="duree">
                                    <option value="">Toutes les durées</option>
                                    <option value="1">1 jour</option>
                                    <option value="2-3">2-3 jours</option>
                                    <option value="4-7">4-7 jours</option>
                                    <option value="8+">8+ jours</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">Type de circuit</label>
                                <select class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent" name="type">
                                    <option value="">Tous les types</option>
                                    <option value="culturel">Culturel</option>
                                    <option value="nature">Nature</option>
                                    <option value="aventure">Aventure</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-gray-700 mb-2">Budget</label>
                                <select class="w-full px-4 py-2 border rounded-lg focus:ring-2 focus:ring-primary focus:border-transparent" name="budget">
                                    <option value="">Tous les budgets</option>
                                    <option value="economique">Économique</option>
                                    <option value="standard">Standard</option>
                                    <option value="luxe">Luxe</option>
                                </select>
                            </div>
                            <button type="submit" class="w-full bg-primary hover:bg-green-700 text-white font-bold py-3 px-4 rounded-lg transition duration-300">
                                Appliquer les filtres
                            </button>
                        </form>
                    </div>
                </div>

                <!-- Circuits List -->
                <div class="lg:w-3/4">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                        <!-- Circuit 1 -->
                        <div class="bg-white rounded-xl shadow-md overflow-hidden circuit-card" data-aos="fade-up">
                            <div class="relative">
                                <img src="https://images.unsplash.com/photo-1566073771259-6a8506099945?w=800" class="w-full h-64 object-cover" alt="Circuit Culturel">
                                <div class="absolute top-4 right-4 bg-dark bg-opacity-80 text-white px-4 py-1 rounded-full text-sm">
                                    3 jours
                                </div>
                            </div>
                            <div class="p-6">
                                <h3 class="text-xl font-bold text-dark mb-2">Circuit Culturel du Sud</h3>
                                <p class="text-gray-600 mb-4">Découvrez les richesses culturelles du Sud Bénin, de Ouidah à Abomey.</p>
                                <ul class="space-y-2 mb-6">
                                    <li class="flex items-center">
                                        <i class="fas fa-map-marker-alt text-secondary mr-2"></i>
                                        <span>Ouidah, Abomey, Porto-Novo</span>
                                    </li>
                                    <li class="flex items-center">
                                        <i class="fas fa-users text-secondary mr-2"></i>
                                        <span>Max 12 personnes</span>
                                    </li>
                                    <li class="flex items-center">
                                        <i class="fas fa-star text-secondary mr-2"></i>
                                        <span>Guide expert</span>
                                    </li>
                                </ul>
                                <div class="flex justify-between items-center">
                                    <span class="text-2xl font-bold text-primary">75,000 FCFA</span>
                                    <a href="reservation.php?circuit=1" class="bg-secondary hover:bg-orange-600 text-white font-bold py-2 px-6 rounded-lg transition duration-300">
                                        Réserver
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Circuit 2 -->
                        <div class="bg-white rounded-xl shadow-md overflow-hidden circuit-card" data-aos="fade-up" data-aos-delay="100">
                            <div class="relative">
                                <img src="https://images.unsplash.com/photo-1540541338287-41700207dee6?w=800" class="w-full h-64 object-cover" alt="Circuit Nature">
                                <div class="absolute top-4 right-4 bg-dark bg-opacity-80 text-white px-4 py-1 rounded-full text-sm">
                                    5 jours
                                </div>
                            </div>
                            <div class="p-6">
                                <h3 class="text-xl font-bold text-dark mb-2">Aventure au Nord</h3>
                                <p class="text-gray-600 mb-4">Explorez les parcs nationaux et les cascades du Nord Bénin.</p>
                                <ul class="space-y-2 mb-6">
                                    <li class="flex items-center">
                                        <i class="fas fa-map-marker-alt text-secondary mr-2"></i>
                                        <span>Parc de la Pendjari, Natitingou</span>
                                    </li>
                                    <li class="flex items-center">
                                        <i class="fas fa-users text-secondary mr-2"></i>
                                        <span>Max 8 personnes</span>
                                    </li>
                                    <li class="flex items-center">
                                        <i class="fas fa-star text-secondary mr-2"></i>
                                        <span>Guide spécialisé</span>
                                    </li>
                                </ul>
                                <div class="flex justify-between items-center">
                                    <span class="text-2xl font-bold text-primary">120,000 FCFA</span>
                                    <a href="reservation.php?circuit=2" class="bg-secondary hover:bg-orange-600 text-white font-bold py-2 px-6 rounded-lg transition duration-300">
                                        Réserver
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Circuit 3 -->
                        <div class="bg-white rounded-xl shadow-md overflow-hidden circuit-card" data-aos="fade-up" data-aos-delay="200">
                            <div class="relative">
                                <img src="https://images.unsplash.com/photo-1530521954074-e64f6810b32d?w=800" class="w-full h-64 object-cover" alt="Circuit Plage">
                                <div class="absolute top-4 right-4 bg-dark bg-opacity-80 text-white px-4 py-1 rounded-full text-sm">
                                    2 jours
                                </div>
                            </div>
                            <div class="p-6">
                                <h3 class="text-xl font-bold text-dark mb-2">Week-end Plage</h3>
                                <p class="text-gray-600 mb-4">Détendez-vous sur les plus belles plages du Bénin.</p>
                                <ul class="space-y-2 mb-6">
                                    <li class="flex items-center">
                                        <i class="fas fa-map-marker-alt text-secondary mr-2"></i>
                                        <span>Grand-Popo, Cotonou</span>
                                    </li>
                                    <li class="flex items-center">
                                        <i class="fas fa-users text-secondary mr-2"></i>
                                        <span>Max 15 personnes</span>
                                    </li>
                                    <li class="flex items-center">
                                        <i class="fas fa-star text-secondary mr-2"></i>
                                        <span>Guide local</span>
                                    </li>
                                </ul>
                                <div class="flex justify-between items-center">
                                    <span class="text-2xl font-bold text-primary">45,000 FCFA</span>
                                    <a href="reservation.php?circuit=3" class="bg-secondary hover:bg-orange-600 text-white font-bold py-2 px-6 rounded-lg transition duration-300">
                                        Réserver
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php include_once(__DIR__ . "/../includes/footer.php"); ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://unpkg.com/aos@next/dist/aos.js"></script>
    <script>
        AOS.init({
            duration: 800,
            once: true,
            easing: 'ease-out-quad'
        });

        // Filtrage des circuits
        document.getElementById('filterForm').addEventListener('submit', function(e) {
            e.preventDefault();
            // Logique de filtrage à implémenter
            console.log('Filtres appliqués');
        });
    </script>
</body>
</html>