<?php
session_start();
include_once("../config/database.php");

if (isset($_POST['publication_id'], $_SESSION['user_id'])) {
    $publication_id = intval($_POST['publication_id']);
    $user_id = $_SESSION['user_id'];

    // Vérifier si déjà liké
    $stmt = $pdo->prepare("SELECT * FROM likes WHERE publication_id = ? AND user_id = ?");
    $stmt->execute([$publication_id, $user_id]);

    if ($stmt->rowCount() > 0) {
        // Déjà liké : on retire
        $pdo->prepare("DELETE FROM likes WHERE publication_id = ? AND user_id = ?")
            ->execute([$publication_id, $user_id]);
    } else {
        // Sinon on ajoute
        $pdo->prepare("INSERT INTO likes (publication_id, user_id) VALUES (?, ?)")
            ->execute([$publication_id, $user_id]);
    }

    // Retourner le nouveau nombre de likes
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM likes WHERE publication_id = ?");
    $stmt->execute([$publication_id]);
    echo $stmt->fetchColumn();
}
?>
