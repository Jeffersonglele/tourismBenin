<?php
session_start();
require 'connexion.php';

if (!isset($_GET['post_id'])) {
    header('Location: afficher_posts.php');
    exit;
}

$post_id = intval($_GET['post_id']);

// Récupérer le post
$stmtPost = $pdo->prepare("
    SELECT posts.*, utilisateurs.nom, utilisateurs.prenom 
    FROM posts 
    JOIN utilisateurs ON posts.utilisateur_id = utilisateurs.id 
    WHERE posts.id = ?
");
$stmtPost->execute([$post_id]);
$post = $stmtPost->fetch(PDO::FETCH_ASSOC);

if (!$post) {
    echo "Post introuvable.";
    exit;
}

// Récupérer les commentaires
$stmtComments = $pdo->prepare("
    SELECT commentaires.*, utilisateurs.nom, utilisateurs.prenom 
    FROM commentaires 
    JOIN utilisateurs ON commentaires.utilisateur_id = utilisateurs.id 
    WHERE post_id = ?
    ORDER BY date_commentaire ASC
");
$stmtComments->execute([$post_id]);
$commentaires = $stmtComments->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Commentaires</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100">
    <?php include_once(__DIR__ . "/../includes/navbar.php"); ?>

    <div class="max-w-3xl mx-auto mt-10">
        <!-- Post -->
        <div class="bg-white p-6 rounded-xl shadow-md mb-6">
            <p class="text-sm text-gray-600 mb-2">
                Posté par <strong><?= htmlspecialchars($post['prenom'] . ' ' . $post['nom']) ?></strong>
                le <?= date('d/m/Y H:i', strtotime($post['date_post'])) ?>
            </p>

            <?php if ($post['type_media'] == 'image'): ?>
                <img src="<?= htmlspecialchars($post['media']) ?>" alt="post image" class="w-full rounded-lg">
            <?php elseif ($post['type_media'] == 'video'): ?>
                <video controls class="w-full rounded-lg mt-2">
                    <source src="<?= htmlspecialchars($post['media']) ?>" type="video/mp4">
                    Votre navigateur ne supporte pas la vidéo.
                </video>
            <?php endif; ?>

            <?php if (!empty($post['texte'])): ?>
                <p class="mt-3"><?= nl2br(htmlspecialchars($post['texte'])) ?></p>
            <?php endif; ?>
        </div>

        <!-- Commentaires -->
        <div class="bg-white p-6 rounded-xl shadow">
            <h2 class="text-xl font-semibold mb-4">Commentaires</h2>

            <?php foreach ($commentaires as $com): ?>
                <div class="border-b pb-3 mb-3">
                    <p class="text-sm text-gray-600">
                        <strong><?= htmlspecialchars($com['prenom'] . ' ' . $com['nom']) ?></strong> - 
                        <?= date('d/m/Y H:i', strtotime($com['date_commentaire'])) ?>
                    </p>
                    <p><?= nl2br(htmlspecialchars($com['contenu'])) ?></p>
                </div>
            <?php endforeach; ?>

            <?php if (isset($_SESSION['user_id'])): ?>
            <!-- Formulaire commentaire -->
            <form action="poster_commentaire.php" method="post" class="mt-4">
                <input type="hidden" name="post_id" value="<?= $post_id ?>">
                <textarea name="contenu" rows="3" class="w-full p-2 border rounded-md" placeholder="Votre commentaire..." required></textarea>
                <button type="submit" class="mt-2 bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600">Envoyer</button>
            </form>
            <?php else: ?>
                <p class="text-gray-600 mt-4">Connectez-vous pour commenter.</p>
            <?php endif; ?>
        </div>
    </div>

    <?php include_once(__DIR__ . "/../includes/footer.php"); ?>
</body>
</html>
